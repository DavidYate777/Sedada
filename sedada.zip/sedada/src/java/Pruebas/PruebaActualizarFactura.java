package Pruebas;

import Controlador.FacturasDAO;
import Modelo.Facturas;
import java.time.LocalDate;
import java.util.Scanner;

public class PruebaActualizarFactura {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        FacturasDAO dao = new FacturasDAO();
        
        scanner.useLocale(java.util.Locale.US);
        
        System.out.print("Digite el ID de la factura que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        scanner.nextLine();
        
        Facturas factura = dao.consultarPorId(idAModificar);
        
        if (factura != null) {
            System.out.println("Factura actual N°: " + factura.getNumeros_factura() + " | Total: " + factura.getTotales());
            
            System.out.print("Digite el nuevo número de la factura: ");
            factura.setNumeros_factura(scanner.nextLine());
            
            System.out.print("Digite la nueva fecha (YYYY-MM-DD): ");
            factura.setFechas_factura(LocalDate.parse(scanner.nextLine()));
            
            System.out.print("Digite el nuevo subtotal: ");
            factura.setSubtotales(scanner.nextBigDecimal());
            
            System.out.print("Digite los nuevos impuestos: ");
            factura.setImpuestos(scanner.nextBigDecimal());
            
            System.out.print("Digite el nuevo total: ");
            factura.setTotales(scanner.nextBigDecimal());
            
            System.out.print("Digite el nuevo ID del estado de pago: ");
            factura.setEstados_pago_id_estados_pago(scanner.nextInt());
            
            boolean resultado = dao.actualizar(factura);
            
            if (resultado) {
                System.out.println("¡Factura actualizada correctamente!");
            } else {
                System.out.println("Error al actualizar la factura.");
            }
        } else {
            System.out.println("La factura con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}