package Controlador;

import Modelo.Facturas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class FacturasDAO {

    public Facturas consultarPorId(int idFactura, Connection conexion) {
        Facturas factura = null;
        String sql = "SELECT * FROM facturas WHERE id_facturas = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idFactura);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    factura = mapearFactura(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar factura por ID: " + e.getMessage());
        }
        return factura;
    }

    public List<Facturas> consultar(Connection conexion) {
        List<Facturas> lista = new ArrayList<>();
        String sql = "SELECT * FROM facturas ORDER BY id_facturas DESC";

        try (PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(mapearFactura(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar facturas: " + e.getMessage());
        }
        return lista;
    }

    public boolean insertar(Facturas factura, Connection conexion) {
        String sql = "INSERT INTO facturas (numeros_factura, fechas_factura, subtotales, impuestos, " +
                     "totales, pedidos_id_pedidos, estados_pago_id_estados_pago) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, factura.getNumeros_factura());
            
            if (factura.getFechas_factura() != null) {
                ps.setTimestamp(2, Timestamp.valueOf(factura.getFechas_factura().atStartOfDay()));
            } else {
                ps.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
            }
            
            ps.setBigDecimal(3, factura.getSubtotales());
            ps.setBigDecimal(4, factura.getImpuestos());
            ps.setBigDecimal(5, factura.getTotales());
            ps.setInt(6, factura.getPedidos_id_pedidos());
            ps.setInt(7, factura.getEstados_pago_id_estados_pago());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error SQL al insertar factura: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean actualizar(Facturas factura, Connection conexion) {
        String sql = "UPDATE facturas SET numeros_factura = ?, fechas_factura = ?, subtotales = ?, " +
                     "impuestos = ?, totales = ?, estados_pago_id_estados_pago = ? WHERE id_facturas = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, factura.getNumeros_factura());
            
            if (factura.getFechas_factura() != null) {
                ps.setTimestamp(2, Timestamp.valueOf(factura.getFechas_factura().atStartOfDay()));
            } else {
                ps.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
            }
            
            ps.setBigDecimal(3, factura.getSubtotales());
            ps.setBigDecimal(4, factura.getImpuestos());
            ps.setBigDecimal(5, factura.getTotales());
            ps.setInt(6, factura.getEstados_pago_id_estados_pago());
            ps.setInt(7, factura.getId_facturas());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar factura: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean cambiarEstadoPago(int idFactura, int idEstadoPago, Connection conexion) {
        String sql = "UPDATE facturas SET estados_pago_id_estados_pago = ? WHERE id_facturas = ?";
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idEstadoPago);
            ps.setInt(2, idFactura);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al cambiar estado de factura: " + e.getMessage());
            return false;
        }
    }

    public boolean activarFactura(int idFactura, int idEstadoActivo, Connection conexion) {
        return cambiarEstadoPago(idFactura, idEstadoActivo, conexion);
    }

    public boolean inactivarFactura(int idFactura, int idEstadoInactivo, Connection conexion) {
        return cambiarEstadoPago(idFactura, idEstadoInactivo, conexion);
    }

    public boolean eliminar(int idFactura, Connection conexion) {
        String sql = "DELETE FROM facturas WHERE id_facturas = ?";
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idFactura);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar factura: " + e.getMessage());
            return false;
        }
    }

    // Métodos con conexión autogestionada
    public Facturas consultarPorId(int idFactura) {
        try (Connection con = Conexion.getConnection()) {
            return consultarPorId(idFactura, con);
        } catch (SQLException e) {
            return null;
        }
    }

    public List<Facturas> consultar() {
        try (Connection con = Conexion.getConnection()) {
            return consultar(con);
        } catch (SQLException e) {
            return new ArrayList<>();
        }
    }

    public boolean insertar(Facturas factura) {
        try (Connection con = Conexion.getConnection()) {
            return insertar(factura, con);
        } catch (SQLException e) {
            return false;
        }
    }

    public boolean actualizar(Facturas factura) {
        try (Connection con = Conexion.getConnection()) {
            return actualizar(factura, con);
        } catch (SQLException e) {
            return false;
        }
    }

    public boolean activarFactura(int idFactura, int idEstadoActivo) {
        try (Connection con = Conexion.getConnection()) {
            return activarFactura(idFactura, idEstadoActivo, con);
        } catch (SQLException e) {
            return false;
        }
    }

    public boolean inactivarFactura(int idFactura, int idEstadoInactivo) {
        try (Connection con = Conexion.getConnection()) {
            return inactivarFactura(idFactura, idEstadoInactivo, con);
        } catch (SQLException e) {
            return false;
        }
    }

    public boolean eliminar(int idFactura) {
        try (Connection con = Conexion.getConnection()) {
            return eliminar(idFactura, con);
        } catch (SQLException e) {
            return false;
        }
    }

    private Facturas mapearFactura(ResultSet rs) throws SQLException {
        Facturas factura = new Facturas();
        factura.setId_facturas(rs.getInt("id_facturas"));
        factura.setNumeros_factura(rs.getString("numeros_factura"));
        
        Timestamp timestamp = rs.getTimestamp("fechas_factura");
        if (timestamp != null) {
            factura.setFechas_factura(timestamp.toLocalDateTime().toLocalDate());
        }
        
        factura.setSubtotales(rs.getBigDecimal("subtotales"));
        factura.setImpuestos(rs.getBigDecimal("impuestos"));
        factura.setTotales(rs.getBigDecimal("totales"));
        factura.setPedidos_id_pedidos(rs.getInt("pedidos_id_pedidos"));
        factura.setEstados_pago_id_estados_pago(rs.getInt("estados_pago_id_estados_pago"));
        return factura;
    }
}