package Servelet;

import Controlador.RolesDAO;
import Controlador.TipoDeDocumentosDAO;
import Controlador.UsuarioDAO;
import Modelo.Roles;
import Modelo.TipoDeDocumentos;
import Modelo.Usuarios;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "AdminUsuariosServlet", urlPatterns = {"/admin/usuarios"})
public class AdminUsuariosServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        String accion = request.getParameter("accion");
        UsuarioDAO usuarioDAO = new UsuarioDAO();

        // Manejo de eliminación
        if ("eliminar".equals(accion)) {
            try {
                int idUsuario = Integer.parseInt(request.getParameter("id"));
                usuarioDAO.eliminar(idUsuario);
            } catch (Exception e) {
                System.err.println("Error al eliminar usuario: " + e.getMessage());
            }
            response.sendRedirect(request.getContextPath() + "/admin/usuarios");
            return;
        }

        try {
            List<Usuarios> listaUsuarios = usuarioDAO.consultar();
            
            // Cargar tipos de documento y roles desde la BD
            TipoDeDocumentosDAO tipoDocDAO = new TipoDeDocumentosDAO();
            RolesDAO rolesDAO = new RolesDAO();
            
            List<TipoDeDocumentos> listaTiposDoc = tipoDocDAO.consultar(); // Usa consultar() de tu DAO
            List<Roles> listaRoles = rolesDAO.consultarTodos();             // Usa consultarTodos() de tu DAO

            request.setAttribute("listaUsuarios", listaUsuarios);
            request.setAttribute("listaTiposDoc", listaTiposDoc);
            request.setAttribute("listaRoles", listaRoles);
            
            // Métricas
            int totalColaboradores = listaUsuarios.size();
            long usuariosActivos = listaUsuarios.stream().filter(u -> u.getEstados_usuarios_id_estados_usuario() == 1).count();
            
            request.setAttribute("totalColaboradores", totalColaboradores);
            request.setAttribute("usuariosActivos", usuariosActivos);

        } catch (Exception e) {
            System.err.println("Error al cargar usuarios: " + e.getMessage());
            e.printStackTrace();
        }

        request.getRequestDispatcher("/admin/admin_usuarios.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String accion = request.getParameter("accion");
        UsuarioDAO usuarioDAO = new UsuarioDAO();

        if ("insertar".equals(accion)) {
            try {
                Usuarios nuevoUsuario = new Usuarios();
                nuevoUsuario.setNombre_usuarios(request.getParameter("nombre_usuarios"));
                nuevoUsuario.setApellido_usuarios(request.getParameter("apellido_usuarios"));
                nuevoUsuario.setDireccion_usuarios(request.getParameter("direccion_usuarios"));
                nuevoUsuario.setTelefonos(request.getParameter("telefonos"));
                nuevoUsuario.setNumero_documentos(request.getParameter("numero_documentos"));
                
                String fechaNac = request.getParameter("fecha_nacimientos");
                nuevoUsuario.setFecha_nacimientos(fechaNac != null && !fechaNac.isEmpty() ? Date.valueOf(fechaNac) : new Date(System.currentTimeMillis()));
                
                String fechaVen = request.getParameter("fecha_vencimiento_claves");
                nuevoUsuario.setFecha_vencimiento_claves(fechaVen != null && !fechaVen.isEmpty() ? Date.valueOf(fechaVen) : new Date(System.currentTimeMillis()));
                
                nuevoUsuario.setCorreos(request.getParameter("correos"));
                nuevoUsuario.setPasswords(request.getParameter("passwords"));
                nuevoUsuario.setAutorizacion_datos(true);
                nuevoUsuario.setRoles_id_roles(Integer.parseInt(request.getParameter("roles_id_roles")));
                nuevoUsuario.setEstados_usuarios_id_estados_usuario(1); // Activo por defecto
                nuevoUsuario.setTipo_de_documentos_id_tipo_de_documento(Integer.parseInt(request.getParameter("tipo_de_documentos_id_tipo_de_documento")));

                usuarioDAO.insertar(nuevoUsuario);
            } catch (Exception e) {
                System.err.println("Error al insertar usuario: " + e.getMessage());
            }
        } else if ("actualizar".equals(accion)) {
            try {
                int idUsuario = Integer.parseInt(request.getParameter("id_Usuarios"));
                Usuarios usuario = usuarioDAO.consultarPorId(idUsuario);

                if (usuario != null) {
                    usuario.setNombre_usuarios(request.getParameter("nombre_usuarios"));
                    usuario.setApellido_usuarios(request.getParameter("apellido_usuarios"));
                    usuario.setDireccion_usuarios(request.getParameter("direccion_usuarios"));
                    usuario.setTelefonos(request.getParameter("telefonos"));
                    usuario.setNumero_documentos(request.getParameter("numero_documentos"));
                    
                    String fechaNac = request.getParameter("fecha_nacimientos");
                    if (fechaNac != null && !fechaNac.isEmpty()) {
                        usuario.setFecha_nacimientos(Date.valueOf(fechaNac));
                    }
                    
                    String fechaVen = request.getParameter("fecha_vencimiento_claves");
                    if (fechaVen != null && !fechaVen.isEmpty()) {
                        usuario.setFecha_vencimiento_claves(Date.valueOf(fechaVen));
                    }
                    
                    usuario.setCorreos(request.getParameter("correos"));
                    usuario.setPasswords(request.getParameter("passwords"));
                    usuario.setRoles_id_roles(Integer.parseInt(request.getParameter("roles_id_roles")));
                    usuario.setEstados_usuarios_id_estados_usuario(Integer.parseInt(request.getParameter("estados_usuarios_id_estados_usuario")));
                    usuario.setTipo_de_documentos_id_tipo_de_documento(Integer.parseInt(request.getParameter("tipo_de_documentos_id_tipo_de_documento")));

                    usuarioDAO.actualizar(usuario);
                }
            } catch (Exception e) {
                System.err.println("Error al actualizar usuario: " + e.getMessage());
            }
        }

        response.sendRedirect(request.getContextPath() + "/admin/usuarios");
    }
}