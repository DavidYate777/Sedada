package Servelet;

import Controlador.Conexion;
import Controlador.MesasDAO;
import Controlador.EstadosMesaDAO;
import Modelo.Mesas;
import Modelo.EstadosMesa;
import Modelo.Usuarios;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "AdminMesasServlet", urlPatterns = {"/admin/mesas"})
public class AdminMesasServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        String accion = request.getParameter("accion");
        MesasDAO mesasDAO = new MesasDAO();
        EstadosMesaDAO estadosMesaDAO = new EstadosMesaDAO();

        // Manejo de eliminación
        if ("eliminar".equals(accion)) {
            try {
                int idMesa = Integer.parseInt(request.getParameter("id"));
                mesasDAO.eliminarMesa(idMesa);
            } catch (Exception e) {
                System.err.println("Error al eliminar mesa: " + e.getMessage());
            }
            response.sendRedirect(request.getContextPath() + "/admin/mesas");
            return;
        }

        try (Connection conn = Conexion.getConnection()) {
            List<Mesas> listaMesas = mesasDAO.consultarTodas(conn);
            request.setAttribute("listaMesas", listaMesas);
            
            // Cargar los estados de mesa para el <select> con la clase correcta EstadosMesa
            List<EstadosMesa> listaEstadosMesa = estadosMesaDAO.consultarTodos(conn);
            request.setAttribute("listaEstadosMesa", listaEstadosMesa);
            
            // Métricas rápidas para las tarjetas superiores (incluyendo los nuevos IDs 3 y 4)
            int totalMesas = listaMesas.size();
            long disponibles = listaMesas.stream().filter(m -> m.getEstados_mesa_id_estados_mesa() == 1).count();
            long ocupadas = listaMesas.stream().filter(m -> m.getEstados_mesa_id_estados_mesa() == 2).count();
            long reservadas = listaMesas.stream().filter(m -> m.getEstados_mesa_id_estados_mesa() == 3 || m.getEstados_mesa_id_estados_mesa() == 4).count();
            
            request.setAttribute("totalMesas", totalMesas);
            request.setAttribute("disponibles", disponibles);
            request.setAttribute("ocupadas", ocupadas);
            request.setAttribute("reservadas", reservadas);

        } catch (Exception e) {
            System.err.println("Error al cargar mesas o estados: " + e.getMessage());
            e.printStackTrace();
        }

        request.getRequestDispatcher("/admin/admin_mesas.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String accion = request.getParameter("accion");
        MesasDAO mesasDAO = new MesasDAO();

        if ("insertar".equals(accion)) {
            try {
                Mesas nuevaMesa = new Mesas();
                nuevaMesa.setNumero_mesas(Integer.parseInt(request.getParameter("numero_mesas")));
                nuevaMesa.setCapacidades(Integer.parseInt(request.getParameter("capacidades")));
                nuevaMesa.setEstados_mesa_id_estados_mesa(Integer.parseInt(request.getParameter("estados_mesa_id_estados_mesa")));

                mesasDAO.insertarMesa(nuevaMesa);
            } catch (Exception e) {
                System.err.println("Error al insertar mesa: " + e.getMessage());
            }
        } else if ("actualizar".equals(accion)) {
            try {
                int idMesa = Integer.parseInt(request.getParameter("id_mesas"));
                Mesas mesa = mesasDAO.consultarMesa(idMesa);

                if (mesa != null) {
                    mesa.setNumero_mesas(Integer.parseInt(request.getParameter("numero_mesas")));
                    mesa.setCapacidades(Integer.parseInt(request.getParameter("capacidades")));
                    mesa.setEstados_mesa_id_estados_mesa(Integer.parseInt(request.getParameter("estados_mesa_id_estados_mesa")));

                    mesasDAO.actualizarMesa(mesa);
                }
            } catch (Exception e) {
                System.err.println("Error al actualizar mesa: " + e.getMessage());
            }
        }

        response.sendRedirect(request.getContextPath() + "/admin/mesas");
    }
}