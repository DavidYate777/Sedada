package Servelet;

import Controlador.Conexion;
import Controlador.EstadosPedidosDAO;
import Controlador.MesasDAO;
import Controlador.PedidoDAO;
import Modelo.EstadoPedido;
import Modelo.Mesas;
import Modelo.Pedido;
import Modelo.Usuarios;

import java.io.IOException;
import java.sql.Connection;
import java.time.LocalDateTime;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "AdminPedidosServlet", urlPatterns = {"/admin/pedidos"})
public class AdminPedidosServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        String accion = request.getParameter("accion");
        PedidoDAO pedidoDAO = new PedidoDAO();
        EstadosPedidosDAO estadosPedidosDAO = new EstadosPedidosDAO();
        MesasDAO mesasDAO = new MesasDAO();

        // Manejo de eliminación vía GET si se solicita
        if ("eliminar".equals(accion)) {
            try {
                int idPedido = Integer.parseInt(request.getParameter("id"));
                pedidoDAO.eliminar(idPedido);
            } catch (Exception e) {
                System.err.println("Error al eliminar pedido: " + e.getMessage());
            }
            response.sendRedirect(request.getContextPath() + "/admin/pedidos");
            return;
        }

        try (Connection conn = Conexion.getConnection()) {
            List<Pedido> listaPedidos = pedidoDAO.consultar(conn);
            request.setAttribute("listaPedidos", listaPedidos);

            // Cargar los estados de pedidos
            List<EstadoPedido> listaEstadosPedidos = estadosPedidosDAO.consultarTodos(conn);
            request.setAttribute("listaEstadosPedidos", listaEstadosPedidos);

            // Cargar las mesas disponibles
            List<Mesas> listaMesas = mesasDAO.consultar(conn);
            request.setAttribute("listaMesas", listaMesas);

        } catch (Exception e) {
            System.err.println("Error al cargar los datos de pedidos: " + e.getMessage());
            e.printStackTrace();
        }

        request.getRequestDispatcher("/admin/admin_pedidos.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String accion = request.getParameter("accion");
        PedidoDAO pedidoDAO = new PedidoDAO();
        Usuarios usuarioLogueado = (Usuarios) request.getSession().getAttribute("usuarioLogueado");

        if ("insertar".equals(accion)) {
            try {
                Pedido nuevoPedido = new Pedido();
                nuevoPedido.setFecha_horas(LocalDateTime.now());
                
                int idUser = 1;
                if (usuarioLogueado != null) {
                    try {
                        idUser = usuarioLogueado.getId_Usuarios();
                    } catch (Exception e) {
                        idUser = 1;
                    }
                }
                nuevoPedido.setUsuarios_id_usuarios(idUser);
                
                String mesaStr = request.getParameter("mesas_id_mesas");
                if (mesaStr != null && !mesaStr.isEmpty() && !mesaStr.equals("domicilio")) {
                    nuevoPedido.setMesas_id_mesas(Integer.parseInt(mesaStr));
                } else {
                    nuevoPedido.setMesas_id_mesas(null); // Es domicilio
                }
                
                nuevoPedido.setDireccion_entrega(request.getParameter("direccion_entrega"));
                nuevoPedido.setTelefono_contacto(request.getParameter("telefono_contacto"));
                
                String estadoStr = request.getParameter("estados_pedidos_id_estados_pedidos");
                if (estadoStr != null && !estadoStr.isEmpty()) {
                    nuevoPedido.setEstados_pedidos_id_estados_pedidos(Integer.parseInt(estadoStr));
                } else {
                    nuevoPedido.setEstados_pedidos_id_estados_pedidos(1);
                }

                pedidoDAO.insertar(nuevoPedido);
            } catch (Exception e) {
                System.err.println("Error al insertar pedido: " + e.getMessage());
                e.printStackTrace();
            }
        } else if ("actualizar".equals(accion)) {
            try {
                int idPedido = Integer.parseInt(request.getParameter("id_pedidos"));
                Pedido pedido = pedidoDAO.consultarPorId(idPedido);
                
                if (pedido != null) {
                    String mesaStr = request.getParameter("mesas_id_mesas");
                    if (mesaStr != null && !mesaStr.isEmpty() && !mesaStr.equals("domicilio")) {
                        pedido.setMesas_id_mesas(Integer.parseInt(mesaStr));
                    } else {
                        pedido.setMesas_id_mesas(null);
                    }
                    
                    pedido.setDireccion_entrega(request.getParameter("direccion_entrega"));
                    pedido.setTelefono_contacto(request.getParameter("telefono_contacto"));
                    
                    String estadoStr = request.getParameter("estados_pedidos_id_estados_pedidos");
                    if (estadoStr != null && !estadoStr.isEmpty()) {
                        pedido.setEstados_pedidos_id_estados_pedidos(Integer.parseInt(estadoStr));
                    }

                    pedidoDAO.actualizar(pedido);
                }
            } catch (Exception e) {
                System.err.println("Error al actualizar pedido: " + e.getMessage());
                e.printStackTrace();
            }
        }

        response.sendRedirect(request.getContextPath() + "/admin/pedidos");
    }
}