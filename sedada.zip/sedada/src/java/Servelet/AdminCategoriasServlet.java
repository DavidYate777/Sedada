package Servelet;

import Controlador.CategoriaDAO;
import Modelo.Categoria;
import Modelo.Usuarios;

import java.io.IOException;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "AdminCategoriasServlet", urlPatterns = {"/admin/categorias", "/AdminCategoriasServlet"})
public class AdminCategoriasServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Validar Sesión
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        CategoriaDAO categoriaDAO = new CategoriaDAO();

        // 2. Procesar acciones vía GET (Eliminar o Seleccionar para Editar)
        String accion = request.getParameter("accion");
        String detalleIdStr = request.getParameter("detalle_id");

        if ("eliminar".equals(accion)) {
            String idStr = request.getParameter("id");
            if (idStr != null && !idStr.isEmpty()) {
                int id = Integer.parseInt(idStr);
                categoriaDAO.eliminarCategoria(id);
            }
            response.sendRedirect(request.getContextPath() + "/admin/categorias");
            return;
        }

        // Si se seleccionó una categoría para editar
        if (detalleIdStr != null && !detalleIdStr.isEmpty()) {
            int idEditar = Integer.parseInt(detalleIdStr);
            Categoria catSeleccionada = categoriaDAO.consultarCategoria(idEditar);
            request.setAttribute("categoriaSeleccionada", catSeleccionada);
        }

        // 3. Cargar la lista completa de categorías
        List<Categoria> listaCategorias = categoriaDAO.consultarTodas();
        request.setAttribute("listaCategorias", listaCategorias);

        // 4. Redirigir al JSP correspondiente
        request.getRequestDispatcher("/admin/admin_categorias.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        String accion = request.getParameter("accion");
        CategoriaDAO categoriaDAO = new CategoriaDAO();

        if ("insertar_categoria".equals(accion)) {
            String nombre = request.getParameter("nombre_categorias");
            if (nombre != null && !nombre.trim().isEmpty()) {
                Categoria nuevaCat = new Categoria();
                nuevaCat.setNombre_categorias(nombre.trim());
                categoriaDAO.insertarCategoria(nuevaCat);
            }
        } else if ("actualizar_categoria".equals(accion)) {
            String idStr = request.getParameter("id_categorias");
            String nombre = request.getParameter("nombre_categorias");

            if (idStr != null && nombre != null && !nombre.trim().isEmpty()) {
                Categoria cat = new Categoria();
                cat.setId_categorias(Integer.parseInt(idStr));
                cat.setNombre_categorias(nombre.trim());
                categoriaDAO.actualizarCategoria(cat);
            }
        }

        response.sendRedirect(request.getContextPath() + "/admin/categorias");
    }
}