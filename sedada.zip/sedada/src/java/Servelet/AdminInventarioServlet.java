package Servelet;

import Controlador.Conexion;
import Controlador.CategoriaDAO;
import Controlador.ProductosDAO;
import Modelo.Categoria;
import Modelo.Productos;
import Modelo.Usuarios;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "AdminInventarioServlet", urlPatterns = {"/admin/inventario"})
public class AdminInventarioServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        String accion = request.getParameter("accion");
        ProductosDAO productosDAO = new ProductosDAO();
        CategoriaDAO categoriaDAO = new CategoriaDAO();

        // Manejo de eliminación
        if ("eliminar".equals(accion)) {
            try {
                int idProducto = Integer.parseInt(request.getParameter("id"));
                productosDAO.eliminar(idProducto);
            } catch (Exception e) {
                System.err.println("Error al eliminar producto: " + e.getMessage());
            }
            response.sendRedirect(request.getContextPath() + "/admin/inventario");
            return;
        }

        try (Connection conn = Conexion.getConnection()) {
            List<Productos> listaProductos = productosDAO.consultar(conn);
            request.setAttribute("listaProductos", listaProductos);

            // Cargar la lista de categorías para los menús desplegables (<select>)
            List<Categoria> listaCategorias = categoriaDAO.consultarTodas(conn);
            request.setAttribute("listaCategorias", listaCategorias);

        } catch (Exception e) {
            System.err.println("Error al cargar inventario o categorías: " + e.getMessage());
            e.printStackTrace();
        }

        request.getRequestDispatcher("/admin/admin_inventario.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String accion = request.getParameter("accion");
        ProductosDAO productosDAO = new ProductosDAO();

        if ("insertar".equals(accion)) {
            try {
                Productos nuevoProducto = new Productos();
                nuevoProducto.setNombres_productos(request.getParameter("nombre_productos"));
                
                String desc = request.getParameter("descripciones");
                nuevoProducto.setDescripciones(desc != null && !desc.trim().isEmpty() ? desc : "Sin descripción");
                
                nuevoProducto.setPrecios(new BigDecimal(request.getParameter("precio")));
                nuevoProducto.setCategorias_id_categorias(Integer.parseInt(request.getParameter("categorias_id_categorias")));
                nuevoProducto.setEstados_productos_id_estados_productos(1); // Valor por defecto activo
                nuevoProducto.setImpuestos_dian_id_impuestos_dian(1); // Valor por defecto impuesto DIAN

                productosDAO.insertar(nuevoProducto);
            } catch (Exception e) {
                System.err.println("Error al insertar producto: " + e.getMessage());
                e.printStackTrace();
            }
        } else if ("actualizar".equals(accion)) {
            try {
                int idProducto = Integer.parseInt(request.getParameter("id_productos"));
                Productos producto = productosDAO.consultarPorId(idProducto);

                if (producto != null) {
                    producto.setNombres_productos(request.getParameter("nombre_productos"));
                    
                    String desc = request.getParameter("descripciones");
                    if (desc != null && !desc.trim().isEmpty()) {
                        producto.setDescripciones(desc);
                    }
                    
                    producto.setPrecios(new BigDecimal(request.getParameter("precio")));
                    producto.setCategorias_id_categorias(Integer.parseInt(request.getParameter("categorias_id_categorias")));

                    productosDAO.actualizar(producto);
                }
            } catch (Exception e) {
                System.err.println("Error al actualizar producto: " + e.getMessage());
                e.printStackTrace();
            }
        }

        response.sendRedirect(request.getContextPath() + "/admin/inventario");
    }
}