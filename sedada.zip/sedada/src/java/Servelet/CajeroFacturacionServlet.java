package Servelet;

import Controlador.Conexion;
import Controlador.DetalleFacturaDAO;
import Controlador.DetallePedidosDAO;
import Controlador.EstadosPagoDAO;
import Controlador.EstadosPedidosDAO;
import Controlador.FacturasDAO;
import Controlador.ImpuestosDianDAO;
import Controlador.MesasDAO;
import Controlador.MetodosPagoDAO;
import Controlador.PagosDAO;
import Controlador.PedidoDAO;
import Controlador.ProductosDAO;
import Controlador.RolesDAO;
import Modelo.DetalleFactura;
import Modelo.DetallePedidos;
import Modelo.EstadoPedido;
import Modelo.EstadosPago;
import Modelo.Facturas;
import Modelo.ImpuestosDian;
import Modelo.Mesas;
import Modelo.MetodosPago;
import Modelo.Pago;
import Modelo.Pedido;
import Modelo.Productos;
import Modelo.Roles;
import Modelo.Usuarios;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet encargado de la facturación por parte del Cajero.
 */
@WebServlet(name = "CajeroFacturacionServlet", urlPatterns = {"/cajero/facturacion"})
public class CajeroFacturacionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        Usuarios usuario = (Usuarios) session.getAttribute("usuarioLogueado");
        if (esRol(usuario, "mesero")) {
            response.sendRedirect(request.getContextPath() + "/mesero/dashboard");
            return;
        }

        try (Connection conn = Conexion.getConnection()) {
            PedidoDAO pedidoDAO = new PedidoDAO();
            DetallePedidosDAO detallePedidosDAO = new DetallePedidosDAO();
            ProductosDAO productosDAO = new ProductosDAO();
            ImpuestosDianDAO impuestosDAO = new ImpuestosDianDAO();
            FacturasDAO facturasDAO = new FacturasDAO();
            EstadosPagoDAO estadosPagoDAO = new EstadosPagoDAO();
            MetodosPagoDAO metodosPagoDAO = new MetodosPagoDAO();
            PagosDAO pagosDAO = new PagosDAO();

            Map<Integer, Productos> mapaProductos = mapaProductos(productosDAO.consultar(conn));
            Map<Integer, BigDecimal> mapaPorcentajeImpuesto = mapaPorcentajesImpuesto(impuestosDAO.consultarTodos(conn));

            List<Pedido> todosPedidos = pedidoDAO.consultar(conn);
            List<DetallePedidos> todosDetalles = detallePedidosDAO.consultar(conn);
            List<Facturas> todasFacturas = facturasDAO.consultar(conn);

            Set<Integer> pedidosFacturados = new HashSet<>();
            Map<Integer, Facturas> facturaPorPedido = new HashMap<>();
            if (todasFacturas != null) {
                for (Facturas f : todasFacturas) {
                    pedidosFacturados.add(f.getPedidos_id_pedidos());
                    facturaPorPedido.put(f.getPedidos_id_pedidos(), f);
                }
            }

            // --- Pedidos pendientes de facturar ---
            List<Pedido> pedidosPendientes = new ArrayList<>();
            Map<Integer, List<DetallePedidos>> detallesPorPedido = new HashMap<>();
            Map<Integer, BigDecimal> totalPorPedido = new HashMap<>();

            if (todosPedidos != null) {
                for (Pedido p : todosPedidos) {
                    if (pedidosFacturados.contains(p.getId_pedidos())) {
                        continue;
                    }
                    List<DetallePedidos> lineas = new ArrayList<>();
                    BigDecimal totalPedido = BigDecimal.ZERO;
                    if (todosDetalles != null) {
                        for (DetallePedidos d : todosDetalles) {
                            if (d.getPedidos_id_pedidos() == p.getId_pedidos()) {
                                lineas.add(d);
                                if (d.getPrecio_unitario() != null) {
                                    totalPedido = totalPedido.add(
                                            d.getPrecio_unitario().multiply(BigDecimal.valueOf(d.getCantidades())));
                                }
                            }
                        }
                    }
                    if (!lineas.isEmpty()) {
                        pedidosPendientes.add(p);
                        detallesPorPedido.put(p.getId_pedidos(), lineas);
                        totalPorPedido.put(p.getId_pedidos(), totalPedido);
                    }
                }
            }
            pedidosPendientes.sort((a, b) -> Integer.compare(b.getId_pedidos(), a.getId_pedidos()));

            // --- Estados de pago y métodos de pago ---
            List<EstadosPago> listaEstadosPago = estadosPagoDAO.consultarTodos(conn);
            Map<Integer, String> mapaEstadosPago = new HashMap<>();
            if (listaEstadosPago != null) {
                for (EstadosPago e : listaEstadosPago) {
                    mapaEstadosPago.put(e.getId_estados_pago(), e.getNombres_estados_pago());
                }
            }
            int idEstadoPagado = resolverIdEstadoPagoPorNombre(listaEstadosPago, "pagad", -1);

            List<MetodosPago> listaMetodosPago = metodosPagoDAO.consultarTodos(conn);

            // --- Pagos existentes ---
            Set<Integer> facturasConPago = new HashSet<>();
            List<Pago> listaPagos = pagosDAO.consultarTodos(conn);
            if (listaPagos != null) {
                for (Pago pago : listaPagos) {
                    facturasConPago.add(pago.getFacturas_id_facturas());
                }
            }

            if (todasFacturas != null) {
                todasFacturas.sort((a, b) -> Integer.compare(b.getId_facturas(), a.getId_facturas()));
            }

            request.setAttribute("pedidosPendientes", pedidosPendientes);
            request.setAttribute("detallesPorPedido", detallesPorPedido);
            request.setAttribute("totalPorPedido", totalPorPedido);
            request.setAttribute("mapaProductos", mapaProductos);
            request.setAttribute("mapaPorcentajeImpuesto", mapaPorcentajeImpuesto);
            request.setAttribute("todasFacturas", todasFacturas);
            request.setAttribute("mapaEstadosPago", mapaEstadosPago);
            request.setAttribute("idEstadoPagado", idEstadoPagado);
            request.setAttribute("listaMetodosPago", listaMetodosPago);
            request.setAttribute("facturasConPago", facturasConPago);

        } catch (Exception e) {
            System.err.println("Error al cargar la facturación del cajero: " + e.getMessage());
            e.printStackTrace();
        }

        request.getRequestDispatcher("/cajero/cajero_facturacion.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        String accion = request.getParameter("accion");

        if ("generar_factura".equals(accion)) {
            generarFactura(request);
        } else if ("registrar_pago".equals(accion)) {
            registrarPago(request);
        }

        response.sendRedirect(request.getContextPath() + "/cajero/facturacion");
    }

    private void generarFactura(HttpServletRequest request) {
        try (Connection conn = Conexion.getConnection()) {
            int idPedido = Integer.parseInt(request.getParameter("id_pedido"));

            PedidoDAO pedidoDAO = new PedidoDAO();
            DetallePedidosDAO detallePedidosDAO = new DetallePedidosDAO();
            ProductosDAO productosDAO = new ProductosDAO();
            ImpuestosDianDAO impuestosDAO = new ImpuestosDianDAO();
            FacturasDAO facturasDAO = new FacturasDAO();
            DetalleFacturaDAO detalleFacturaDAO = new DetalleFacturaDAO();
            EstadosPagoDAO estadosPagoDAO = new EstadosPagoDAO();

            Pedido pedido = pedidoDAO.consultarPorId(idPedido, conn);
            if (pedido == null) {
                return;
            }

            List<DetallePedidos> todosDetalles = detallePedidosDAO.consultar(conn);
            List<DetallePedidos> lineasPedido = new ArrayList<>();
            if (todosDetalles != null) {
                for (DetallePedidos d : todosDetalles) {
                    if (d.getPedidos_id_pedidos() == idPedido) {
                        lineasPedido.add(d);
                    }
                }
            }
            if (lineasPedido.isEmpty()) {
                return;
            }

            Map<Integer, Productos> mapaProductos = mapaProductos(productosDAO.consultar(conn));
            Map<Integer, BigDecimal> mapaPorcentajeImpuesto = mapaPorcentajesImpuesto(impuestosDAO.consultarTodos(conn));

            BigDecimal subtotal = BigDecimal.ZERO;
            BigDecimal totalImpuestos = BigDecimal.ZERO;
            Map<Integer, BigDecimal> ivaPorLinea = new HashMap<>();

            for (DetallePedidos linea : lineasPedido) {
                BigDecimal precio = linea.getPrecio_unitario() != null ? linea.getPrecio_unitario() : BigDecimal.ZERO;
                BigDecimal totalLinea = precio.multiply(BigDecimal.valueOf(linea.getCantidades()));
                subtotal = subtotal.add(totalLinea);

                BigDecimal porcentaje = BigDecimal.ZERO;
                Productos producto = mapaProductos.get(linea.getProductos_id_productos());
                if (producto != null) {
                    BigDecimal pct = mapaPorcentajeImpuesto.get(producto.getImpuestos_dian_id_impuestos_dian());
                    if (pct != null) {
                        porcentaje = pct;
                    }
                }
                BigDecimal ivaLinea = totalLinea.multiply(porcentaje)
                        .divide(BigDecimal.valueOf(100), 2, java.math.RoundingMode.HALF_UP);
                ivaPorLinea.put(linea.getId_detalle_pedido(), ivaLinea);
                totalImpuestos = totalImpuestos.add(ivaLinea);
            }

            BigDecimal total = subtotal.add(totalImpuestos);

            int idEstadoPendientePago = resolverIdEstadoPagoPorNombre(
                    estadosPagoDAO.consultarTodos(conn), "pendiente", 1);

            Facturas nuevaFactura = new Facturas();
            nuevaFactura.setNumeros_factura("FAC-" + idPedido + "-" + System.currentTimeMillis());
            nuevaFactura.setFechas_factura(LocalDate.now());
            nuevaFactura.setSubtotales(subtotal);
            nuevaFactura.setImpuestos(totalImpuestos);
            nuevaFactura.setTotales(total);
            nuevaFactura.setPedidos_id_pedidos(idPedido);
            nuevaFactura.setEstados_pago_id_estados_pago(idEstadoPendientePago);

            boolean facturaCreada = facturasDAO.insertar(nuevaFactura, conn);

            if (facturaCreada) {
                int idFacturaNueva = -1;
                List<Facturas> facturasActuales = facturasDAO.consultar(conn);
                if (facturasActuales != null) {
                    for (Facturas f : facturasActuales) {
                        if (f.getPedidos_id_pedidos() == idPedido && f.getId_facturas() > idFacturaNueva) {
                            idFacturaNueva = f.getId_facturas();
                        }
                    }
                }

                if (idFacturaNueva > 0) {
                    for (DetallePedidos linea : lineasPedido) {
                        DetalleFactura detalleFactura = new DetalleFactura();
                        detalleFactura.setCantidades(linea.getCantidades());
                        detalleFactura.setPrecios_unitarios_facturados(
                                linea.getPrecio_unitario() != null ? linea.getPrecio_unitario() : BigDecimal.ZERO);
                        detalleFactura.setValores_iva_lineas(
                                ivaPorLinea.getOrDefault(linea.getId_detalle_pedido(), BigDecimal.ZERO));
                        detalleFactura.setFacturas_id_facturas(idFacturaNueva);
                        detalleFactura.setDetalle_pedidos_id_detalle_pedidos(linea.getId_detalle_pedido());

                        detalleFacturaDAO.insertar(detalleFactura, conn);
                    }
                }
            }

        } catch (Exception e) {
            System.err.println("Error al generar la factura: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Registra el pago, actualiza el estado del pedido a pagado, e interrumpe la ocupación de la mesa vinculada haciéndola Libre (ID: 1).
     */
    private void registrarPago(HttpServletRequest request) {
        try (Connection conn = Conexion.getConnection()) {
            int idFactura = Integer.parseInt(request.getParameter("id_factura"));
            int idMetodoPago = Integer.parseInt(request.getParameter("metodos_pago_id_metodos_pago"));

            PagosDAO pagosDAO = new PagosDAO();
            FacturasDAO facturasDAO = new FacturasDAO();
            EstadosPagoDAO estadosPagoDAO = new EstadosPagoDAO();
            PedidoDAO pedidoDAO = new PedidoDAO();
            MesasDAO mesasDAO = new MesasDAO();
            EstadosPedidosDAO estadosPedidosDAO = new EstadosPedidosDAO();

            // Cálculo dinámico del siguiente ID de Pago para PagosDAO
            int siguienteIdPago = 1;
            List<Pago> pagosActuales = pagosDAO.consultarTodos(conn);
            if (pagosActuales != null) {
                for (Pago p : pagosActuales) {
                    if (p.getId_pago() >= siguienteIdPago) {
                        siguienteIdPago = p.getId_pago() + 1;
                    }
                }
            }

            Pago nuevoPago = new Pago();
            nuevoPago.setId_pago(siguienteIdPago);
            nuevoPago.setFacturas_id_facturas(idFactura);
            nuevoPago.setMetodos_pago_id_metodos_pago(idMetodoPago);

            boolean pagoInsertado = pagosDAO.insertarPago(nuevoPago, conn);

            if (pagoInsertado) {
                // Se marca la factura como pagada
                int idEstadoPagado = resolverIdEstadoPagoPorNombre(
                        estadosPagoDAO.consultarTodos(conn), "pagad", -1);
                if (idEstadoPagado > 0) {
                    facturasDAO.cambiarEstadoPago(idFactura, idEstadoPagado, conn);
                }

                // Actualizar el estado del pedido a Pagado y liberación automática de la mesa asociada
                Facturas factura = facturasDAO.consultarPorId(idFactura, conn);
                if (factura != null) {
                    Pedido pedido = pedidoDAO.consultarPorId(factura.getPedidos_id_pedidos(), conn);
                    if (pedido != null) {
                        // Cambiar el estado del pedido a Pagado para que se refleje con el mesero
                        int idEstadoPedidoPagado = resolverIdEstadoPedidoPorNombrePedido(
                                estadosPedidosDAO.consultarTodos(conn), "pagad", -1);
                        if (idEstadoPedidoPagado > 0) {
                            pedido.setEstados_pedidos_id_estados_pedidos(idEstadoPedidoPagado);
                            pedidoDAO.actualizar(pedido, conn);
                        }

                        // Liberar la mesa asociada al pedido
                        if (pedido.getMesas_id_mesas() != null) {
                            int idMesa = pedido.getMesas_id_mesas();
                            Mesas mesa = mesasDAO.consultarMesa(idMesa, conn);
                            if (mesa == null) {
                                mesa = mesasDAO.consultarPorId(idMesa, conn);
                            }
                            if (mesa != null) {
                                mesa.setEstados_mesa_id_estados_mesa(1); // 1 = Libre / Disponible
                                boolean liberado = mesasDAO.actualizarMesa(mesa, conn);
                                if (!liberado) {
                                    mesasDAO.actualizar(mesa, conn);
                                }
                            }
                        }
                    }
                }
            }

        } catch (Exception e) {
            System.err.println("Error al registrar el pago: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private Map<Integer, Productos> mapaProductos(List<Productos> productos) {
        Map<Integer, Productos> mapa = new HashMap<>();
        if (productos != null) {
            for (Productos p : productos) {
                mapa.put(p.getId_productos(), p);
            }
        }
        return mapa;
    }

    private Map<Integer, BigDecimal> mapaPorcentajesImpuesto(List<ImpuestosDian> impuestos) {
        Map<Integer, BigDecimal> mapa = new HashMap<>();
        if (impuestos != null) {
            for (ImpuestosDian i : impuestos) {
                mapa.put(i.getId_impuestos_dian(), i.getPorcentajes() != null ? i.getPorcentajes() : BigDecimal.ZERO);
            }
        }
        return mapa;
    }

    private int resolverIdEstadoPagoPorNombre(List<EstadosPago> estados, String nombreBuscado, int valorPorDefecto) {
        if (estados != null) {
            for (EstadosPago e : estados) {
                if (e.getNombres_estados_pago() != null
                        && e.getNombres_estados_pago().trim().toLowerCase().contains(nombreBuscado)) {
                    return e.getId_estados_pago();
                }
            }
        }
        return valorPorDefecto;
    }

    private int resolverIdEstadoPedidoPorNombrePedido(List<EstadoPedido> estados, String nombreBuscado, int valorPorDefecto) {
        if (estados != null) {
            for (EstadoPedido e : estados) {
                if (e.getNombres_estado_pedidos() != null
                        && e.getNombres_estado_pedidos().trim().toLowerCase().contains(nombreBuscado)) {
                    return e.getId_estados_pedidos();
                }
            }
        }
        return valorPorDefecto;
    }

    private boolean esRol(Usuarios usuario, String nombreEsperado) {
        try {
            RolesDAO rolesDAO = new RolesDAO();
            Roles rol = rolesDAO.consultarRol(usuario.getRoles_id_roles());
            return rol != null && rol.getNombre_rol() != null
                    && rol.getNombre_rol().trim().equalsIgnoreCase(nombreEsperado);
        } catch (Exception e) {
            return false;
        }
    }
}