package Modelo;

public class EstadosMesa {

    private int id_estados_mesa;
    private String nombre_estado;

    public EstadosMesa() {
    }

    public EstadosMesa(int id_estados_mesa, String nombre_estado) {
        this.id_estados_mesa = id_estados_mesa;
        this.nombre_estado = nombre_estado;
    }

    public int getId_estados_mesa() {
        return id_estados_mesa;
    }

    public void setId_estados_mesa(int id_estados_mesa) {
        this.id_estados_mesa = id_estados_mesa;
    }

    public String getNombre_estado() {
        return nombre_estado;
    }

    public void setNombre_estado(String nombre_estado) {
        this.nombre_estado = nombre_estado;
    }
}