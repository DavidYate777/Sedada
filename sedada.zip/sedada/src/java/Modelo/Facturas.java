package Modelo;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Facturas {

    private int id_facturas;
    private String numeros_factura;
    private LocalDate fechas_factura;
    private BigDecimal subtotales;
    private BigDecimal impuestos;
    private BigDecimal totales;
    private int pedidos_id_pedidos;
    private int estados_pago_id_estados_pago;

    public Facturas() {
    }

    public Facturas(int id_facturas, String numeros_factura, LocalDate fechas_factura, BigDecimal subtotales, BigDecimal impuestos, BigDecimal totales, int pedidos_id_pedidos, int estados_pago_id_estados_pago) {
        this.id_facturas = id_facturas;
        this.numeros_factura = numeros_factura;
        this.fechas_factura = fechas_factura;
        this.subtotales = subtotales;
        this.impuestos = impuestos;
        this.totales = totales;
        this.pedidos_id_pedidos = pedidos_id_pedidos;
        this.estados_pago_id_estados_pago = estados_pago_id_estados_pago;
    }

    // Getters y Setters Principales
    public int getId_facturas() {
        return id_facturas;
    }

    public void setId_facturas(int id_facturas) {
        this.id_facturas = id_facturas;
    }

    public String getNumeros_factura() {
        return numeros_factura;
    }

    public void setNumeros_factura(String numeros_factura) {
        this.numeros_factura = numeros_factura;
    }

    public LocalDate getFechas_factura() {
        return fechas_factura;
    }

    public void setFechas_factura(LocalDate fechas_factura) {
        this.fechas_factura = fechas_factura;
    }

    public BigDecimal getSubtotales() {
        return subtotales;
    }

    public void setSubtotales(BigDecimal subtotales) {
        this.subtotales = subtotales;
    }

    public BigDecimal getImpuestos() {
        return impuestos;
    }

    public void setImpuestos(BigDecimal impuestos) {
        this.impuestos = impuestos;
    }

    public BigDecimal getTotales() {
        return totales;
    }

    public void setTotales(BigDecimal totales) {
        this.totales = totales;
    }

    public int getPedidos_id_pedidos() {
        return pedidos_id_pedidos;
    }

    public void setPedidos_id_pedidos(int pedidos_id_pedidos) {
        this.pedidos_id_pedidos = pedidos_id_pedidos;
    }

    public int getEstados_pago_id_estados_pago() {
        return estados_pago_id_estados_pago;
    }

    public void setEstados_pago_id_estados_pago(int estados_pago_id_estados_pago) {
        this.estados_pago_id_estados_pago = estados_pago_id_estados_pago;
    }

    // --- MÉTODOS ALIAS DE COMPATIBILIDAD CON VISTAS JSP ---
    // Permiten llamadas getNumero_facturas() y getFechas_facturas() en admin_facturas.jsp sin generar error
    public String getNumero_facturas() {
        return getNumeros_factura();
    }

    public LocalDate getFechas_facturas() {
        return getFechas_factura();
    }
}