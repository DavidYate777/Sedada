<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuarios" %>
<%@ page import="Modelo.Mesas" %>
<%@ page import="Modelo.Productos" %>
<%@ page import="Modelo.Pedido" %>
<%@ page import="Modelo.DetallePedidos" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%
    Usuarios user = (Usuarios) session.getAttribute("usuarioLogueado");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }

    List<Mesas> todasLasMesas = (List<Mesas>) request.getAttribute("todasLasMesas");
    List<Mesas> mesasDisponibles = (List<Mesas>) request.getAttribute("mesasDisponibles");
    List<Productos> productosActivos = (List<Productos>) request.getAttribute("productosActivos");
    Map<Integer, String> mapaCategorias = (Map<Integer, String>) request.getAttribute("mapaCategorias");
    Map<Integer, Productos> mapaProductos = (Map<Integer, Productos>) request.getAttribute("mapaProductos");
    Map<Integer, String> mapaEstadosPedido = (Map<Integer, String>) request.getAttribute("mapaEstadosPedido");
    List<Pedido> pedidosPropios = (List<Pedido>) request.getAttribute("pedidosPropios");
    Map<Integer, List<DetallePedidos>> detallesPorPedido = (Map<Integer, List<DetallePedidos>>) request.getAttribute("detallesPorPedido");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plano de Mesas y Toma de Pedidos - SEDADA</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Archivo CSS centralizado -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">
    <style>
        .card-mesa {
            transition: transform 0.15s ease-in-out, shadow 0.15s ease-in-out;
            cursor: pointer;
            border: 2px solid transparent;
        }
        .card-mesa:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.08) !important;
        }
        .card-mesa.estado-libre { border-color: #28a745; }
        .card-mesa.estado-ocupada { border-color: #0d6efd; }
        .card-mesa.estado-cuenta { border-color: #ffc107; }
        .badge-libre { background-color: #e8f5e9; color: #2e7d32; }
        .badge-ocupada { background-color: #e3f2fd; color: #1565c0; }
        .badge-cuenta { background-color: #fff8e1; color: #f57f17; }
    </style>
</head>
<body class="admin-body bg-light">

    <!-- Menú Lateral -->
    <div class="admin-sidebar">
        <div class="brand d-flex align-items-center gap-2">
            <div class="bg-dark text-white rounded p-1 px-2 fw-bold" style="font-size: 0.8rem;">SD</div>
            <div>
                <div style="line-height: 1.2;">SEDADA</div>
                <small class="text-muted fw-normal" style="font-size: 0.70rem;">MESERO OPS</small>
            </div>
        </div>

        <div class="px-2 mt-2 flex-grow-1">
            <div class="text-muted px-3 mb-1" style="font-size: 0.65rem; letter-spacing: 0.5px;">MENÚ PRINCIPAL</div>
            <ul class="nav flex-column gap-1">
                <li class="nav-item">
                    <a href="${pageContext.request.contextPath}/mesero/dashboard" class="nav-link">
                        <i class="fa-solid fa-shapes me-1"></i> Resumen
                    </a>
                </li>
                <li class="nav-item">
                    <a href="${pageContext.request.contextPath}/mesero/pedidos" class="nav-link active">
                        <i class="fa-solid fa-cart-shopping me-1"></i> Tomar Pedidos
                    </a>
                </li>
            </ul>
        </div>

        <div class="p-3 border-top">
            <a href="${pageContext.request.contextPath}/LoginServlet?accion=logout" class="nav-link text-danger">
                <i class="fa-solid fa-right-from-bracket me-1"></i> Cerrar Sesión
            </a>
        </div>
    </div>

    <!-- Área de Contenido Principal -->
    <div class="admin-main-content">

        <!-- Barra Superior -->
        <div class="admin-top-navbar mb-3 d-flex justify-content-between align-items-center">
            <div class="text-muted small">SEDADA / Gestión de Salón / <span class="text-dark fw-semibold">Plano de Mesas</span></div>
            <div class="d-flex align-items-center gap-3">
                <div class="d-flex align-items-center gap-2 border-start ps-3">
                    <div class="bg-dark text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 32px; height: 32px; font-size: 0.8rem;">
                        <%= user.getNombre_usuarios().substring(0, 1).toUpperCase() %>
                    </div>
                    <div>
                        <span class="fw-semibold text-dark small d-block" style="line-height: 1;"><%= user.getNombre_usuarios() %></span>
                        <small class="text-muted" style="font-size: 0.7rem;">Mesero Activo</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Encabezado y Métricas Rápidas -->
        <div class="card border-0 shadow-sm p-3 mb-4 bg-white rounded-3">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                <div>
                    <h4 class="fw-bold m-0" style="font-size: 1.3rem;"><i class="fa-solid fa-chair text-primary me-2"></i>Plano de Mesas · Salón Principal</h4>
                    <p class="text-muted small m-0">Seleccione una mesa disponible para abrir una nueva comanda o revise las comandas en curso.</p>
                </div>
                <button class="btn btn-primary btn-sm fw-semibold px-3 py-2" data-bs-toggle="modal" data-bs-target="#modalNuevoPedido">
                    <i class="fa-solid fa-plus me-1"></i> Abrir Nueva Comanda
                </button>
            </div>
        </div>

        <!-- Rejilla de Mesas (Plano de Mesas) -->
        <div class="row g-3 mb-4">
            <%
                if (todasLasMesas != null && !todasLasMesas.isEmpty()) {
                    for (Mesas m : todasLasMesas) {
                        boolean esDisponible = m.getEstados_mesa_id_estados_mesa() == 1; // 1 = Libre/Disponible
                        boolean esOcupada = m.getEstados_mesa_id_estados_mesa() == 2;    // 2 = Ocupada
                        String claseEstado = esDisponible ? "estado-libre" : (esOcupada ? "estado-ocupada" : "estado-cuenta");
                        String badgeEstado = esDisponible ? "badge-libre" : (esOcupada ? "badge-ocupada" : "badge-cuenta");
                        String textoEstado = esDisponible ? "Libre" : (esOcupada ? "Ocupada" : "Por Cobrar");
            %>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <div class="card card-mesa <%= claseEstado %> shadow-sm rounded-3 p-3 bg-white h-100" 
                     <% if(esDisponible) { %> onclick="seleccionarMesaParaPedido(<%= m.getId_mesas() %>)" <% } %>>
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="fw-bold fs-5 text-dark">Mesa <%= m.getNumero_mesas() %></span>
                        <span class="badge <%= badgeEstado %> px-2 py-1" style="font-size: 0.68rem;"><%= textoEstado %></span>
                    </div>
                    <div class="text-muted small mb-2">
                        <i class="fa-solid fa-users me-1"></i> Cap: <%= m.getCapacidades() %> p.
                    </div>
                    <div class="mt-auto pt-2 border-top text-end">
                        <% if(esDisponible) { %>
                            <span class="small text-primary fw-semibold"><i class="fa-solid fa-circle-plus me-1"></i>Abrir</span>
                        <% } else { %>
                            <span class="small text-secondary fw-semibold"><i class="fa-solid fa-lock me-1"></i>En servicio</span>
                        <% } %>
                    </div>
                </div>
            </div>
            <%
                    }
                } else if (mesasDisponibles != null && !mesasDisponibles.isEmpty()) {
                    for (Mesas m : mesasDisponibles) {
            %>
            <div class="col-6 col-sm-4 col-md-3 col-lg-2">
                <div class="card card-mesa estado-libre shadow-sm rounded-3 p-3 bg-white h-100" onclick="seleccionarMesaParaPedido(<%= m.getId_mesas() %>)">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="fw-bold fs-5 text-dark">Mesa <%= m.getNumero_mesas() %></span>
                        <span class="badge badge-libre px-2 py-1" style="font-size: 0.68rem;">Libre</span>
                    </div>
                    <div class="text-muted small mb-2"><i class="fa-solid fa-users me-1"></i> Cap: <%= m.getCapacidades() %> p.</div>
                    <div class="mt-auto pt-2 border-top text-end">
                        <span class="small text-primary fw-semibold"><i class="fa-solid fa-circle-plus me-1"></i>Abrir</span>
                    </div>
                </div>
            </div>
            <%      }
                } else { %>
            <div class="col-12">
                <div class="alert alert-info border-0 shadow-sm rounded-3">No hay información de mesas disponible en este momento.</div>
            </div>
            <% } %>
        </div>

        <!-- Seccion Comandas Activas del Turno -->
        <h5 class="fw-bold mb-3 text-dark"><i class="fa-solid fa-receipt me-2"></i>Comandas Registradas en Tu Turno</h5>
        <div class="row g-3">
            <%
                if (pedidosPropios != null && !pedidosPropios.isEmpty()) {
                    for (Pedido p : pedidosPropios) {
                        List<DetallePedidos> lineas = detallesPorPedido != null ? detallesPorPedido.get(p.getId_pedidos()) : null;
                        java.math.BigDecimal totalPedido = java.math.BigDecimal.ZERO;
                        if (lineas != null) {
                            for (DetallePedidos d : lineas) {
                                if (d.getPrecio_unitario() != null) {
                                    totalPedido = totalPedido.add(d.getPrecio_unitario().multiply(java.math.BigDecimal.valueOf(d.getCantidades())));
                                }
                            }
                        }
                        String nombreEstado = mapaEstadosPedido != null ? mapaEstadosPedido.get(p.getEstados_pedidos_id_estados_pedidos()) : null;
                        if (nombreEstado == null) nombreEstado = "Estado #" + p.getEstados_pedidos_id_estados_pedidos();
            %>
            <div class="col-md-6 col-lg-4">
                <div class="card border-0 shadow-sm p-3 bg-white h-100 rounded-3 d-flex flex-column">
                    <div class="d-flex justify-content-between align-items-start border-bottom pb-2 mb-2">
                        <div>
                            <span class="badge bg-dark text-white fw-bold px-2 py-1">
                                <%= p.getMesas_id_mesas() != null ? "Mesa " + p.getMesas_id_mesas() : "Domicilio" %>
                            </span>
                            <div class="text-muted mt-1" style="font-size: 0.75rem;"><i class="fa-regular fa-clock me-1"></i> <%= p.getFecha_horas() != null ? p.getFecha_horas().toString() : "Reciente" %></div>
                        </div>
                        <% 
                            boolean esPagado = nombreEstado != null && nombreEstado.toLowerCase().contains("pagad");
                            String claseBadge = esPagado ? "bg-success bg-opacity-10 text-success border-success" : "bg-warning bg-opacity-10 text-warning border";
                        %>
                        <span class="badge <%= claseBadge %> px-2 py-1 small">
                            <%= nombreEstado %>
                        </span>
                    </div>

                    <div class="mb-3 small flex-grow-1" style="max-height: 150px; overflow-y: auto;">
                        <% if (lineas != null && !lineas.isEmpty()) {
                            for (DetallePedidos d : lineas) {
                                Productos prod = mapaProductos != null ? mapaProductos.get(d.getProductos_id_productos()) : null;
                                String nombreProd = prod != null ? prod.getNombres_productos() : "Producto #" + d.getProductos_id_productos();
                        %>
                        <div class="d-flex justify-content-between py-1 border-bottom border-light">
                            <span class="text-dark"><%= d.getCantidades() %>x <%= nombreProd %></span>
                            <span class="text-muted fw-semibold">$<%= d.getPrecio_unitario() != null ? d.getPrecio_unitario().multiply(java.math.BigDecimal.valueOf(d.getCantidades())) : "0" %></span>
                        </div>
                        <% if (d.getNotas_especiales() != null && !d.getNotas_especiales().isBlank()) { %>
                        <div class="text-muted fst-italic mb-1" style="font-size: 0.72rem;"><i class="fa-regular fa-comment-dots me-1"></i>Nota: <%= d.getNotas_especiales() %></div>
                        <% } %>
                        <% } } else { %>
                        <span class="text-muted fst-italic">Sin productos detallados.</span>
                        <% } %>
                    </div>

                    <div class="d-flex justify-content-between align-items-center pt-2 border-top mt-auto">
                        <span class="fw-bold text-dark small">Comanda #COM-<%= p.getId_pedidos() %></span>
                        <span class="fw-bold text-primary fs-6">$<%= totalPedido %></span>
                    </div>
                </div>
            </div>
            <%
                    }
                } else {
            %>
            <div class="col-12">
                <div class="card border-0 bg-white p-4 text-center text-muted rounded-3 shadow-sm">
                    <i class="fa-solid fa-utensils fs-2 mb-2 text-secondary opacity-50"></i>
                    <p class="small mb-0">No hay comandas registradas en este turno. Seleccione una mesa disponible arriba para empezar.</p>
                </div>
            </div>
            <% } %>
        </div>

    </div>

    <!-- Modal Nuevo Pedido / Comanda -->
    <div class="modal fade" id="modalNuevoPedido" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content border-0 shadow">
                <form action="${pageContext.request.contextPath}/mesero/pedidos" method="POST" id="formNuevoPedido">
                    <input type="hidden" name="accion" value="insertar_pedido">
                    <div class="modal-header bg-dark text-white">
                        <h5 class="modal-title fw-bold fs-6"><i class="fa-solid fa-receipt me-2"></i>Registrar Comanda</h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body small">

                        <!-- Tipo de Pedido -->
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Tipo de Servicio</label>
                            <div class="d-flex gap-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="tipo_pedido" id="tipoMesa" value="mesa" checked onclick="toggleTipoPedido()">
                                    <label class="form-check-label fw-semibold" for="tipoMesa">Mesa (Salón)</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="tipo_pedido" id="tipoDomicilio" value="domicilio" onclick="toggleTipoPedido()">
                                    <label class="form-check-label fw-semibold" for="tipoDomicilio">Domicilio</label>
                                </div>
                            </div>
                        </div>

                        <!-- Selección de Mesa -->
                        <div id="seccionMesa" class="mb-3">
                            <label class="form-label fw-semibold">Mesa Asignada</label>
                            <select class="form-select form-select-sm" name="mesas_id_mesas" id="selectMesas">
                                <% if (mesasDisponibles != null && !mesasDisponibles.isEmpty()) {
                                    for (Mesas m : mesasDisponibles) { %>
                                <option value="<%= m.getId_mesas() %>">Mesa <%= m.getNumero_mesas() %> (<%= m.getCapacidades() %> personas)</option>
                                <% } } else { %>
                                <option value="">No hay mesas libres actualmente</option>
                                <% } %>
                            </select>
                        </div>

                        <!-- Sección Domicilio -->
                        <div id="seccionDomicilio" class="mb-3" style="display: none;">
                            <label class="form-label fw-semibold">Dirección de Entrega</label>
                            <input type="text" class="form-control form-control-sm mb-2" name="direccion_entrega" placeholder="Ej. Calle Principal #123">
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-semibold">Teléfono de Contacto</label>
                            <input type="text" class="form-control form-control-sm" name="telefono_contacto" placeholder="Ej. 3001234567">
                        </div>

                        <hr class="my-3">

                        <!-- Catálogo de Productos -->
                        <label class="form-label fw-semibold">Seleccionar Platos / Productos</label>
                        <div style="max-height: 280px; overflow-y: auto;">
                            <table class="table table-sm align-middle">
                                <thead class="bg-light sticky-top">
                                    <tr class="text-muted" style="font-size: 0.75rem;">
                                        <th>Producto</th>
                                        <th style="width: 100px;">Cantidad</th>
                                        <th>Notas / Término</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <% if (productosActivos != null && !productosActivos.isEmpty()) {
                                        for (Productos prod : productosActivos) {
                                            String nombreCategoria = mapaCategorias != null ? mapaCategorias.get(prod.getCategorias_id_categorias()) : null;
                                    %>
                                    <tr>
                                        <td>
                                            <div class="fw-semibold text-dark"><%= prod.getNombres_productos() %></div>
                                            <div class="text-muted" style="font-size: 0.7rem;">
                                                <%= nombreCategoria != null ? nombreCategoria : "General" %> · $<%= prod.getPrecios() %>
                                            </div>
                                            <input type="hidden" name="producto_id" value="<%= prod.getId_productos() %>">
                                        </td>
                                        <td>
                                            <input type="number" min="0" value="0" class="form-control form-control-sm text-center" name="cantidad">
                                        </td>
                                        <td>
                                            <input type="text" class="form-control form-control-sm" name="nota" placeholder="Ej. Sin cebolla, término 3/4">
                                        </td>
                                    </tr>
                                    <% } } else { %>
                                    <tr>
                                        <td colspan="3" class="text-muted text-center py-3">No hay productos disponibles en el menú.</td>
                                    </tr>
                                    <% } %>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer bg-light">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary btn-sm fw-semibold"><i class="fa-solid fa-paper-plane me-1"></i> Enviar Comanda</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleTipoPedido() {
            var esMesa = document.getElementById('tipoMesa').checked;
            document.getElementById('seccionMesa').style.display = esMesa ? 'block' : 'none';
            document.getElementById('seccionDomicilio').style.display = esMesa ? 'none' : 'block';
        }

        function seleccionarMesaParaPedido(idMesa) {
            var select = document.getElementById('selectMesas');
            if (select) {
                select.value = idMesa;
            }
            var modal = new bootstrap.Modal(document.getElementById('modalNuevoPedido'));
            modal.show();
        }
    </script>
</body>
</html>