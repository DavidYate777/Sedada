<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SEDADA - Sistema de Gestión de Restaurantes</title>
    
    <!-- Enlace a tu CSS personalizado -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">
    <!-- FontAwesome para Iconos -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Fuente Inter -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>

    <!-- NAVBAR -->
    <header class="sd-header">
        <div class="sd-container sd-nav-content">
            <a href="${pageContext.request.contextPath}/home" class="sd-logo">
                <span class="sd-logo-icon"><i class="fa-solid fa-utensils"></i></span>
                <span>SEDADA</span>
            </a>
            
            <ul class="sd-nav-links">
                <li><a href="#inicio">¿Qué es SEDADA?</a></li>
                <li><a href="#funciones">Para tu restaurante</a></li>
                <li><a href="#circuito">POS & Local</a></li>
                <li><a href="#arquitectura">Plataforma Integral</a></li>
                <li><a href="#roles">Beneficios</a></li>
            </ul>

            <div>
                <%-- Integración con HomeServlet: evalúa si el usuario inició sesión --%>
                <c:choose>
                    <c:when test="${not empty usuarioLogueado}">
                        <a href="${pageContext.request.contextPath}/AdminDashboardServlet" class="sd-btn-primary">
                            <i class="fa-solid fa-user-circle"></i>
                            <span>Mi Panel</span>
                        </a>
                    </c:when>
                    <c:otherwise>
                        <a href="${pageContext.request.contextPath}/login.jsp" class="sd-btn-primary">
                            <i class="fa-solid fa-right-to-bracket"></i>
                            <span>Iniciar Sesión</span>
                        </a>
                    </c:otherwise>
                </c:choose>
            </div>
        </div>
    </header>

    <!-- HERO SECTION -->
    <section id="inicio" class="sd-hero">
        <div class="sd-container sd-hero-grid">
            <div>
                <span class="sd-tag"><i class="fa-solid fa-sparkles"></i> Sistema de Gestión Restaurantera</span>
                <h1 class="sd-hero-title">Gestión automatizada de tu local</h1>
                <p class="sd-hero-desc">
                    El sistema inteligente de gestión que optimiza el flujo en tu restaurante, desde comandas rápidas hasta control de inventario y caja sin descuadres.
                </p>
                <div class="sd-hero-actions">
                    <c:choose>
                        <c:when test="${not empty usuarioLogueado}">
                            <a href="${pageContext.request.contextPath}/AdminDashboardServlet" class="sd-btn-primary">
                                <i class="fa-solid fa-gauge-high"></i>
                                <span>Ir al Dashboard</span>
                            </a>
                        </c:when>
                        <c:otherwise>
                            <a href="${pageContext.request.contextPath}/login.jsp" class="sd-btn-primary">
                                <i class="fa-solid fa-right-to-bracket"></i>
                                <span>Ingresar al Sistema</span>
                            </a>
                        </c:otherwise>
                    </c:choose>
                    <a href="#contacto" class="sd-btn-secondary">
                        <i class="fa-solid fa-building"></i>
                        <span>Registrar mi Local</span>
                    </a>
                </div>
            </div>

            <!-- MOCKUP TARJETA -->
            <div class="sd-preview-card">
                <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--sd-border); padding-bottom: 1rem; margin-bottom: 1.5rem;">
                    <div class="sd-logo">
                        <span class="sd-logo-icon"><i class="fa-solid fa-utensils"></i></span>
                        <div>
                            <div style="font-size: 1rem; font-weight: 800;">SEDADA</div>
                            <div style="font-size: 0.7rem; color: var(--sd-text-muted);">MANAGEMENT SYSTEM</div>
                        </div>
                    </div>
                    <span style="background-color: #dcfce7; color: #166534; padding: 0.2rem 0.6rem; border-radius: 9999px; font-size: 0.75rem; font-weight: 600;">En línea</span>
                </div>
                <div style="background-color: var(--sd-primary-light); padding: 2rem; border-radius: 12px; text-align: center; border: 1px solid #dbeafe;">
                    <i class="fa-solid fa-laptop-code" style="font-size: 2.5rem; color: var(--sd-primary); margin-bottom: 0.75rem;"></i>
                    <h4 style="margin: 0 0 0.25rem 0; font-weight: 700;">Configura tu Restaurante</h4>
                    <p style="margin: 0; font-size: 0.8rem; color: var(--sd-text-muted);">Administra mesas, menú e inventario desde un solo panel web.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- FUNCIONALIDADES PRINCIPALES -->
    <section id="funciones" class="sd-section sd-section-white">
        <div class="sd-container">
            <div class="sd-section-header">
                <span class="sd-subtitle">Aumenta la Eficiencia</span>
                <h2 class="sd-section-title">Control de punta a punta, sin comandas extraviadas ni descuadres</h2>
                <p style="color: var(--sd-text-muted);">SEDADA une tu personal de sala, cocina y caja en una plataforma intuitiva en tiempo real.</p>
            </div>

            <div class="sd-grid-4">
                <div class="sd-card">
                    <div class="sd-card-icon"><i class="fa-solid fa-bell"></i></div>
                    <h3 style="margin: 0 0 0.5rem 0; font-size: 1.1rem;">Comandas en Tiempo Real</h3>
                    <p style="font-size: 0.85rem; color: var(--sd-text-muted); margin: 0;">Toma de pedidos ágil desde tablets o smartphones con envío instantáneo a cocina.</p>
                </div>
                <div class="sd-card">
                    <div class="sd-card-icon"><i class="fa-solid fa-border-all"></i></div>
                    <h3 style="margin: 0 0 0.5rem 0; font-size: 1.1rem;">Control Digital de Mesas</h3>
                    <p style="font-size: 0.85rem; color: var(--sd-text-muted); margin: 0;">Visualiza el estado de las mesas en tiempo real (disponible, ocupada, por pagar).</p>
                </div>
                <div class="sd-card">
                    <div class="sd-card-icon"><i class="fa-solid fa-cash-register"></i></div>
                    <h3 style="margin: 0 0 0.5rem 0; font-size: 1.1rem;">Cierre de Caja sin Errores</h3>
                    <p style="font-size: 0.85rem; color: var(--sd-text-muted); margin: 0;">Control estricto de caja, formas de pago, propinas e informes para evitar descuadres.</p>
                </div>
                <div class="sd-card">
                    <div class="sd-card-icon"><i class="fa-solid fa-boxes-stacked"></i></div>
                    <h3 style="margin: 0 0 0.5rem 0; font-size: 1.1rem;">Gestión de Inventario</h3>
                    <p style="font-size: 0.85rem; color: var(--sd-text-muted); margin: 0;">Descuento automático de stock según los platillos consumidos cada día.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CIRCUITO OPERATIVO -->
    <section id="circuito" class="sd-section">
        <div class="sd-container">
            <div class="sd-section-header">
                <span class="sd-subtitle">Flujo de Trabajo</span>
                <h2 class="sd-section-title">¿Cómo funciona el circuito operativo en tu local?</h2>
            </div>

            <div class="sd-grid-4">
                <div class="sd-card">
                    <span class="sd-step-num">01</span>
                    <h4 style="margin: 0 0 0.5rem 0;">Toma de Pedidos en Mesa</h4>
                    <p style="font-size: 0.8rem; color: var(--sd-text-muted);">El mesero ingresa el pedido en el sistema seleccionando los ítems de la carta digital.</p>
                </div>
                <div class="sd-card">
                    <span class="sd-step-num">02</span>
                    <h4 style="margin: 0 0 0.5rem 0;">Cocina / Bar en Vivo</h4>
                    <p style="font-size: 0.8rem; color: var(--sd-text-muted);">La orden se refleja de inmediato en la pantalla de la cocina dividida por estaciones.</p>
                </div>
                <div class="sd-card">
                    <span class="sd-step-num">03</span>
                    <h4 style="margin: 0 0 0.5rem 0;">Servicio & Entrega</h4>
                    <p style="font-size: 0.8rem; color: var(--sd-text-muted);">El equipo de cocina notifica cuando el plato está listo para su entrega inmediata.</p>
                </div>
                <div class="sd-card">
                    <span class="sd-step-num">04</span>
                    <h4 style="margin: 0 0 0.5rem 0;">Cierre & Facturación</h4>
                    <p style="font-size: 0.8rem; color: var(--sd-text-muted);">El cajero emite la factura, registra los medios de pago y libera la mesa ocupada.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ROLES -->
    <section id="roles" class="sd-section sd-section-white">
        <div class="sd-container">
            <div class="sd-section-header">
                <span class="sd-subtitle">Adaptado a tu Equipo</span>
                <h2 class="sd-section-title">Una interfaz precisa para cada puesto de trabajo</h2>
            </div>

            <div class="sd-grid-4">
                <div class="sd-card">
                    <i class="fa-solid fa-user-gear" style="font-size: 1.5rem; color: var(--sd-primary); margin-bottom: 0.5rem;"></i>
                    <h4>Administración</h4>
                    <p style="font-size: 0.8rem; color: var(--sd-text-muted);">Control total de usuarios, inventario, ventas y parametrización.</p>
                </div>
                <div class="sd-card">
                    <i class="fa-solid fa-utensils" style="font-size: 1.5rem; color: var(--sd-primary); margin-bottom: 0.5rem;"></i>
                    <h4>Meseros y Sala</h4>
                    <p style="font-size: 0.8rem; color: var(--sd-text-muted);">Atención rápida de comandas en mesa y mapas visuales de mesas.</p>
                </div>
                <div class="sd-card">
                    <i class="fa-solid fa-fire-burner" style="font-size: 1.5rem; color: var(--sd-primary); margin-bottom: 0.5rem;"></i>
                    <h4>Cocinero / Chef</h4>
                    <p style="font-size: 0.8rem; color: var(--sd-text-muted);">Pantalla de comandas en tiempo real para preparación y despacho.</p>
                </div>
                <div class="sd-card">
                    <i class="fa-solid fa-cash-register" style="font-size: 1.5rem; color: var(--sd-primary); margin-bottom: 0.5rem;"></i>
                    <h4>Cajero / Cobro</h4>
                    <p style="font-size: 0.8rem; color: var(--sd-text-muted);">Facturación rápida, arqueo de caja y registro de medios de pago.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ESTADÍSTICAS -->
    <section class="sd-section">
        <div class="sd-container sd-stats-grid">
            <div>
                <div class="sd-stat-num">+38%</div>
                <div class="sd-stat-label">Eficiencia en Mesas</div>
            </div>
            <div>
                <div class="sd-stat-num">0</div>
                <div class="sd-stat-label">Comandas Perdidas</div>
            </div>
            <div>
                <div class="sd-stat-num">100%</div>
                <div class="sd-stat-label">Precisión en Caja</div>
            </div>
            <div>
                <div class="sd-stat-num">&lt; 0.3s</div>
                <div class="sd-stat-label">Sincronización Cloud</div>
            </div>
        </div>
    </section>

    <!-- BANNER CTA -->
    <section id="contacto" class="sd-container" style="margin-bottom: 4rem;">
        <div class="sd-cta-box">
            <h2 style="font-size: 2rem; margin-bottom: 1rem;">Transforma la operación de tu restaurante hoy mismo</h2>
            <p style="font-size: 0.9rem; max-width: 600px; margin: 0 auto 2rem; color: #dbeafe;">Ingresa directamente si ya cuentas con tu usuario asignado o accede con tus credenciales.</p>
            <a href="${pageContext.request.contextPath}/login.jsp" class="sd-btn-secondary" style="color: var(--sd-primary); font-weight: 700;">
                Ingresar al Sistema
            </a>
        </div>
    </section>

    <!-- FOOTER -->
    <footer class="sd-footer">
        <div class="sd-container">
            <div class="sd-footer-grid">
                <div>
                    <a href="#" class="sd-logo" style="color: white; margin-bottom: 1rem;">
                        <span class="sd-logo-icon"><i class="fa-solid fa-utensils"></i></span>
                        <span>SEDADA</span>
                    </a>
                    <p>Plataforma integral de gestión de restaurante para control de mesas, cocina, facturación y personal.</p>
                </div>
                <div>
                    <h5 style="color: white; margin: 0 0 1rem 0;">Módulos</h5>
                    <p><a href="${pageContext.request.contextPath}/login.jsp" style="color: inherit; text-decoration: none;">Administración</a></p>
                    <p><a href="${pageContext.request.contextPath}/login.jsp" style="color: inherit; text-decoration: none;">Meseros</a></p>
                    <p><a href="${pageContext.request.contextPath}/login.jsp" style="color: inherit; text-decoration: none;">Cocina</a></p>
                </div>
                <div>
                    <h5 style="color: white; margin: 0 0 1rem 0;">Sistema</h5>
                    <p><a href="#funciones" style="color: inherit; text-decoration: none;">Funcionalidades</a></p>
                    <p><a href="#circuito" style="color: inherit; text-decoration: none;">Flujo Operativo</a></p>
                </div>
                <div>
                    <h5 style="color: white; margin: 0 0 1rem 0;">Acceso</h5>
                    <p><a href="${pageContext.request.contextPath}/login.jsp" style="color: inherit; text-decoration: none;">Iniciar Sesión</a></p>
                </div>
            </div>
            <div class="sd-footer-bottom">
                <span>© 2026 SEDADA Management System. Todos los derechos reservados.</span>
                <span>Apache NetBeans JDK 17</span>
            </div>
        </div>
    </footer>

</body>
</html>