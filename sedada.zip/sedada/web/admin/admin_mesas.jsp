<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuarios" %>
<%@ page import="Modelo.Mesas" %>
<%@ page import="Modelo.EstadosMesa" %>
<%@ page import="java.util.List" %>
<%
    Usuarios user = (Usuarios) session.getAttribute("usuarioLogueado");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
    
    List<Mesas> listaMesas = (List<Mesas>) request.getAttribute("listaMesas");
    List<EstadosMesa> listaEstadosMesa = (List<EstadosMesa>) request.getAttribute("listaEstadosMesa");
    
    Integer totalMesas = (Integer) request.getAttribute("totalMesas");
    Long disponibles = (Long) request.getAttribute("disponibles");
    Long ocupadas = (Long) request.getAttribute("ocupadas");
    Long reservadas = (Long) request.getAttribute("reservadas");
    
    if (totalMesas == null) totalMesas = 0;
    if (disponibles == null) disponibles = 0L;
    if (ocupadas == null) ocupadas = 0L;
    if (reservadas == null) reservadas = 0L;
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Mesas - SEDADA Enterprise OPS</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Archivo CSS centralizado -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">
</head>
<body class="admin-body">

    <!-- Menú Lateral -->
    <div class="admin-sidebar">
        <div class="brand d-flex align-items-center gap-2">
            <div class="bg-dark text-white rounded p-1 px-2 fw-bold" style="font-size: 0.8rem;">SD</div>
            <div>
                <div style="line-height: 1.2;">SEDADA</div>
                <small class="text-muted fw-normal" style="font-size: 0.70rem;">ENTERPRISE OPS</small>
            </div>
        </div>
        
        <div class="px-2 mt-2 flex-grow-1">
            <div class="text-muted px-3 mb-1" style="font-size: 0.65rem; letter-spacing: 0.5px;">MAIN MENU</div>
            <ul class="nav flex-column gap-1">
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/admin_dashboard" class="nav-link"><i class="fa-solid fa-shapes"></i> Resumen</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/pedidos" class="nav-link"><i class="fa-solid fa-cart-shopping"></i> Pedidos</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/inventario" class="nav-link"><i class="fa-solid fa-boxes-stacked"></i> Inventario</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/mesas" class="nav-link active"><i class="fa-solid fa-chair"></i> Mesas</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/usuarios" class="nav-link"><i class="fa-solid fa-users"></i> Usuarios</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/categorias" class="nav-link"><i class="fa-solid fa-layer-group"></i> Categorías</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/facturas" class="nav-link"><i class="fa-solid fa-file-invoice-dollar"></i> Facturación e Impuestos</a></li>
            </ul>
        </div>

        <div class="p-3 border-top">
            <a href="#" class="nav-link mb-2"><i class="fa-solid fa-circle-question"></i> Soporte</a>
            <a href="${pageContext.request.contextPath}/LoginServlet?accion=logout" class="nav-link text-danger"><i class="fa-solid fa-right-from-bracket"></i> Cerrar Sesión</a>
        </div>
    </div>

    <!-- Área de Contenido Principal -->
    <div class="admin-main-content">
        
        <!-- Barra Superior -->
        <div class="admin-top-navbar mb-3">
            <div class="text-muted small">SEDADA / Operaciones / <span class="text-dark fw-semibold">Gestión de Mesas</span></div>
            <div class="position-relative">
                <i class="fa-solid fa-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted small"></i>
                <input type="text" class="form-control admin-search-box ps-5 text-muted small" placeholder="Buscar pedidos, mesas o inventario...">
            </div>
            <div class="d-flex align-items-center gap-3">
                <i class="fa-regular fa-bell text-secondary fs-6" style="cursor: pointer;"></i>
                <a href="${pageContext.request.contextPath}/perfil" class="text-secondary d-flex align-items-center text-decoration-none" title="Configuración de Perfil">
                    <i class="fa-solid fa-gear fs-6"></i>
                </a>
                <div class="d-flex align-items-center gap-2 border-start ps-3">
                    <div class="bg-dark text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 32px; height: 32px; font-size: 0.8rem;">
                        <%= user.getNombre_usuarios().substring(0, 1).toUpperCase() %>
                    </div>
                    <div>
                        <span class="fw-semibold text-dark small d-block" style="line-height: 1;"><%= user.getNombre_usuarios() %></span>
                        <small class="text-muted" style="font-size: 0.7rem;">SEDADA Central</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Módulo Header / Supabase Sync -->
        <div class="mb-2">
            <div class="text-muted small fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">MÓDULO DE SALA & SALÓN • <span class="text-success">Supabase Sync: Activo</span></div>
        </div>

        <!-- Encabezado de la Sección y Botones -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold m-0" style="font-size: 1.4rem;">Gestión de Mesas</h3>
                <p class="text-muted small m-0 mt-1">Administración, asignación y estado del salón en tiempo real.</p>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-outline-dark btn-sm fw-semibold bg-white px-3"><i class="fa-solid fa-download me-1"></i> Exportar Plano / Lista</button>
                <button class="btn btn-dark btn-sm fw-semibold px-3" data-bs-toggle="modal" data-bs-target="#modalNuevaMesa">
                    <i class="fa-solid fa-plus me-1"></i> Nueva Mesa
                </button>
            </div>
        </div>

        <!-- Tarjetas de Métricas de Mesas -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">TOTAL CAPACIDAD SALÓN</span>
                        <div class="bg-light p-2 rounded-2 text-primary"><i class="fa-solid fa-utensils"></i></div>
                    </div>
                    <h3 class="fw-bold m-0"><%= totalMesas %> <span class="text-muted fw-normal fs-6">mesas</span></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;"><i class="fa-solid fa-circle text-success me-1" style="font-size: 8px;"></i> DISPONIBLES</span>
                        <div class="bg-light p-2 rounded-2 text-success"><i class="fa-solid fa-check"></i></div>
                    </div>
                    <h3 class="fw-bold m-0"><%= disponibles %></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;"><i class="fa-solid fa-circle text-primary me-1" style="font-size: 8px;"></i> EN SERVICIO / OCUPADAS</span>
                        <div class="bg-light p-2 rounded-2 text-info"><i class="fa-solid fa-chair"></i></div>
                    </div>
                    <h3 class="fw-bold m-0"><%= ocupadas %></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;"><i class="fa-solid fa-circle text-warning me-1" style="font-size: 8px;"></i> PRE-CUENTA / OTRAS</span>
                        <div class="bg-light p-2 rounded-2 text-warning"><i class="fa-solid fa-triangle-exclamation"></i></div>
                    </div>
                    <h3 class="fw-bold m-0"><%= reservadas %></h3>
                </div>
            </div>
        </div>

        <!-- Cuadrícula de Tarjetas de Mesas -->
        <div class="row g-3">
            <% 
                if (listaMesas != null && !listaMesas.isEmpty()) {
                    for (Mesas m : listaMesas) {
                        String statusBadge = "";
                        String statusText = "";
                        int estadoId = m.getEstados_mesa_id_estados_mesa();
                        if (estadoId == 1) {
                            statusBadge = "bg-success text-success";
                            statusText = "Disponible";
                        } else if (estadoId == 2) {
                            statusBadge = "bg-primary text-primary";
                            statusText = "Ocupada";
                        } else if (estadoId == 3) {
                            statusBadge = "bg-warning text-warning";
                            statusText = "En Pre-cuenta";
                        } else {
                            statusBadge = "bg-secondary text-secondary";
                            statusText = "Libre";
                        }
            %>
            <div class="col-md-3">
                <div class="card border-0 shadow-sm p-3 position-relative rounded-3 bg-white h-100">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <div>
                            <span class="text-muted small fw-semibold">Mesa</span>
                            <h4 class="fw-bold m-0 text-dark">#0<%= m.getNumero_mesas() %></h4>
                            <small class="text-muted" style="font-size: 0.7rem;">Salón Principal</small>
                        </div>
                        <span class="badge <%= statusBadge %> bg-opacity-10 border border-opacity-25 py-1 px-2 small">
                            <i class="fa-solid fa-circle me-1" style="font-size: 5px;"></i> <%= statusText %>
                        </span>
                    </div>

                    <div class="my-3 py-2 border-top border-bottom small text-muted">
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <i class="fa-solid fa-users text-secondary"></i>
                            <span>Capacidad: <strong><%= m.getCapacidades() %> Personas</strong></span>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <i class="fa-solid fa-id-badge text-secondary"></i>
                            <span>Estado: <strong><%= statusText %></strong></span>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center pt-1 mt-auto">
                        <span class="fw-bold text-dark small">Mesa #0<%= m.getNumero_mesas() %></span>
                        <div class="d-flex gap-1">
                            <button class="btn btn-sm btn-outline-dark py-0 px-2" data-bs-toggle="modal" data-bs-target="#modalEditarMesa<%= m.getId_mesas() %>" title="Editar mesa">
                                <i class="fa-solid fa-pen"></i>
                            </button>
                            <a href="${pageContext.request.contextPath}/admin/mesas?accion=eliminar&id=<%= m.getId_mesas() %>" class="btn btn-sm btn-outline-danger py-0 px-2" onclick="return confirm('¿Está seguro de eliminar esta mesa?');" title="Eliminar mesa">
                                <i class="fa-solid fa-trash-can"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Editar Mesa -->
            <div class="modal fade" id="modalEditarMesa<%= m.getId_mesas() %>" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="${pageContext.request.contextPath}/admin/mesas" method="POST">
                            <input type="hidden" name="accion" value="actualizar">
                            <input type="hidden" name="id_mesas" value="<%= m.getId_mesas() %>">
                            <div class="modal-header">
                                <h5 class="modal-title fw-bold fs-6">Editar Mesa #0<%= m.getNumero_mesas() %></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body small">
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Número de Mesa</label>
                                    <input type="number" class="form-control form-control-sm" name="numero_mesas" value="<%= m.getNumero_mesas() %>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Capacidad (Personas)</label>
                                    <input type="number" class="form-control form-control-sm" name="capacidades" value="<%= m.getCapacidades() %>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Estado de la Mesa</label>
                                    <select class="form-select form-select-sm" name="estados_mesa_id_estados_mesa" required>
                                        <% 
                                            if (listaEstadosMesa != null) {
                                                for (EstadosMesa em : listaEstadosMesa) {
                                                    boolean esActual = (m.getEstados_mesa_id_estados_mesa() == em.getId_estados_mesa());
                                        %>
                                        <option value="<%= em.getId_estados_mesa() %>" <%= esActual ? "selected" : "" %>>
                                            <%= em.getNombre_estado() %>
                                        </option>
                                        <% 
                                                }
                                            } 
                                        %>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                                <button type="submit" class="btn btn-dark btn-sm">Guardar Cambios</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <% 
                    }
                } else {
            %>
            <div class="col-12">
                <div class="card border-0 bg-white p-5 text-center text-muted rounded-3 shadow-sm">
                    <i class="fa-solid fa-chair fs-1 mb-2 text-secondary"></i>
                    <h5 class="fw-bold text-dark">No hay mesas registradas</h5>
                    <p class="small mb-0">Utilice el botón "Nueva Mesa" para registrar la primera mesa en el sistema.</p>
                </div>
            </div>
            <% } %>
        </div>

    </div>

    <!-- Modal Nueva Mesa (Crear) -->
    <div class="modal fade" id="modalNuevaMesa" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="${pageContext.request.contextPath}/admin/mesas" method="POST">
                    <input type="hidden" name="accion" value="insertar">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold fs-6">Registrar Nueva Mesa</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body small">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Número de Mesa</label>
                            <input type="number" class="form-control form-control-sm" name="numero_mesas" placeholder="Ej. 1" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Capacidad (Personas)</label>
                            <input type="number" class="form-control form-control-sm" name="capacidades" placeholder="Ej. 4" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Estado Inicial</label>
                            <select class="form-select form-select-sm" name="estados_mesa_id_estados_mesa" required>
                                <option value="">-- Seleccione un estado inicial --</option>
                                <% 
                                    if (listaEstadosMesa != null) {
                                        for (EstadosMesa em : listaEstadosMesa) {
                                            boolean esDisponible = (em.getId_estados_mesa() == 1);
                                %>
                                <option value="<%= em.getId_estados_mesa() %>" <%= esDisponible ? "selected" : "" %>>
                                    <%= em.getNombre_estado() %>
                                </option>
                                <% 
                                        }
                                    } 
                                %>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-dark btn-sm">Registrar Mesa</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>