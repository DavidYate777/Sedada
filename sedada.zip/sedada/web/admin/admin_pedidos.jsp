<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuarios" %>
<%@ page import="Modelo.Pedido" %>
<%@ page import="Modelo.EstadoPedido" %>
<%@ page import="Modelo.Mesas" %>
<%@ page import="java.util.List" %>
<%
    Usuarios user = (Usuarios) session.getAttribute("usuarioLogueado");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
    
    List<Pedido> listaPedidos = (List<Pedido>) request.getAttribute("listaPedidos");
    List<EstadoPedido> listaEstadosPedidos = (List<EstadoPedido>) request.getAttribute("listaEstadosPedidos");
    List<Mesas> listaMesas = (List<Mesas>) request.getAttribute("listaMesas");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Pedidos - SEDADA Enterprise OPS</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Archivo CSS centralizado -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">
</head>
<body class="admin-body">

    <!-- Menú Lateral -->
    <div class="admin-sidebar">
        <div class="brand d-flex align-items-center gap-2">
            <div class="bg-dark text-white rounded p-1 px-2 fw-bold" style="font-size: 0.8rem;">SD</div>
            <div>
                <div style="line-height: 1.2;">SEDADA</div>
                <small class="text-muted fw-normal" style="font-size: 0.70rem;">ENTERPRISE OPS</small>
            </div>
        </div>
        
        <div class="px-2 mt-2 flex-grow-1">
            <div class="text-muted px-3 mb-1" style="font-size: 0.65rem; letter-spacing: 0.5px;">MAIN MENU</div>
            <ul class="nav flex-column gap-1">
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/admin_dashboard" class="nav-link"><i class="fa-solid fa-shapes"></i> Resumen</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/pedidos" class="nav-link active"><i class="fa-solid fa-cart-shopping"></i> Pedidos</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/inventario" class="nav-link"><i class="fa-solid fa-boxes-stacked"></i> Inventario</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/mesas" class="nav-link"><i class="fa-solid fa-chair"></i> Mesas</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/usuarios" class="nav-link"><i class="fa-solid fa-users"></i> Usuarios</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/categorias" class="nav-link"><i class="fa-solid fa-layer-group"></i> Categorías</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/facturas" class="nav-link"><i class="fa-solid fa-file-invoice-dollar"></i> Facturación e Impuestos</a></li>
            </ul>
        </div>

        <div class="p-3 border-top">
            <a href="#" class="nav-link mb-2"><i class="fa-solid fa-circle-question"></i> Soporte</a>
            <a href="${pageContext.request.contextPath}/LoginServlet?accion=logout" class="nav-link text-danger"><i class="fa-solid fa-right-from-bracket"></i> Cerrar Sesión</a>
        </div>
    </div>

    <!-- Área de Contenido Principal -->
    <div class="admin-main-content">
        
        <!-- Barra Superior -->
        <div class="admin-top-navbar mb-3">
            <div class="text-muted small">SEDADA / Operaciones / <span class="text-dark fw-semibold">Gestión de Pedidos</span></div>
            <div class="position-relative">
                <i class="fa-solid fa-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted small"></i>
                <input type="text" class="form-control admin-search-box ps-5 text-muted small" placeholder="Buscar pedidos, mesas o inventario...">
            </div>
            <div class="d-flex align-items-center gap-3">
                <i class="fa-regular fa-bell text-secondary fs-6" style="cursor: pointer;"></i>
                <a href="${pageContext.request.contextPath}/perfil" class="text-secondary d-flex align-items-center text-decoration-none" title="Configuración de Perfil">
                    <i class="fa-solid fa-gear fs-6"></i>
                </a>
                <div class="d-flex align-items-center gap-2 border-start ps-3">
                    <div class="bg-dark text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 32px; height: 32px; font-size: 0.8rem;">
                        <%= user.getNombre_usuarios().substring(0, 1).toUpperCase() %>
                    </div>
                    <div>
                        <span class="fw-semibold text-dark small d-block" style="line-height: 1;"><%= user.getNombre_usuarios() %></span>
                        <small class="text-muted" style="font-size: 0.7rem;">SEDADA Central</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Encabezado de la Sección y Botón Nuevo -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold m-0" style="font-size: 1.4rem;">Gestión de Pedidos</h3>
                <p class="text-muted small m-0 mt-1">Cree, modifique y supervise el ciclo completo de los pedidos activos.</p>
            </div>
            <button class="btn btn-dark btn-sm fw-semibold px-3" data-bs-toggle="modal" data-bs-target="#modalNuevoPedido">
                <i class="fa-solid fa-plus me-1"></i> Nuevo Pedido
            </button>
        </div>

        <!-- Cuadrícula de Tarjetas de Órdenes -->
        <div class="row g-3">
            <% 
                if (listaPedidos != null && !listaPedidos.isEmpty()) {
                    for (Pedido p : listaPedidos) {
            %>
            <div class="col-md-4">
                <div class="card border-0 shadow-sm p-3 bg-white h-100 position-relative" style="border-radius: 8px;">
                    <div class="d-flex justify-content-between align-items-start border-bottom pb-3 mb-3">
                        <div>
                            <span class="badge bg-light text-dark fw-bold fs-6 mb-1 border">
                                <%= p.getMesas_id_mesas() != null ? "Mesa " + p.getMesas_id_mesas() : "Domicilio" %>
                            </span>
                            <div class="text-muted" style="font-size: 0.75rem;"><i class="fa-regular fa-clock me-1"></i> <%= p.getFecha_horas() != null ? p.getFecha_horas().toString() : "Reciente" %></div>
                        </div>
                        <span class="badge bg-warning bg-opacity-15 text-warning-emphasis border border-warning-subtle py-1 px-2" style="font-size: 0.75rem;">
                            Estado ID: <%= p.getEstados_pedidos_id_estados_pedidos() %>
                        </span>
                    </div>

                    <div class="mb-3 small">
                        <div class="d-flex justify-content-between py-1 border-bottom border-light">
                            <span class="text-dark fw-medium">Ubicación:</span>
                            <span class="text-muted"><%= p.getDireccion_entrega() != null ? p.getDireccion_entrega() : "Salón principal" %></span>
                        </div>
                        <div class="d-flex justify-content-between py-1">
                            <span class="text-dark fw-medium">Teléfono:</span>
                            <span class="text-muted"><%= p.getTelefono_contacto() != null ? p.getTelefono_contacto() : "N/D" %></span>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center pt-2 border-top mt-auto">
                        <span class="fw-bold text-dark small">ID: #ORD-<%= p.getId_pedidos() %></span>
                        <div class="d-flex gap-1">
                            <!-- Botón Editar -->
                            <button class="btn btn-sm btn-outline-dark py-0 px-2" data-bs-toggle="modal" data-bs-target="#modalEditar<%= p.getId_pedidos() %>" title="Editar pedido">
                                <i class="fa-solid fa-pen"></i>
                            </button>
                            <!-- Botón Eliminar -->
                            <a href="${pageContext.request.contextPath}/admin/pedidos?accion=eliminar&id=<%= p.getId_pedidos() %>" class="btn btn-sm btn-outline-danger py-0 px-2" onclick="return confirm('¿Está seguro de eliminar este pedido?');" title="Eliminar pedido">
                                <i class="fa-solid fa-trash-can"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Modal Editar Pedido para cada tarjeta -->
            <div class="modal fade" id="modalEditar<%= p.getId_pedidos() %>" tabindex="-1" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="${pageContext.request.contextPath}/admin/pedidos" method="POST">
                            <input type="hidden" name="accion" value="actualizar">
                            <input type="hidden" name="id_pedidos" value="<%= p.getId_pedidos() %>">
                            <div class="modal-header">
                                <h5 class="modal-title fw-bold fs-6">Editar Pedido #ORD-<%= p.getId_pedidos() %></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body small">
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Asignación de Mesa</label>
                                    <select class="form-select form-select-sm" name="mesas_id_mesas">
                                        <option value="domicilio" <%= p.getMesas_id_mesas() == null ? "selected" : "" %>>-- Es Domicilio (Sin Mesa) --</option>
                                        <% 
                                            if (listaMesas != null) {
                                                for (Mesas m : listaMesas) {
                                                    boolean esMesaActual = (p.getMesas_id_mesas() != null && p.getMesas_id_mesas() == m.getId_mesas());
                                        %>
                                        <option value="<%= m.getId_mesas() %>" <%= esMesaActual ? "selected" : "" %>>
                                            Mesa <%= m.getNumero_mesas() %> (Capacidad: <%= m.getCapacidades() %> p.)
                                        </option>
                                        <% 
                                                }
                                            } 
                                        %>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Dirección de Entrega</label>
                                    <input type="text" class="form-control form-control-sm" name="direccion_entrega" value="<%= p.getDireccion_entrega() != null ? p.getDireccion_entrega() : "" %>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Teléfono de Contacto</label>
                                    <input type="text" class="form-control form-control-sm" name="telefono_contacto" value="<%= p.getTelefono_contacto() != null ? p.getTelefono_contacto() : "" %>">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label fw-semibold">Estado del Pedido</label>
                                    <select class="form-select form-select-sm" name="estados_pedidos_id_estados_pedidos" required>
                                        <% 
                                            if (listaEstadosPedidos != null) {
                                                for (EstadoPedido ep : listaEstadosPedidos) {
                                                    boolean esActual = (p.getEstados_pedidos_id_estados_pedidos() == ep.getId_estados_pedidos());
                                        %>
                                        <option value="<%= ep.getId_estados_pedidos() %>" <%= esActual ? "selected" : "" %>>
                                            <%= ep.getNombres_estado_pedidos() %>
                                        </option>
                                        <% 
                                                }
                                            } 
                                        %>
                                    </select>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                                <button type="submit" class="btn btn-dark btn-sm">Guardar Cambios</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <% 
                    }
                } else {
            %>
            <div class="col-12">
                <div class="card border-0 bg-white p-5 text-center text-muted rounded-3 shadow-sm">
                    <i class="fa-solid fa-box-open fs-1 mb-2 text-secondary"></i>
                    <h5 class="fw-bold text-dark">No hay pedidos registrados</h5>
                    <p class="small mb-0">Utilice el botón "Nuevo Pedido" para registrar la primera orden.</p>
                </div>
            </div>
            <% } %>
        </div>

    </div>

    <!-- Modal Nuevo Pedido (Crear) -->
    <div class="modal fade" id="modalNuevoPedido" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="${pageContext.request.contextPath}/admin/pedidos" method="POST">
                    <input type="hidden" name="accion" value="insertar">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold fs-6">Registrar Nuevo Pedido</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body small">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Asignación de Mesa</label>
                            <select class="form-select form-select-sm" name="mesas_id_mesas">
                                <option value="domicilio">-- Es Domicilio (Sin Mesa) --</option>
                                <% 
                                    if (listaMesas != null) {
                                        for (Mesas m : listaMesas) {
                                %>
                                <option value="<%= m.getId_mesas() %>">
                                    Mesa <%= m.getNumero_mesas() %> (Capacidad: <%= m.getCapacidades() %> p.)
                                </option>
                                <% 
                                        }
                                    } 
                                %>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Dirección de Entrega</label>
                            <input type="text" class="form-control form-control-sm" name="direccion_entrega" placeholder="Ej. Calle Principal #123">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Teléfono de Contacto</label>
                            <input type="text" class="form-control form-control-sm" name="telefono_contacto" placeholder="Ej. 3001234567">
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Estado Inicial</label>
                            <select class="form-select form-select-sm" name="estados_pedidos_id_estados_pedidos" required>
                                <% 
                                    if (listaEstadosPedidos != null) {
                                        for (EstadoPedido ep : listaEstadosPedidos) {
                                            boolean esPendiente = (ep.getId_estados_pedidos() == 1);
                                %>
                                <option value="<%= ep.getId_estados_pedidos() %>" <%= esPendiente ? "selected" : "" %>>
                                    <%= ep.getNombres_estado_pedidos() %>
                                </option>
                                <% 
                                        }
                                    } 
                                %>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-dark btn-sm">Registrar Pedido</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>