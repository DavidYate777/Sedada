<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuarios" %>
<%@ page import="Modelo.Categoria" %>
<%@ page import="java.util.List" %>
<%
    Usuarios user = (Usuarios) session.getAttribute("usuarioLogueado");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
    
    List<Categoria> listaCategorias = (List<Categoria>) request.getAttribute("listaCategorias");
    Categoria categoriaSeleccionada = (Categoria) request.getAttribute("categoriaSeleccionada");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categorías - SEDADA Enterprise OPS</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Archivo CSS centralizado -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">
</head>
<body class="admin-body">

    <!-- Menú Lateral -->
    <div class="admin-sidebar">
        <div class="brand d-flex align-items-center gap-2">
            <div class="bg-dark text-white rounded p-1 px-2 fw-bold" style="font-size: 0.8rem;">SD</div>
            <div>
                <div style="line-height: 1.2;">SEDADA</div>
                <small class="text-muted fw-normal" style="font-size: 0.70rem;">ENTERPRISE OPS</small>
            </div>
        </div>
        
        <div class="px-2 mt-2 flex-grow-1">
            <div class="text-muted px-3 mb-1" style="font-size: 0.65rem; letter-spacing: 0.5px;">MAIN MENU</div>
            <ul class="nav flex-column gap-1">
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/admin_dashboard" class="nav-link"><i class="fa-solid fa-shapes"></i> Resumen</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/pedidos" class="nav-link"><i class="fa-solid fa-cart-shopping"></i> Pedidos</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/inventario" class="nav-link"><i class="fa-solid fa-boxes-stacked"></i> Inventario</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/mesas" class="nav-link"><i class="fa-solid fa-chair"></i> Mesas</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/usuarios" class="nav-link"><i class="fa-solid fa-users"></i> Usuarios</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/categorias" class="nav-link active"><i class="fa-solid fa-layer-group"></i> Categorías</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/facturas" class="nav-link"><i class="fa-solid fa-file-invoice-dollar"></i> Facturación e Impuestos</a></li>
            </ul>
        </div>

        <div class="p-3 border-top">
            <a href="#" class="nav-link mb-2"><i class="fa-solid fa-circle-question"></i> Soporte</a>
            <a href="${pageContext.request.contextPath}/LoginServlet?accion=logout" class="nav-link text-danger"><i class="fa-solid fa-right-from-bracket"></i> Cerrar Sesión</a>
        </div>
    </div>

    <!-- Área de Contenido Principal -->
    <div class="admin-main-content d-flex gap-3 align-items-start">
        
        <!-- Columna Izquierda: Listado, Filtros y Métricas -->
        <div class="flex-grow-1">
            
            <!-- Barra Superior -->
            <div class="admin-top-navbar mb-3">
                <div class="text-muted small">SEDADA / Catálogo Maestro / <span class="text-dark fw-semibold">Categorías</span></div>
                <div class="position-relative">
                    <i class="fa-solid fa-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted small"></i>
                    <input type="text" class="form-control admin-search-box ps-5 text-muted small" placeholder="Buscar categorías o productos...">
                </div>
                <div class="d-flex align-items-center gap-3">
                    <i class="fa-regular fa-bell text-secondary fs-6" style="cursor: pointer;"></i>
                    <a href="${pageContext.request.contextPath}/perfil" class="text-secondary d-flex align-items-center text-decoration-none" title="Configuración de Perfil">
                        <i class="fa-solid fa-gear fs-6"></i>
                    </a>
                    <div class="d-flex align-items-center gap-2 border-start ps-3">
                        <div class="bg-dark text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 32px; height: 32px; font-size: 0.8rem;">
                            <%= user.getNombre_usuarios() != null && !user.getNombre_usuarios().isEmpty() ? user.getNombre_usuarios().substring(0, 1).toUpperCase() : "U" %>
                        </div>
                        <div>
                            <span class="fw-semibold text-dark small d-block" style="line-height: 1;"><%= user.getNombre_usuarios() %></span>
                            <small class="text-muted" style="font-size: 0.7rem;">SEDADA Central</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Encabezado de la Sección -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold m-0" style="font-size: 1.4rem;">Categorías del Menú y Catálogo</h3>
                    <p class="text-muted small m-0 mt-1">Organiza y administra las familias de productos disponibles en el menú y órdenes vinculadas al esquema DIAN.</p>
                </div>
                <div class="d-flex gap-2">
                    <button class="btn btn-outline-dark btn-sm fw-semibold bg-white px-3"><i class="fa-solid fa-arrow-down-up-across-lines me-1"></i> Reordenar Menú</button>
                    <!-- BOTÓN QUE DESPLIEGA EL FORMULARIO -->
                    <button type="button" id="btnMostrarFormulario" class="btn btn-dark btn-sm fw-semibold px-3">
                        <i class="fa-solid fa-plus me-1"></i> + Nueva Categoría
                    </button>
                </div>
            </div>

            <!-- Tarjetas de Métricas -->
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="card card-metric">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">TOTAL CATEGORÍAS</span>
                            <div class="bg-light p-2 rounded-2 text-primary"><i class="fa-solid fa-layer-group"></i></div>
                        </div>
                        <h3 class="fw-bold m-0"><%= listaCategorias != null ? listaCategorias.size() : 0 %> <small class="text-success fs-6 fw-normal">● Activas</small></h3>
                        <small class="text-muted mt-1" style="font-size: 0.75rem;">Supabase table: <strong>categorias</strong></small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-metric">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">TOTAL PRODUCTOS VINCULADOS</span>
                            <div class="bg-light p-2 rounded-2 text-dark"><i class="fa-solid fa-utensils"></i></div>
                        </div>
                        <h3 class="fw-bold m-0">64 <small class="text-muted fs-6 fw-normal">items en catálogo</small></h3>
                        <small class="text-muted mt-1" style="font-size: 0.75rem;">100% clasificados en POS</small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-metric">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">CATEGORÍA MÁS VENDIDA</span>
                            <div class="bg-light p-2 rounded-2 text-warning"><i class="fa-solid fa-chart-line"></i></div>
                        </div>
                        <h3 class="fw-bold m-0" style="font-size: 1.15rem;">Platos Fuertes</h3>
                        <small class="text-success fw-semibold mt-1" style="font-size: 0.75rem;"><i class="fa-solid fa-arrow-trend-up me-1"></i> 42% de facturación este mes</small>
                    </div>
                </div>
            </div>

            <!-- Filtros de la Tabla -->
            <div class="table-container">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div class="position-relative w-50">
                        <i class="fa-solid fa-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted small"></i>
                        <input type="text" class="form-control form-control-sm ps-5 text-muted" placeholder="Filtrar por nombre o impuesto...">
                    </div>
                    <div class="d-flex align-items-center gap-2">
                        <span class="text-muted small">Filtro Estado:</span>
                        <select class="form-select form-select-sm" style="width: 150px;">
                            <option>Todos los estados</option>
                            <option>Activos</option>
                            <option>Inactivos</option>
                        </select>
                    </div>
                </div>

                <!-- Tabla de Categorías -->
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="text-muted small bg-light">
                            <tr>
                                <th class="py-3 ps-3">ORDEN</th>
                                <th>CATEGORÍA</th>
                                <th>PRODUCTOS</th>
                                <th>IMPUESTO DIAN</th>
                                <th>ESTADO EN CARTA</th>
                                <th class="text-end pe-3">ACCIONES</th>
                            </tr>
                        </thead>
                        <tbody class="small">
                            <% 
                                if (listaCategorias != null && !listaCategorias.isEmpty()) {
                                    for (Categoria cat : listaCategorias) {
                            %>
                            <tr>
                                <td class="ps-3 text-muted"><i class="fa-solid fa-grip-vertical me-1"></i> #<%= cat.getId_categorias() %></td>
                                <td class="fw-semibold">
                                    <a href="${pageContext.request.contextPath}/admin/categorias?detalle_id=<%= cat.getId_categorias() %>" class="text-decoration-none text-dark">
                                        <%= cat.getNombre_categorias() %>
                                    </a>
                                </td>
                                <td><span class="badge bg-light text-dark border px-2 py-1 rounded-pill">5 productos</span></td>
                                <td><span class="badge bg-light text-secondary border px-2 py-1">Impoconsumo 8%</span></td>
                                <td><span class="text-success fw-semibold">● Visible en Menú</span></td>
                                <td class="text-end pe-3">
                                    <div class="d-flex justify-content-end gap-1">
                                        <a href="${pageContext.request.contextPath}/admin/categorias?detalle_id=<%= cat.getId_categorias() %>" class="btn btn-sm btn-outline-dark py-0 px-2" title="Editar">
                                            <i class="fa-solid fa-pen"></i>
                                        </a>
                                        <a href="${pageContext.request.contextPath}/admin/categorias?accion=eliminar&id=<%= cat.getId_categorias() %>" class="btn btn-sm btn-outline-danger py-0 px-2" onclick="return confirm('¿Desea eliminar esta categoría?');" title="Eliminar">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <% 
                                    }
                                } else {
                            %>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">No hay categorías registradas en el sistema.</td>
                            </tr>
                            <% } %>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <!-- Columna Derecha -->
        <div id="columnaFormulario" style="width: 380px; min-width: 380px; margin-top: 85px;" class="<%= categoriaSeleccionada != null ? "" : "d-none" %>">
            <div class="card border-0 shadow-sm p-4 bg-white mb-3" style="border-radius: 8px;">
                <div class="d-flex justify-content-between align-items-start mb-3 border-bottom pb-3">
                    <div>
                        <h5 class="fw-bold m-0 text-dark" style="font-size: 1.1rem;"><%= categoriaSeleccionada != null ? "Editar Categoría" : "Nueva Categoría" %></h5>
                        <small class="text-muted" style="font-size: 0.75rem;">Define las propiedades en carta e impuestos</small>
                    </div>
                    <span class="badge bg-primary bg-opacity-10 text-primary px-2 py-1" style="font-size: 0.7rem;"><%= categoriaSeleccionada != null ? "MODIFICANDO" : "CREANDO" %></span>
                </div>

                <form action="${pageContext.request.contextPath}/admin/categorias" method="POST">
                    <input type="hidden" name="accion" value="<%= categoriaSeleccionada != null ? "actualizar_categoria" : "insertar_categoria" %>">
                    <% if (categoriaSeleccionada != null) { %>
                        <input type="hidden" name="id_categorias" value="<%= categoriaSeleccionada.getId_categorias() %>">
                    <% } %>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Nombre de la Categoría *</label>
                        <input type="text" class="form-control form-control-sm" name="nombre_categorias" 
                               value="<%= categoriaSeleccionada != null ? categoriaSeleccionada.getNombre_categorias() : "" %>" 
                               placeholder="Ej. Cortes Especiales, Vinos Premium" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Descripción / Detalle</label>
                        <textarea class="form-control form-control-sm" name="descripcion" rows="2" placeholder="Breve reseña que aparecerá en el menú digital..."></textarea>
                    </div>

                    <!-- SELECTOR DE ICONO CON CAMPO OCULTO -->
                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Icono Identificador</label>
                        <input type="hidden" name="icono" id="inputIcono" value="fa-utensils">
                        <div class="d-flex gap-2 bg-light p-2 rounded-2 justify-content-between">
                            <button type="button" class="btn btn-sm btn-icon-option btn-dark px-2 py-1" data-icon="fa-utensils"><i class="fa-solid fa-utensils"></i></button>
                            <button type="button" class="btn btn-sm btn-icon-option btn-outline-secondary px-2 py-1" data-icon="fa-burger"><i class="fa-solid fa-burger"></i></button>
                            <button type="button" class="btn btn-sm btn-icon-option btn-outline-secondary px-2 py-1" data-icon="fa-wine-glass"><i class="fa-solid fa-wine-glass"></i></button>
                            <button type="button" class="btn btn-sm btn-icon-option btn-outline-secondary px-2 py-1" data-icon="fa-mug-hot"><i class="fa-solid fa-mug-hot"></i></button>
                            <button type="button" class="btn btn-sm btn-icon-option btn-outline-secondary px-2 py-1" data-icon="fa-ice-cream"><i class="fa-solid fa-ice-cream"></i></button>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold small">Impuesto por Defecto Asociado *</label>
                        <select class="form-select form-select-sm" name="impuesto">
                            <option value="1">Impoconsumo 8% (Servicio de Rest.)</option>
                            <option value="2">IVA 19% (General)</option>
                            <option value="3">Exento de Impuestos</option>
                        </select>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mb-4 bg-light p-2 rounded-2 border">
                        <div>
                            <span class="small fw-semibold text-dark d-block" style="font-size: 0.8rem;">Visibilidad en Menú Digital y POS</span>
                            <small class="text-muted" style="font-size: 0.7rem;">Los camareros podrán añadir items</small>
                        </div>
                        <div class="form-check form-switch m-0">
                            <input class="form-check-input" type="checkbox" name="visible" role="switch" checked>
                        </div>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-dark btn-sm w-100 fw-semibold py-2">
                            <%= categoriaSeleccionada != null ? "Actualizar Categoría" : "Guardar Categoría" %>
                        </button>
                        <button type="button" id="btnCancelarFormulario" class="btn btn-outline-secondary btn-sm w-100 py-2">Cancelar</button>
                    </div>
                </form>
            </div>

            <!-- Tarjeta secundaria inferior derecha -->
            <div class="card border-0 shadow-sm p-3 bg-white" style="border-radius: 8px;">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="fw-bold small text-dark">Productos Recientes en Catálogo</span>
                    <small class="text-muted" style="font-size: 0.7rem;">Tabla: productos</small>
                </div>
                <div class="d-flex justify-content-between align-items-center bg-light p-2 rounded-2 mb-2 small">
                    <span class="text-dark fw-semibold"><i class="fa-solid fa-utensils me-1 text-secondary"></i> Bife de Chorizo 350g</span>
                    <span class="badge bg-white text-muted border">Platos Fuertes</span>
                </div>
                <div class="d-flex justify-content-between align-items-center bg-light p-2 rounded-2 small">
                    <span class="text-dark fw-semibold"><i class="fa-solid fa-wine-glass me-1 text-secondary"></i> Vino Tinto Reserva</span>
                    <span class="badge bg-white text-muted border">Bebidas</span>
                </div>
            </div>
        </div>

    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Script Interactivo para Mostrar/Ocultar y Seleccionar Icono -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const btnMostrar = document.getElementById('btnMostrarFormulario');
            const btnCancelar = document.getElementById('btnCancelarFormulario');
            const columnaForm = document.getElementById('columnaFormulario');
            const inputIcono = document.getElementById('inputIcono');
            const botonesIconos = document.querySelectorAll('.btn-icon-option');

            // 1. Mostrar el formulario al presionar "+ Nueva Categoría"
            if (btnMostrar && columnaForm) {
                btnMostrar.addEventListener('click', function() {
                    columnaForm.classList.remove('d-none');
                });
            }

            // 2. Ocultar formulario o cancelar edición
            if (btnCancelar && columnaForm) {
                btnCancelar.addEventListener('click', function() {
                    <% if (categoriaSeleccionada != null) { %>
                        window.location.href = "${pageContext.request.contextPath}/admin/categorias";
                    <% } else { %>
                        columnaForm.classList.add('d-none');
                    <% } %>
                });
            }

            // 3. Selección interactiva de iconos
            botonesIconos.forEach(btn => {
                btn.addEventListener('click', function() {
                    botonesIconos.forEach(b => {
                        b.classList.remove('btn-dark');
                        b.classList.add('btn-outline-secondary');
                    });
                    this.classList.remove('btn-outline-secondary');
                    this.classList.add('btn-dark');
                    
                    const iconoSeleccionado = this.getAttribute('data-icon');
                    inputIcono.value = iconoSeleccionado;
                });
            });
        });
    </script>
</body>
</html>