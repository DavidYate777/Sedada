package Controlador;

import Modelo.Pago;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PagosDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public Pago consultarPago(int id, Connection conn) {
        Pago miPago = null;
        String querySql = "SELECT id_pago, facturas_id_facturas, metodos_pago_id_metodos_pago "
                        + "FROM pago WHERE id_pago = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miPago = mapearPago(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar el pago: " + e.getMessage());
        }

        return miPago;
    }

    public List<Pago> consultarTodos(Connection conn) {
        List<Pago> lista = new ArrayList<>();
        String querySql = "SELECT id_pago, facturas_id_facturas, metodos_pago_id_metodos_pago FROM pago";

        try (PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearPago(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar todos los pagos: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertarPago(Pago miPago, Connection conn) {
        String querySql = "INSERT INTO pago (id_pago, facturas_id_facturas, metodos_pago_id_metodos_pago) "
                        + "VALUES (?, ?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, miPago.getId_pago());
            ps.setInt(2, miPago.getFacturas_id_facturas());
            ps.setInt(3, miPago.getMetodos_pago_id_metodos_pago());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar el pago: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarPago(Pago miPago, Connection conn) {
        String querySql = "UPDATE pago SET facturas_id_facturas = ?, "
                        + "metodos_pago_id_metodos_pago = ? WHERE id_pago = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, miPago.getFacturas_id_facturas());
            ps.setInt(2, miPago.getMetodos_pago_id_metodos_pago());
            ps.setInt(3, miPago.getId_pago());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar el pago: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarPago(int id, Connection conn) {
        String querySql = "DELETE FROM pago WHERE id_pago = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar el pago: " + e.getMessage());
            return false;
        }
    }

    public boolean inactivarPago(int id, Connection conn) {
        String querySql = "UPDATE pago SET estado = 'Inactivo' WHERE id_pago = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al inactivar el pago: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS ESTÁNDAR (ALIAS / COMPATIBILIDAD)
    // ==========================================

    public Pago consultarPorId(int id, Connection conn) {
        return consultarPago(id, conn);
    }

    public List<Pago> consultar(Connection conn) {
        return consultarTodos(conn);
    }

    public boolean insertar(Pago miPago, Connection conn) {
        return insertarPago(miPago, conn);
    }

    public boolean actualizar(Pago miPago, Connection conn) {
        return actualizarPago(miPago, conn);
    }

    public boolean eliminar(int id, Connection conn) {
        return eliminarPago(id, conn);
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public Pago consultarPago(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return consultarPago(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar el pago: " + e.getMessage());
            return null;
        }
    }

    public List<Pago> consultarTodos() {
        try (Connection conn = Conexion.getConnection()) {
            return consultarTodos(conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar todos los pagos: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertarPago(Pago miPago) {
        try (Connection conn = Conexion.getConnection()) {
            return insertarPago(miPago, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar el pago: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarPago(Pago miPago) {
        try (Connection conn = Conexion.getConnection()) {
            return actualizarPago(miPago, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar el pago: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarPago(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return eliminarPago(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar el pago: " + e.getMessage());
            return false;
        }
    }

    public boolean inactivarPago(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return inactivarPago(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al inactivar el pago: " + e.getMessage());
            return false;
        }
    }

    public Pago consultarPorId(int id) {
        return consultarPago(id);
    }

    public List<Pago> consultar() {
        return consultarTodos();
    }

    public boolean insertar(Pago miPago) {
        return insertarPago(miPago);
    }

    public boolean actualizar(Pago miPago) {
        return actualizarPago(miPago);
    }

    public boolean eliminar(int id) {
        return eliminarPago(id);
    }

    // ==========================================
    // MÉTODOS AUXILIARES
    // ==========================================

    private Pago mapearPago(ResultSet rs) throws SQLException {
        Pago pago = new Pago();
        pago.setId_pago(rs.getInt("id_pago"));
        pago.setFacturas_id_facturas(rs.getInt("facturas_id_facturas"));
        pago.setMetodos_pago_id_metodos_pago(rs.getInt("metodos_pago_id_metodos_pago"));
        return pago;
    }
}