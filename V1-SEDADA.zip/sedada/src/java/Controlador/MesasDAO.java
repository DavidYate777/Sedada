package Controlador;

import Modelo.Mesas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MesasDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public Mesas consultarMesa(int id, Connection conn) {
        Mesas miMesa = null;
        String querySql = "SELECT id_Mesas, numero_Mesas, capacidades, estados_mesa_id_estados_mesa "
                        + "FROM Mesas WHERE id_Mesas = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miMesa = mapearMesa(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar la mesa: " + e.getMessage());
        }

        return miMesa;
    }

    public List<Mesas> consultarTodas(Connection conn) {
        List<Mesas> lista = new ArrayList<>();
        String querySql = "SELECT id_Mesas, numero_Mesas, capacidades, estados_mesa_id_estados_mesa FROM Mesas ORDER BY numero_Mesas ASC";

        try (PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearMesa(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar todas las mesas: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertarMesa(Mesas miMesa, Connection conn) {
        String querySql = "INSERT INTO Mesas (numero_Mesas, capacidades, estados_mesa_id_estados_mesa) VALUES (?, ?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, miMesa.getNumero_mesas());
            ps.setInt(2, miMesa.getCapacidades());
            ps.setInt(3, miMesa.getEstados_mesa_id_estados_mesa());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar la mesa: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarMesa(Mesas miMesa, Connection conn) {
        String querySql = "UPDATE Mesas SET capacidades = ?, numero_Mesas = ?, estados_mesa_id_estados_mesa = ? "
                        + "WHERE id_Mesas = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, miMesa.getCapacidades());
            ps.setInt(2, miMesa.getNumero_mesas());
            ps.setInt(3, miMesa.getEstados_mesa_id_estados_mesa());
            ps.setInt(4, miMesa.getId_mesas());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar la mesa: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarMesa(int id, Connection conn) {
        String querySql = "DELETE FROM Mesas WHERE id_Mesas = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar la mesa: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarMesa(Mesas miMesa, Connection conn) {
        return eliminarMesa(miMesa.getId_mesas(), conn);
    }

    /**
     * Permite cambiar el estado de la mesa sin necesidad de instanciar o cargar el objeto completo.
     */
    public boolean cambiarEstadoMesa(int idMesa, int idNuevoEstado, Connection conn) {
        String querySql = "UPDATE Mesas SET estados_mesa_id_estados_mesa = ? WHERE id_Mesas = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, idNuevoEstado);
            ps.setInt(2, idMesa);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al cambiar el estado de la mesa: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS ESTÁNDAR (ALIAS / COMPATIBILIDAD)
    // ==========================================

    public Mesas consultarPorId(int id, Connection conn) {
        return consultarMesa(id, conn);
    }

    public List<Mesas> consultar(Connection conn) {
        return consultarTodas(conn);
    }

    public boolean insertar(Mesas miMesa, Connection conn) {
        return insertarMesa(miMesa, conn);
    }

    public boolean actualizar(Mesas miMesa, Connection conn) {
        return actualizarMesa(miMesa, conn);
    }

    public boolean eliminar(int id, Connection conn) {
        return eliminarMesa(id, conn);
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public Mesas consultarMesa(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return consultarMesa(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar la mesa: " + e.getMessage());
            return null;
        }
    }

    public List<Mesas> consultarTodas() {
        try (Connection conn = Conexion.getConnection()) {
            return consultarTodas(conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar todas las mesas: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertarMesa(Mesas miMesa) {
        try (Connection conn = Conexion.getConnection()) {
            return insertarMesa(miMesa, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar la mesa: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarMesa(Mesas miMesa) {
        try (Connection conn = Conexion.getConnection()) {
            return actualizarMesa(miMesa, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar la mesa: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarMesa(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return eliminarMesa(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar la mesa: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarMesa(Mesas miMesa) {
        return eliminarMesa(miMesa.getId_mesas());
    }

    public boolean cambiarEstadoMesa(int idMesa, int idNuevoEstado) {
        try (Connection conn = Conexion.getConnection()) {
            return cambiarEstadoMesa(idMesa, idNuevoEstado, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al cambiar el estado de la mesa: " + e.getMessage());
            return false;
        }
    }

    public Mesas consultarPorId(int id) {
        return consultarMesa(id);
    }

    public List<Mesas> consultar() {
        return consultarTodas();
    }

    public boolean insertar(Mesas miMesa) {
        return insertarMesa(miMesa);
    }

    public boolean actualizar(Mesas miMesa) {
        return actualizarMesa(miMesa);
    }

    public boolean eliminar(int id) {
        return eliminarMesa(id);
    }

    // ==========================================
    // MÉTODOS AUXILIARES
    // ==========================================

    private Mesas mapearMesa(ResultSet rs) throws SQLException {
        Mesas mesa = new Mesas();
        mesa.setId_mesas(rs.getInt("id_Mesas"));
        mesa.setNumero_mesas(rs.getInt("numero_Mesas"));
        mesa.setCapacidades(rs.getInt("capacidades"));
        mesa.setEstados_mesa_id_estados_mesa(rs.getInt("estados_mesa_id_estados_mesa"));
        return mesa;
    }
}