package Modelo;

public class RolPermisos {
    
    private int roles_id_roles;
    private int permisos_id_permisos;

    public int getRoles_id_roles() {
        return roles_id_roles;
    }

    public void setRoles_id_roles(int roles_id_roles) {
        this.roles_id_roles = roles_id_roles;
    }

    public int getPermisos_id_permisos() {
        return permisos_id_permisos;
    }

    public void setPermisos_id_permisos(int permisos_id_permisos) {
        this.permisos_id_permisos = permisos_id_permisos;
    }
}