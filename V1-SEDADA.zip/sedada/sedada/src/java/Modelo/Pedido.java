package Modelo;

import java.time.LocalDateTime;

public class Pedido {
    private int id_pedidos;
    private LocalDateTime fecha_horas;
    private int usuarios_id_usuarios;
    private Integer cocinero_id_usuarios;
    private Integer domiciliario_id_usuarios;
    private Integer mesas_id_mesas;
    private String direccion_entrega;
    private String telefono_contacto;
    private int estados_pedidos_id_estados_pedidos;

    public Pedido() {
    }

    public int getId_pedidos() {
        return id_pedidos;
    }

    public void setId_pedidos(int id_pedidos) {
        this.id_pedidos = id_pedidos;
    }

    public LocalDateTime getFecha_horas() {
        return fecha_horas;
    }

    public void setFecha_horas(LocalDateTime fecha_horas) {
        this.fecha_horas = fecha_horas;
    }

    public int getUsuarios_id_usuarios() {
        return usuarios_id_usuarios;
    }

    public void setUsuarios_id_usuarios(int usuarios_id_usuarios) {
        this.usuarios_id_usuarios = usuarios_id_usuarios;
    }

    public Integer getCocinero_id_usuarios() {
        return cocinero_id_usuarios;
    }

    public void setCocinero_id_usuarios(Integer cocinero_id_usuarios) {
        this.cocinero_id_usuarios = cocinero_id_usuarios;
    }

    public Integer getDomiciliario_id_usuarios() {
        return domiciliario_id_usuarios;
    }

    public void setDomiciliario_id_usuarios(Integer domiciliario_id_usuarios) {
        this.domiciliario_id_usuarios = domiciliario_id_usuarios;
    }

    public Integer getMesas_id_mesas() {
        return mesas_id_mesas;
    }

    public void setMesas_id_mesas(Integer mesas_id_mesas) {
        this.mesas_id_mesas = mesas_id_mesas;
    }

    public String getDireccion_entrega() {
        return direccion_entrega;
    }

    public void setDireccion_entrega(String direccion_entrega) {
        this.direccion_entrega = direccion_entrega;
    }

    public String getTelefono_contacto() {
        return telefono_contacto;
    }

    public void setTelefono_contacto(String telefono_contacto) {
        this.telefono_contacto = telefono_contacto;
    }

    public int getEstados_pedidos_id_estados_pedidos() {
        return estados_pedidos_id_estados_pedidos;
    }

    public void setEstados_pedidos_id_estados_pedidos(int estados_pedidos_id_estados_pedidos) {
        this.estados_pedidos_id_estados_pedidos = estados_pedidos_id_estados_pedidos;
    }
}