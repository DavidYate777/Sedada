package Modelo;

public class Permisos {
    
    private int id_permisos;
    private String nombre_permiso;
    private String descripcion_permiso;

    public int getId_permisos() {
        return id_permisos;
    }

    public void setId_permisos(int id_permisos) {
        this.id_permisos = id_permisos;
    }

    public String getNombre_permiso() {
        return nombre_permiso;
    }

    public void setNombre_permiso(String nombre_permiso) {
        this.nombre_permiso = nombre_permiso;
    }

    public String getDescripcion_permiso() {
        return descripcion_permiso;
    }

    public void setDescripcion_permiso(String descripcion_permiso) {
        this.descripcion_permiso = descripcion_permiso;
    }
}