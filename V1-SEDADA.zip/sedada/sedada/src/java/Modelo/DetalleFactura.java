/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;
import java.math.BigDecimal;

/**
 *
 * @author Aprendiz
 */
public class DetalleFactura {
    
    private int id_detalle_factura;
    private int cantidades;
    private BigDecimal precios_unitarios_facturados;
    private BigDecimal valores_iva_lineas;
    private int facturas_id_facturas;
    private int detalle_pedidos_id_detalle_pedidos;

    public int getId_detalle_factura() {
        return id_detalle_factura;
    }

    public void setId_detalle_factura(int id_detalle_factura) {
        this.id_detalle_factura = id_detalle_factura;
    }

    public int getCantidades() {
        return cantidades;
    }

    public void setCantidades(int cantidades) {
        this.cantidades = cantidades;
    }

    public BigDecimal getPrecios_unitarios_facturados() {
        return precios_unitarios_facturados;
    }

    public void setPrecios_unitarios_facturados(BigDecimal precios_unitarios_facturados) {
        this.precios_unitarios_facturados = precios_unitarios_facturados;
    }

    public BigDecimal getValores_iva_lineas() {
        return valores_iva_lineas;
    }

    public void setValores_iva_lineas(BigDecimal valores_iva_lineas) {
        this.valores_iva_lineas = valores_iva_lineas;
    }

    public int getFacturas_id_facturas() {
        return facturas_id_facturas;
    }

    public void setFacturas_id_facturas(int facturas_id_facturas) {
        this.facturas_id_facturas = facturas_id_facturas;
    }

    public int getDetalle_pedidos_id_detalle_pedidos() {
        return detalle_pedidos_id_detalle_pedidos;
    }

    public void setDetalle_pedidos_id_detalle_pedidos(int detalle_pedidos_id_detalle_pedidos) {
        this.detalle_pedidos_id_detalle_pedidos = detalle_pedidos_id_detalle_pedidos;
    }
    
    
}
