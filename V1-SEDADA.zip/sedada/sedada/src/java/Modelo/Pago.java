/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class Pago {

    public int getId_pago() {
        return id_pago;
    }

    public void setId_pago(int id_pago) {
        this.id_pago = id_pago;
    }

    public int getFacturas_id_facturas() {
        return facturas_id_facturas;
    }

    public void setFacturas_id_facturas(int facturas_id_facturas) {
        this.facturas_id_facturas = facturas_id_facturas;
    }

    public int getMetodos_pago_id_metodos_pago() {
        return metodos_pago_id_metodos_pago;
    }

    public void setMetodos_pago_id_metodos_pago(int metodos_pago_id_metodos_pago) {
        this.metodos_pago_id_metodos_pago = metodos_pago_id_metodos_pago;
    }
    private int id_pago;
    private int facturas_id_facturas;
    private int metodos_pago_id_metodos_pago;
    
}
