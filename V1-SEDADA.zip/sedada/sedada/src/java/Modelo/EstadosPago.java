/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class EstadosPago {
    
    private int id_estados_pago;
    private String nombres_estados_pago;

    public int getId_estados_pago() {
        return id_estados_pago;
    }

    public void setId_estados_pago(int id_estados_pago) {
        this.id_estados_pago = id_estados_pago;
    }

    public String getNombres_estados_pago() {
        return nombres_estados_pago;
    }

    public void setNombres_estados_pago(String nombres_estados_pago) {
        this.nombres_estados_pago = nombres_estados_pago;
    }
}