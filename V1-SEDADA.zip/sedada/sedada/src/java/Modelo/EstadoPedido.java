/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class EstadoPedido {
    
    private int id_estados_pedidos;
    private String nombres_estado_pedidos;

    public int getId_estados_pedidos() {
        return id_estados_pedidos;
    }

    public void setId_estados_pedidos(int id_estados_pedidos) {
        this.id_estados_pedidos = id_estados_pedidos;
    }

    public String getNombres_estado_pedidos() {
        return nombres_estado_pedidos;
    }

    public void setNombres_estado_pedidos(String nombres_estado_pedidos) {
        this.nombres_estado_pedidos = nombres_estado_pedidos;
    }
}