/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class Mesas {

    private int id_mesas;
    private int numero_mesas;
    private int capacidades;
    private int estados_mesa_id_estados_mesa;

    public int getId_mesas() {
        return id_mesas;
    }

    public void setId_mesas(int id_mesas) {
        this.id_mesas = id_mesas;
    }

    public int getNumero_mesas() {
        return numero_mesas;
    }

    public void setNumero_mesas(int numero_mesas) {
        this.numero_mesas = numero_mesas;
    }

    public int getCapacidades() {
        return capacidades;
    }

    public void setCapacidades(int capacidades) {
        this.capacidades = capacidades;
    }

    public int getEstados_mesa_id_estados_mesa() {
        return estados_mesa_id_estados_mesa;
    }

    public void setEstados_mesa_id_estados_mesa(int estados_mesa_id_estados_mesa) {
        this.estados_mesa_id_estados_mesa = estados_mesa_id_estados_mesa;
    }
}