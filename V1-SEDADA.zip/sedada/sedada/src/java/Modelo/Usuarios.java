
package Modelo;

import java.util.Date;

public class Usuarios {
    
    private int id_Usuarios;
    private String nombre_usuarios;
    private String apellido_usuarios;
    private String direccion_usuarios;
    private String telefonos;
    private String numero_documentos;
    private Date fecha_nacimientos;
    private Date fecha_vencimiento_claves;
    private String correos;
    private String passwords;
    private boolean autorizacion_datos;
    private int roles_id_roles;
    private int estados_usuarios_id_estados_usuario;
    private int tipo_de_documentos_id_tipo_de_documento;

    public int getId_Usuarios() {
        return id_Usuarios;
    }

    public void setId_Usuarios(int id_Usuarios) {
        this.id_Usuarios = id_Usuarios;
    }

    public String getNombre_usuarios() {
        return nombre_usuarios;
    }

    public void setNombre_usuarios(String nombre_usuarios) {
        this.nombre_usuarios = nombre_usuarios;
    }

    public String getApellido_usuarios() {
        return apellido_usuarios;
    }

    public void setApellido_usuarios(String apellido_usuarios) {
        this.apellido_usuarios = apellido_usuarios;
    }

    public String getDireccion_usuarios() {
        return direccion_usuarios;
    }

    public void setDireccion_usuarios(String direccion_usuarios) {
        this.direccion_usuarios = direccion_usuarios;
    }

    public String getTelefonos() {
        return telefonos;
    }

    public void setTelefonos(String telefonos) {
        this.telefonos = telefonos;
    }

    public String getNumero_documentos() {
        return numero_documentos;
    }

    public void setNumero_documentos(String numero_documentos) {
        this.numero_documentos = numero_documentos;
    }

    public Date getFecha_nacimientos() {
        return fecha_nacimientos;
    }

    public void setFecha_nacimientos(Date fecha_nacimientos) {
        this.fecha_nacimientos = fecha_nacimientos;
    }

    public Date getFecha_vencimiento_claves() {
        return fecha_vencimiento_claves;
    }

    public void setFecha_vencimiento_claves(Date fecha_vencimiento_claves) {
        this.fecha_vencimiento_claves = fecha_vencimiento_claves;
    }

    public String getCorreos() {
        return correos;
    }

    public void setCorreos(String correos) {
        this.correos = correos;
    }

    public String getPasswords() {
        return passwords;
    }

    public void setPasswords(String passwords) {
        this.passwords = passwords;
    }

    public boolean isAutorizacion_datos() {
        return autorizacion_datos;
    }

    public void setAutorizacion_datos(boolean autorizacion_datos) {
        this.autorizacion_datos = autorizacion_datos;
    }

    public int getRoles_id_roles() {
        return roles_id_roles;
    }

    public void setRoles_id_roles(int roles_id_roles) {
        this.roles_id_roles = roles_id_roles;
    }

    public int getEstados_usuarios_id_estados_usuario() {
        return estados_usuarios_id_estados_usuario;
    }

    public void setEstados_usuarios_id_estados_usuario(int estados_usuarios_id_estados_usuario) {
        this.estados_usuarios_id_estados_usuario = estados_usuarios_id_estados_usuario;
    }

    public int getTipo_de_documentos_id_tipo_de_documento() {
        return tipo_de_documentos_id_tipo_de_documento;
    }

    public void setTipo_de_documentos_id_tipo_de_documento(int tipo_de_documentos_id_tipo_de_documento) {
        this.tipo_de_documentos_id_tipo_de_documento = tipo_de_documentos_id_tipo_de_documento;
    }
    
    
} 