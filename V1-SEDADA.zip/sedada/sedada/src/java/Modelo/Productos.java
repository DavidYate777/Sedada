package Modelo;

import java.math.BigDecimal;

public class Productos {
    private int id_productos;
    private String nombres_productos;
    private String descripciones;
    private BigDecimal precios;
    private int categorias_id_categorias;
    private int estados_productos_id_estados_productos;
    private int impuestos_dian_id_impuestos_dian;

    public Productos() {
    }

    public int getId_productos() {
        return id_productos;
    }

    public void setId_productos(int id_productos) {
        this.id_productos = id_productos;
    }

    public String getNombres_productos() {
        return nombres_productos;
    }

    public void setNombres_productos(String nombres_productos) {
        this.nombres_productos = nombres_productos;
    }

    public String getDescripciones() {
        return descripciones;
    }

    public void setDescripciones(String descripciones) {
        this.descripciones = descripciones;
    }

    public BigDecimal getPrecios() {
        return precios;
    }

    public void setPrecios(BigDecimal precios) {
        this.precios = precios;
    }

    public int getCategorias_id_categorias() {
        return categorias_id_categorias;
    }

    public void setCategorias_id_categorias(int categorias_id_categorias) {
        this.categorias_id_categorias = categorias_id_categorias;
    }

    public int getEstados_productos_id_estados_productos() {
        return estados_productos_id_estados_productos;
    }

    public void setEstados_productos_id_estados_productos(int estados_productos_id_estados_productos) {
        this.estados_productos_id_estados_productos = estados_productos_id_estados_productos;
    }

    public int getImpuestos_dian_id_impuestos_dian() {
        return impuestos_dian_id_impuestos_dian;
    }

    public void setImpuestos_dian_id_impuestos_dian(int impuestos_dian_id_impuestos_dian) {
        this.impuestos_dian_id_impuestos_dian = impuestos_dian_id_impuestos_dian;
    }
}