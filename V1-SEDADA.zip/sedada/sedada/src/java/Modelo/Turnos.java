package Modelo;

import java.time.LocalTime;

public class Turnos {

    private int id_turnos;
    private String nombre_turno;
    private LocalTime hora_entrada;
    private LocalTime hora_salida;
    private int usuarios_id_Usuarios;

    public int getId_turnos() {
        return id_turnos;
    }

    public void setId_turnos(int id_turnos) {
        this.id_turnos = id_turnos;
    }

    public String getNombre_turno() {
        return nombre_turno;
    }

    public void setNombre_turno(String nombre_turno) {
        this.nombre_turno = nombre_turno;
    }

    public LocalTime getHora_entrada() {
        return hora_entrada;
    }

    public void setHora_entrada(LocalTime hora_entrada) {
        this.hora_entrada = hora_entrada;
    }

    public LocalTime getHora_salida() {
        return hora_salida;
    }

    public void setHora_salida(LocalTime hora_salida) {
        this.hora_salida = hora_salida;
    }

    public int getUsuarios_id_Usuarios() {
        return usuarios_id_Usuarios;
    }

    public void setUsuarios_id_Usuarios(int usuarios_id_Usuarios) {
        this.usuarios_id_Usuarios = usuarios_id_Usuarios;
    }
}