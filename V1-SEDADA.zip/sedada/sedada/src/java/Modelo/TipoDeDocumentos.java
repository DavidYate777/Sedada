
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class TipoDeDocumentos {
    
    private int id_tipo_de_documento;
    private String nombre_documento;
    

    public int getId_tipo_de_documento() {
        return id_tipo_de_documento;
    }

    public void setId_tipo_de_documento(int id_tipo_de_documento) {
        this.id_tipo_de_documento = id_tipo_de_documento;
    }

    public String getNombre_documento() {
        return nombre_documento;
    }

    public void setNombre_documento(String nombre_documento) {
        this.nombre_documento = nombre_documento;
    }
    
    
}
