/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class MetodosPago {
    
    private int id_metodos_pago;
    private String nombre_metodo_pago;

    public int getId_metodos_pago() {
        return id_metodos_pago;
    }

    public void setId_metodos_pago(int id_metodos_pago) {
        this.id_metodos_pago = id_metodos_pago;
    }

    public String getNombre_metodo_pago() {
        return nombre_metodo_pago;
    }

    public void setNombre_metodo_pago(String nombre_metodo_pago) {
        this.nombre_metodo_pago = nombre_metodo_pago;
    }
}