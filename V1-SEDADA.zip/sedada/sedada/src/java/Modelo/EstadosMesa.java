/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class EstadosMesa {

    private int id_estados_mesa;
    private String nombre_estado;

    public int getId_estados_mesa() {
        return id_estados_mesa;
    }

    public void setId_estados_mesa(int id_estados_mesa) {
        this.id_estados_mesa = id_estados_mesa;
    }

    public String getNombre_estado() {
        return nombre_estado;
    }

    public void setNombre_estado(String nombre_estado) {
        this.nombre_estado = nombre_estado;
    }
}