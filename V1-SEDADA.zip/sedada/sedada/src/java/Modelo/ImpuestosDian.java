/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;
import java.math.BigDecimal;
import java.time.LocalDate;
/**
 *
 * @author Aprendiz
 */
public class ImpuestosDian {

   
    private int id_impuestos_dian;
    private String nombres_impuestos;
    private BigDecimal porcentajes;
    private LocalDate fecha_inicio;
    private LocalDate fecha_fin;

    public int getId_impuestos_dian() {
        return id_impuestos_dian;
    }

    public void setId_impuestos_dian(int id_impuestos_dian) {
        this.id_impuestos_dian = id_impuestos_dian;
    }

    public String getNombres_impuestos() {
        return nombres_impuestos;
    }

    public void setNombres_impuestos(String nombres_impuestos) {
        this.nombres_impuestos = nombres_impuestos;
    }

    public BigDecimal getPorcentajes() {
        return porcentajes;
    }

    public void setPorcentajes(BigDecimal porcentajes) {
        this.porcentajes = porcentajes;
    }

    public LocalDate getFecha_inicio() {
        return fecha_inicio;
    }

    public void setFecha_inicio(LocalDate fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }

    public LocalDate getFecha_fin() {
        return fecha_fin;
    }

    public void setFecha_fin(LocalDate fecha_fin) {
        this.fecha_fin = fecha_fin;
    }

    
    
    
    
}
