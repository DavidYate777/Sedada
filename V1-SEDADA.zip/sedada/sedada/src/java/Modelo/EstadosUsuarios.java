package Modelo;

public class EstadosUsuarios {
    
    private int id_estados_usuario;
    private String nombre_estado;

    public int getId_estados_usuario() {
        return id_estados_usuario;
    }

    public void setId_estados_usuario(int id_estados_usuario) {
        this.id_estados_usuario = id_estados_usuario;
    }

    public String getNombre_estado() {
        return nombre_estado;
    }

    public void setNombre_estado(String nombre_estado) {
        this.nombre_estado = nombre_estado;
    }
}