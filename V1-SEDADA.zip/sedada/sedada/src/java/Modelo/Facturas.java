/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.math.BigDecimal;
import java.time.LocalDate;

/**
 *
 * @author Aprendiz
 */
public class Facturas {

    public int getId_facturas() {
        return id_facturas;
    }

    public void setId_facturas(int id_facturas) {
        this.id_facturas = id_facturas;
    }

    public String getNumero_facturas() {
        return numero_facturas;
    }

    public void setNumero_facturas(String numero_facturas) {
        this.numero_facturas = numero_facturas;
    }

    public LocalDate getFechas_facturas() {
        return fechas_facturas;
    }

    public void setFechas_facturas(LocalDate fechas_facturas) {
        this.fechas_facturas = fechas_facturas;
    }

    public BigDecimal getSubtotales() {
        return subtotales;
    }

    public void setSubtotales(BigDecimal subtotales) {
        this.subtotales = subtotales;
    }

    public BigDecimal getImpuestos() {
        return impuestos;
    }

    public void setImpuestos(BigDecimal impuestos) {
        this.impuestos = impuestos;
    }

    public BigDecimal getTotales() {
        return totales;
    }

    public void setTotales(BigDecimal totales) {
        this.totales = totales;
    }

    public int getPedidos_id_pedidos() {
        return pedidos_id_pedidos;
    }

    public void setPedidos_id_pedidos(int pedidos_id_pedidos) {
        this.pedidos_id_pedidos = pedidos_id_pedidos;
    }

    public int getEstados_pago_id_estados_pago() {
        return estados_pago_id_estados_pago;
    }

    public void setEstados_pago_id_estados_pago(int estados_pago_id_estados_pago) {
        this.estados_pago_id_estados_pago = estados_pago_id_estados_pago;
    }
    private int id_facturas;
    private String numero_facturas;
    private LocalDate fechas_facturas;
    private BigDecimal subtotales;
    private BigDecimal impuestos;
    private BigDecimal totales;
    private int pedidos_id_pedidos;
    private int estados_pago_id_estados_pago;
}
