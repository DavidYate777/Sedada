/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class Categoria {

    private int id_categorias;
    private String nombre_categorias;

    public int getId_categorias() {
        return id_categorias;
    }

    public void setId_categorias(int id_categorias) {
        this.id_categorias = id_categorias;
    }

    public String getNombre_categorias() {
        return nombre_categorias;
    }

    public void setNombre_categorias(String nombre_categorias) {
        this.nombre_categorias = nombre_categorias;
    }
}