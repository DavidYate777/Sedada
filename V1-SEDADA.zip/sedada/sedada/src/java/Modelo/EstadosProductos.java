/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Aprendiz
 */
public class EstadosProductos {
    
    private int id_estados_productos;
    private String nombre_estado_productos;

    public int getId_estados_productos() {
        return id_estados_productos;
    }

    public void setId_estados_productos(int id_estados_productos) {
        this.id_estados_productos = id_estados_productos;
    }

    public String getNombre_estado_productos() {
        return nombre_estado_productos;
    }

    public void setNombre_estado_productos(String nombre_estado_productos) {
        this.nombre_estado_productos = nombre_estado_productos;
    }
    

}
