/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.math.BigDecimal;

/**
 *
 * @author Aprendiz
 */
public class DetallePedidos {

    public int getId_detalle_pedido() {
        return id_detalle_pedido;
    }

    public void setId_detalle_pedido(int id_detalle_pedido) {
        this.id_detalle_pedido = id_detalle_pedido;
    }

    public int getCantidades() {
        return cantidades;
    }

    public void setCantidades(int cantidades) {
        this.cantidades = cantidades;
    }

    public BigDecimal getPrecio_unitario() {
        return precio_unitario;
    }

    public void setPrecio_unitario(BigDecimal precio_unitario) {
        this.precio_unitario = precio_unitario;
    }

    public String getNotas_especiales() {
        return notas_especiales;
    }

    public void setNotas_especiales(String notas_especiales) {
        this.notas_especiales = notas_especiales;
    }

    public int getProductos_id_productos() {
        return productos_id_productos;
    }

    public void setProductos_id_productos(int productos_id_productos) {
        this.productos_id_productos = productos_id_productos;
    }

    public int getPedidos_id_pedidos() {
        return pedidos_id_pedidos;
    }

    public void setPedidos_id_pedidos(int pedidos_id_pedidos) {
        this.pedidos_id_pedidos = pedidos_id_pedidos;
    }
    
    private int id_detalle_pedido;
    private int cantidades;
    private BigDecimal precio_unitario; 
    private String notas_especiales;
    private int productos_id_productos;
    private int pedidos_id_pedidos;
}
