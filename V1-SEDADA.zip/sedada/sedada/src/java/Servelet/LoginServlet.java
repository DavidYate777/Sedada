package Servelet;

import Controlador.Conexion;
import Controlador.UsuarioDAO;
import Controlador.RolesDAO;
import Modelo.Usuarios;
import Modelo.Roles;

import java.io.IOException;
import java.sql.Connection;

// Importaciones en jakarta
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // ==========================================
        // CODIFICACIÓN
        // ==========================================
        request.setCharacterEncoding("UTF-8");

        // ==========================================
        // OBTENER DATOS DEL FORMULARIO
        // ==========================================
        String correo = request.getParameter("email");
        String password = request.getParameter("password");

        // ==========================================
        // VALIDAR CAMPOS VACÍOS
        // ==========================================
        if (correo == null || correo.trim().isEmpty()
                || password == null || password.trim().isEmpty()) {

            response.sendRedirect(
                    request.getContextPath()
                    + "/login.jsp?error=campos"
            );
            return;
        }

        // ==========================================
        // INSTANCIAR USUARIO DAO
        // ==========================================
        UsuarioDAO usuarioDAO = new UsuarioDAO();

        // ==========================================
        // ABRIR CONEXIÓN Y VALIDAR
        // ==========================================
        try (Connection conexion = Conexion.getConnection()) {

            // AQUÍ SE LLAMA AL MÉTODO DE TU UsuarioDAO.java
            Usuarios usuario = usuarioDAO.validarUsuario(
                    correo,
                    password,
                    conexion
            );

            // ==========================================
            // CREDENCIALES INCORRECTAS (usuario es null)
            // ==========================================
            if (usuario == null) {
                response.sendRedirect(
                        request.getContextPath()
                        + "/login.jsp?error=credenciales"
                );
                return;
            }

            // ==========================================
            // LOGIN CORRECTO
            // ==========================================
            System.out.println("==========================================");
            System.out.println("LOGIN CORRECTO");
            System.out.println("ID: " + usuario.getId_Usuarios());
            System.out.println("NOMBRE: " + usuario.getNombre_usuarios());
            System.out.println("CORREO: " + usuario.getCorreos());
            System.out.println("ROL: " + usuario.getRoles_id_roles());
            System.out.println("==========================================");

            // Crear sesión HTTP y almacenar el objeto del usuario autenticado
            HttpSession session = request.getSession();
            session.setAttribute("usuarioLogueado", usuario);

            // ==========================================
            // REDIRECCIÓN SEGÚN EL ROL DEL USUARIO
            // ==========================================
            RolesDAO rolesDAO = new RolesDAO();
            Roles rol = rolesDAO.consultarRol(usuario.getRoles_id_roles(), conexion);
            String nombreRol = (rol != null && rol.getNombre_rol() != null)
                    ? rol.getNombre_rol().trim().toLowerCase()
                    : "";

            String destino;
            if (nombreRol.contains("mesero")) {
                destino = "/mesero/dashboard";
            } else if (nombreRol.contains("cajero")) {
                destino = "/cajero/dashboard";
            } else {
                // Administrador, Cocinero, Domiciliario u otro rol sin panel propio aún
                destino = "/admin/admin_dashboard";
            }

            response.sendRedirect(request.getContextPath() + destino);

        } catch (Exception e) {
            System.err.println("ERROR EN LOGIN: " + e.getMessage());
            e.printStackTrace();

            response.setContentType("text/html;charset=UTF-8");
            response.getWriter().println("<h1>Error al iniciar sesión</h1>");
            response.getWriter().println("<p>" + e.getMessage() + "</p>");
        }
    }

    @Override
    protected void doGet(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // Opcional: Manejo de cierre de sesión si se pasa ?accion=logout
        String accion = request.getParameter("accion");
        if ("logout".equals(accion)) {
            HttpSession session = request.getSession(false);
            if (session != null) {
                session.invalidate();
            }
            response.sendRedirect(request.getContextPath() + "/login.jsp");
        } else {
            response.sendRedirect(
                    request.getContextPath()
                    + "/login.jsp"
            );
        }
    }

    @Override
    public String getServletInfo() {
        return "Servlet de inicio de sesión SEDADA";
    }
}