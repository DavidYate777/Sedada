package Servelet;

import Controlador.Conexion;
import Controlador.MesasDAO;
import Controlador.PedidoDAO;
import Controlador.RolesDAO;
import Modelo.Mesas;
import Modelo.Pedido;
import Modelo.Roles;
import Modelo.Usuarios;

import java.io.IOException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Panel principal del rol Mesero. Muestra el estado del salón (mesas) y un
 * resumen de los pedidos que el mesero autenticado ha registrado.
 */
@WebServlet(name = "MeseroDashboardServlet", urlPatterns = {"/mesero/dashboard"})
public class MeseroDashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        Usuarios usuario = (Usuarios) session.getAttribute("usuarioLogueado");

        // Si quien ingresa es Cajero, lo enviamos a su propio panel.
        if (esRol(usuario, "cajero")) {
            response.sendRedirect(request.getContextPath() + "/cajero/dashboard");
            return;
        }

        try (Connection conn = Conexion.getConnection()) {
            MesasDAO mesasDAO = new MesasDAO();
            PedidoDAO pedidoDAO = new PedidoDAO();

            List<Mesas> listaMesas = mesasDAO.consultarTodas(conn);
            long mesasDisponibles = 0;
            long mesasOcupadas = 0;
            if (listaMesas != null) {
                for (Mesas m : listaMesas) {
                    if (m.getEstados_mesa_id_estados_mesa() == 1) {
                        mesasDisponibles++;
                    } else if (m.getEstados_mesa_id_estados_mesa() == 2) {
                        mesasOcupadas++;
                    }
                }
            }

            List<Pedido> todosPedidos = pedidoDAO.consultar(conn);
            List<Pedido> pedidosPropios = new ArrayList<>();
            if (todosPedidos != null) {
                for (Pedido p : todosPedidos) {
                    if (p.getUsuarios_id_usuarios() == usuario.getId_Usuarios()) {
                        pedidosPropios.add(p);
                    }
                }
            }
            // Los más recientes primero
            pedidosPropios.sort((a, b) -> Integer.compare(b.getId_pedidos(), a.getId_pedidos()));

            List<Pedido> recientes = pedidosPropios.size() > 5
                    ? pedidosPropios.subList(0, 5)
                    : pedidosPropios;

            request.setAttribute("totalMesas", listaMesas != null ? listaMesas.size() : 0);
            request.setAttribute("mesasDisponibles", mesasDisponibles);
            request.setAttribute("mesasOcupadas", mesasOcupadas);
            request.setAttribute("totalPedidosPropios", pedidosPropios.size());
            request.setAttribute("pedidosRecientes", recientes);

        } catch (Exception e) {
            System.err.println("Error al cargar el panel del mesero: " + e.getMessage());
            e.printStackTrace();
        }

        request.getRequestDispatcher("/mesero/mesero_dashboard.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    /**
     * Determina si el usuario autenticado tiene el rol indicado, comparando
     * por nombre (sin importar mayúsculas) contra la tabla roles.
     */
    private boolean esRol(Usuarios usuario, String nombreEsperado) {
        try {
            RolesDAO rolesDAO = new RolesDAO();
            Roles rol = rolesDAO.consultarRol(usuario.getRoles_id_roles());
            return rol != null && rol.getNombre_rol() != null
                    && rol.getNombre_rol().trim().equalsIgnoreCase(nombreEsperado);
        } catch (Exception e) {
            return false;
        }
    }
}
