package Servelet;

import Controlador.Conexion;
import Controlador.EstadosPagoDAO;
import Controlador.FacturasDAO;
import Controlador.PedidoDAO;
import Controlador.RolesDAO;
import Modelo.EstadosPago;
import Modelo.Facturas;
import Modelo.Pedido;
import Modelo.Roles;
import Modelo.Usuarios;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Panel principal del rol Cajero. Resume cuántos pedidos están pendientes de
 * facturar, cuánto se ha facturado en el día y cuántas facturas siguen sin
 * pago registrado.
 */
@WebServlet(name = "CajeroDashboardServlet", urlPatterns = {"/cajero/dashboard"})
public class CajeroDashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        Usuarios usuario = (Usuarios) session.getAttribute("usuarioLogueado");
        if (esRol(usuario, "mesero")) {
            response.sendRedirect(request.getContextPath() + "/mesero/dashboard");
            return;
        }

        try (Connection conn = Conexion.getConnection()) {
            PedidoDAO pedidoDAO = new PedidoDAO();
            FacturasDAO facturasDAO = new FacturasDAO();
            EstadosPagoDAO estadosPagoDAO = new EstadosPagoDAO();

            List<Pedido> todosPedidos = pedidoDAO.consultar(conn);
            List<Facturas> todasFacturas = facturasDAO.consultar(conn);

            Set<Integer> pedidosFacturados = new HashSet<>();
            if (todasFacturas != null) {
                for (Facturas f : todasFacturas) {
                    pedidosFacturados.add(f.getPedidos_id_pedidos());
                }
            }

            int pedidosPorFacturar = 0;
            if (todosPedidos != null) {
                for (Pedido p : todosPedidos) {
                    if (!pedidosFacturados.contains(p.getId_pedidos())) {
                        pedidosPorFacturar++;
                    }
                }
            }

            int idEstadoPendientePago = resolverIdEstadoPagoPorNombre(
                    estadosPagoDAO.consultarTodos(conn), "pendiente", 1);

            int facturasPendientesPago = 0;
            int facturasHoy = 0;
            BigDecimal totalFacturadoHoy = BigDecimal.ZERO;
            LocalDate hoy = LocalDate.now();

            if (todasFacturas != null) {
                for (Facturas f : todasFacturas) {
                    if (f.getEstados_pago_id_estados_pago() == idEstadoPendientePago) {
                        facturasPendientesPago++;
                    }
                    if (f.getFechas_facturas() != null && f.getFechas_facturas().isEqual(hoy)) {
                        facturasHoy++;
                        if (f.getTotales() != null) {
                            totalFacturadoHoy = totalFacturadoHoy.add(f.getTotales());
                        }
                    }
                }
            }

            request.setAttribute("pedidosPorFacturar", pedidosPorFacturar);
            request.setAttribute("facturasPendientesPago", facturasPendientesPago);
            request.setAttribute("facturasHoy", facturasHoy);
            request.setAttribute("totalFacturadoHoy", totalFacturadoHoy);
            request.setAttribute("totalFacturas", todasFacturas != null ? todasFacturas.size() : 0);

        } catch (Exception e) {
            System.err.println("Error al cargar el panel del cajero: " + e.getMessage());
            e.printStackTrace();
        }

        request.getRequestDispatcher("/cajero/cajero_dashboard.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    private int resolverIdEstadoPagoPorNombre(List<EstadosPago> estados, String nombreBuscado, int valorPorDefecto) {
        if (estados != null) {
            for (EstadosPago e : estados) {
                if (e.getNombres_estados_pago() != null
                        && e.getNombres_estados_pago().trim().toLowerCase().contains(nombreBuscado)) {
                    return e.getId_estados_pago();
                }
            }
        }
        return valorPorDefecto;
    }

    private boolean esRol(Usuarios usuario, String nombreEsperado) {
        try {
            RolesDAO rolesDAO = new RolesDAO();
            Roles rol = rolesDAO.consultarRol(usuario.getRoles_id_roles());
            return rol != null && rol.getNombre_rol() != null
                    && rol.getNombre_rol().trim().equalsIgnoreCase(nombreEsperado);
        } catch (Exception e) {
            return false;
        }
    }
}
