package Servelet;

import Controlador.Conexion;
import Controlador.PedidoDAO;
import Modelo.Pedido;
import Modelo.Usuarios;

import java.io.IOException;
import java.sql.Connection;
import java.time.LocalDateTime;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "AdminPedidosServlet", urlPatterns = {"/admin/pedidos"})
public class AdminPedidosServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        String accion = request.getParameter("accion");
        PedidoDAO pedidoDAO = new PedidoDAO();

        // Manejo de eliminación vía GET si se solicita
        if ("eliminar".equals(accion)) {
            try {
                int idPedido = Integer.parseInt(request.getParameter("id"));
                pedidoDAO.eliminar(idPedido);
            } catch (Exception e) {
                System.err.println("Error al eliminar pedido: " + e.getMessage());
            }
            response.sendRedirect(request.getContextPath() + "/admin/pedidos");
            return;
        }

        try (Connection conn = Conexion.getConnection()) {
            List<Pedido> listaPedidos = pedidoDAO.consultar(conn);
            request.setAttribute("listaPedidos", listaPedidos);
        } catch (Exception e) {
            System.err.println("Error al cargar los pedidos: " + e.getMessage());
            e.printStackTrace();
        }

        request.getRequestDispatcher("/admin/admin_pedidos.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String accion = request.getParameter("accion");
        PedidoDAO pedidoDAO = new PedidoDAO();
        Usuarios usuarioLogueado = (Usuarios) request.getSession().getAttribute("usuarioLogueado");

        if ("insertar".equals(accion)) {
            try {
                Pedido nuevoPedido = new Pedido();
                nuevoPedido.setFecha_horas(LocalDateTime.now());
                nuevoPedido.setUsuarios_id_usuarios(usuarioLogueado != null ? usuarioLogueado.getId_Usuarios() : 1);
                
                String mesaStr = request.getParameter("mesas_id_mesas");
                if (mesaStr != null && !mesaStr.isEmpty()) {
                    nuevoPedido.setMesas_id_mesas(Integer.parseInt(mesaStr));
                } else {
                    nuevoPedido.setMesas_id_mesas(null);
                }
                
                nuevoPedido.setDireccion_entrega(request.getParameter("direccion_entrega"));
                nuevoPedido.setTelefono_contacto(request.getParameter("telefono_contacto"));
                nuevoPedido.setEstados_pedidos_id_estados_pedidos(Integer.parseInt(request.getParameter("estados_pedidos_id_estados_pedidos")));

                pedidoDAO.insertar(nuevoPedido);
            } catch (Exception e) {
                System.err.println("Error al insertar pedido: " + e.getMessage());
            }
        } else if ("actualizar".equals(accion)) {
            try {
                int idPedido = Integer.parseInt(request.getParameter("id_pedidos"));
                Pedido pedido = pedidoDAO.consultarPorId(idPedido);
                
                if (pedido != null) {
                    String mesaStr = request.getParameter("mesas_id_mesas");
                    if (mesaStr != null && !mesaStr.isEmpty()) {
                        pedido.setMesas_id_mesas(Integer.parseInt(mesaStr));
                    } else {
                        pedido.setMesas_id_mesas(null);
                    }
                    
                    pedido.setDireccion_entrega(request.getParameter("direccion_entrega"));
                    pedido.setTelefono_contacto(request.getParameter("telefono_contacto"));
                    pedido.setEstados_pedidos_id_estados_pedidos(Integer.parseInt(request.getParameter("estados_pedidos_id_estados_pedidos")));

                    pedidoDAO.actualizar(pedido);
                }
            } catch (Exception e) {
                System.err.println("Error al actualizar pedido: " + e.getMessage());
            }
        }

        response.sendRedirect(request.getContextPath() + "/admin/pedidos");
    }
}