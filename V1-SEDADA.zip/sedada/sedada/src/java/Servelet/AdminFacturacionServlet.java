package Servelet;

import Controlador.FacturasDAO;
import Controlador.ImpuestosDianDAO;
import Modelo.Facturas;
import Modelo.ImpuestosDian;
import Modelo.Usuarios;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "AdminFacturacionServlet", urlPatterns = {"/admin/facturas", "/admin/facturacion"})
public class AdminFacturacionServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        String accion = request.getParameter("accion");
        FacturasDAO facturasDAO = new FacturasDAO();
        ImpuestosDianDAO impuestosDAO = new ImpuestosDianDAO();

        if ("eliminar".equals(accion)) {
            try {
                int idFactura = Integer.parseInt(request.getParameter("id"));
                facturasDAO.eliminar(idFactura);
            } catch (Exception e) {
                System.err.println("Error al eliminar factura: " + e.getMessage());
            }
            response.sendRedirect(request.getContextPath() + "/admin/facturas");
            return;
        }

        String idDetalle = request.getParameter("detalle_id");
        if (idDetalle != null) {
            try {
                int facturaId = Integer.parseInt(idDetalle);
                Facturas facturaSeleccionada = facturasDAO.consultarPorId(facturaId);
                request.setAttribute("facturaSeleccionada", facturaSeleccionada);
            } catch (Exception e) {
                System.err.println("Error al cargar detalle de factura: " + e.getMessage());
            }
        }

        try {
            List<Facturas> listaFacturas = facturasDAO.consultar();
            List<ImpuestosDian> listaImpuestos = impuestosDAO.consultarTodos();
            
            request.setAttribute("listaFacturas", listaFacturas);
            request.setAttribute("listaImpuestos", listaImpuestos);
            
            BigDecimal totalInvoicedToday = BigDecimal.ZERO;
            BigDecimal totalTaxCollected = BigDecimal.ZERO;
            
            for (Facturas f : listaFacturas) {
                if (f.getTotales() != null) {
                    totalInvoicedToday = totalInvoicedToday.add(f.getTotales());
                }
                if (f.getImpuestos() != null) {
                    totalTaxCollected = totalTaxCollected.add(f.getImpuestos());
                }
            }
            
            request.setAttribute("totalInvoicedToday", totalInvoicedToday);
            request.setAttribute("totalTaxCollected", totalTaxCollected);

        } catch (Exception e) {
            System.err.println("Error al cargar facturación: " + e.getMessage());
            e.printStackTrace();
        }

        request.getRequestDispatcher("/admin/admin_facturas.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String accion = request.getParameter("accion");
        FacturasDAO facturasDAO = new FacturasDAO();
        ImpuestosDianDAO impuestosDAO = new ImpuestosDianDAO();

        if ("insertar_factura".equals(accion)) {
            try {
                Facturas nuevaFactura = new Facturas();
                nuevaFactura.setNumero_facturas(request.getParameter("numero_facturas"));
                nuevaFactura.setFechas_facturas(LocalDate.now());
                nuevaFactura.setSubtotales(new BigDecimal(request.getParameter("subtotales")));
                nuevaFactura.setImpuestos(new BigDecimal(request.getParameter("impuestos")));
                nuevaFactura.setTotales(new BigDecimal(request.getParameter("totales")));
                nuevaFactura.setPedidos_id_pedidos(Integer.parseInt(request.getParameter("pedidos_id_pedidos")));
                nuevaFactura.setEstados_pago_id_estados_pago(Integer.parseInt(request.getParameter("estados_pago_id_estados_pago")));

                facturasDAO.insertar(nuevaFactura);
            } catch (Exception e) {
                System.err.println("Error al insertar factura: " + e.getMessage());
            }
        } else if ("insertar_impuesto".equals(accion)) {
            try {
                ImpuestosDian nuevoImpuesto = new ImpuestosDian();
                nuevoImpuesto.setNombres_impuestos(request.getParameter("nombres_impuestos"));
                nuevoImpuesto.setPorcentajes(new BigDecimal(request.getParameter("porcentajes")));
                nuevoImpuesto.setFecha_inicio(LocalDate.parse(request.getParameter("fechas_inicio")));
                nuevoImpuesto.setFecha_fin(LocalDate.parse(request.getParameter("fechas_fin")));

                impuestosDAO.insertarImpuesto(nuevoImpuesto);
            } catch (Exception e) {
                System.err.println("Error al insertar impuesto DIAN: " + e.getMessage());
            }
        }

        response.sendRedirect(request.getContextPath() + "/admin/facturas");
    }
}