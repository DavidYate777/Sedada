package Servelet;

import Controlador.UsuarioDAO;
import Modelo.Usuarios;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "PerfilServlet", urlPatterns = {"/perfil"})
public class PerfilServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        request.getRequestDispatcher("/perfil/mi_perfil.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession(false);

        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        Usuarios usuarioActual = (Usuarios) session.getAttribute("usuarioLogueado");

        String nombre = request.getParameter("nombre_usuarios");
        String apellido = request.getParameter("apellido_usuarios");
        String telefono = request.getParameter("telefonos");
        String direccion = request.getParameter("direccion_usuarios");

        if (nombre != null && !nombre.isBlank() && apellido != null && !apellido.isBlank()) {
            UsuarioDAO usuarioDAO = new UsuarioDAO();
            
            boolean actualizado = usuarioDAO.actualizarPerfil(
                usuarioActual.getId_Usuarios(), 
                nombre, 
                apellido, 
                telefono, 
                direccion
            );

            if (actualizado) {
                // Sincronizar datos en el objeto de sesión activa
                usuarioActual.setNombre_usuarios(nombre);
                usuarioActual.setApellido_usuarios(apellido);
                usuarioActual.setTelefonos(telefono);
                usuarioActual.setDireccion_usuarios(direccion);
                session.setAttribute("usuarioLogueado", usuarioActual);

                response.sendRedirect(request.getContextPath() + "/perfil?exito=true");
                return;
            }
        }

        response.sendRedirect(request.getContextPath() + "/perfil?error=true");
    }
}