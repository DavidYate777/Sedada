package Servelet;

import Controlador.CategoriaDAO;
import Controlador.Conexion;
import Controlador.DetallePedidosDAO;
import Controlador.EstadosPedidosDAO;
import Controlador.EstadosProductosDAO;
import Controlador.MesasDAO;
import Controlador.PedidoDAO;
import Controlador.ProductosDAO;
import Controlador.RolesDAO;
import Modelo.Categoria;
import Modelo.DetallePedidos;
import Modelo.EstadoPedido;
import Modelo.EstadosProductos;
import Modelo.Mesas;
import Modelo.Pedido;
import Modelo.Productos;
import Modelo.Roles;
import Modelo.Usuarios;

import java.io.IOException;
import java.sql.Connection;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet encargado de la toma de pedidos por parte del Mesero.
 *
 * GET  -> Lista las mesas disponibles, el catálogo de productos activos y el
 *         historial de pedidos ya registrados por el mesero autenticado.
 * POST -> accion=insertar_pedido registra un nuevo pedido (mesa o domicilio)
 *         junto con sus líneas de detalle (detalle_pedidos) en una sola
 *         operación, y marca la mesa como Ocupada cuando aplica.
 */
@WebServlet(name = "MeseroPedidosServlet", urlPatterns = {"/mesero/pedidos"})
public class MeseroPedidosServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        Usuarios usuario = (Usuarios) session.getAttribute("usuarioLogueado");
        if (esRol(usuario, "cajero")) {
            response.sendRedirect(request.getContextPath() + "/cajero/dashboard");
            return;
        }

        try (Connection conn = Conexion.getConnection()) {
            MesasDAO mesasDAO = new MesasDAO();
            ProductosDAO productosDAO = new ProductosDAO();
            CategoriaDAO categoriaDAO = new CategoriaDAO();
            EstadosProductosDAO estadosProductosDAO = new EstadosProductosDAO();
            EstadosPedidosDAO estadosPedidosDAO = new EstadosPedidosDAO();
            PedidoDAO pedidoDAO = new PedidoDAO();
            DetallePedidosDAO detalleDAO = new DetallePedidosDAO();

            // --- Mesas disponibles para asignar a un pedido nuevo ---
            List<Mesas> todasLasMesas = mesasDAO.consultarTodas(conn);
            List<Mesas> mesasDisponibles = new ArrayList<>();
            if (todasLasMesas != null) {
                for (Mesas m : todasLasMesas) {
                    if (m.getEstados_mesa_id_estados_mesa() == 1) {
                        mesasDisponibles.add(m);
                    }
                }
            }

            // --- Catálogo de productos activos, agrupado por categoría ---
            // CORREGIDO: Se cambia consultarTodos(conn) por consultar(conn)
            int idEstadoActivoProducto = resolverIdEstadoProductoPorNombre(
                    estadosProductosDAO.consultar(conn), "activo", 1);

            List<Productos> todosLosProductos = productosDAO.consultar(conn);
            List<Productos> productosActivos = new ArrayList<>();
            Map<Integer, Productos> mapaProductos = new HashMap<>();
            if (todosLosProductos != null) {
                for (Productos p : todosLosProductos) {
                    mapaProductos.put(p.getId_productos(), p);
                    if (p.getEstados_productos_id_estados_productos() == idEstadoActivoProducto) {
                        productosActivos.add(p);
                    }
                }
            }

            List<Categoria> listaCategorias = categoriaDAO.consultarTodas(conn);
            Map<Integer, String> mapaCategorias = new HashMap<>();
            if (listaCategorias != null) {
                for (Categoria c : listaCategorias) {
                    mapaCategorias.put(c.getId_categorias(), c.getNombre_categorias());
                }
            }

            // --- Estados de pedido, para mostrar el nombre en vez del ID ---
            List<EstadoPedido> listaEstadosPedido = estadosPedidosDAO.consultarTodos(conn);
            Map<Integer, String> mapaEstadosPedido = new HashMap<>();
            if (listaEstadosPedido != null) {
                for (EstadoPedido e : listaEstadosPedido) {
                    mapaEstadosPedido.put(e.getId_estados_pedidos(), e.getNombres_estado_pedidos());
                }
            }

            // --- Historial de pedidos del mesero autenticado, con sus líneas ---
            List<Pedido> todosPedidos = pedidoDAO.consultar(conn);
            List<DetallePedidos> todosDetalles = detalleDAO.consultar(conn);

            List<Pedido> pedidosPropios = new ArrayList<>();
            Map<Integer, List<DetallePedidos>> detallesPorPedido = new HashMap<>();
            if (todosPedidos != null) {
                for (Pedido p : todosPedidos) {
                    if (p.getUsuarios_id_usuarios() == usuario.getId_Usuarios()) {
                        pedidosPropios.add(p);
                        List<DetallePedidos> lineas = new ArrayList<>();
                        if (todosDetalles != null) {
                            for (DetallePedidos d : todosDetalles) {
                                if (d.getPedidos_id_pedidos() == p.getId_pedidos()) {
                                    lineas.add(d);
                                }
                            }
                        }
                        detallesPorPedido.put(p.getId_pedidos(), lineas);
                    }
                }
            }
            pedidosPropios.sort((a, b) -> Integer.compare(b.getId_pedidos(), a.getId_pedidos()));

            request.setAttribute("mesasDisponibles", mesasDisponibles);
            request.setAttribute("productosActivos", productosActivos);
            request.setAttribute("mapaCategorias", mapaCategorias);
            request.setAttribute("mapaProductos", mapaProductos);
            request.setAttribute("mapaEstadosPedido", mapaEstadosPedido);
            request.setAttribute("pedidosPropios", pedidosPropios);
            request.setAttribute("detallesPorPedido", detallesPorPedido);

        } catch (Exception e) {
            System.err.println("Error al cargar la toma de pedidos del mesero: " + e.getMessage());
            e.printStackTrace();
        }

        request.getRequestDispatcher("/mesero/mesero_pedidos.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        Usuarios usuario = (Usuarios) session.getAttribute("usuarioLogueado");
        String accion = request.getParameter("accion");

        if ("insertar_pedido".equals(accion)) {
            try (Connection conn = Conexion.getConnection()) {

                PedidoDAO pedidoDAO = new PedidoDAO();
                DetallePedidosDAO detalleDAO = new DetallePedidosDAO();
                MesasDAO mesasDAO = new MesasDAO();
                EstadosPedidosDAO estadosPedidosDAO = new EstadosPedidosDAO();
                ProductosDAO productosDAO = new ProductosDAO();

                String tipoPedido = request.getParameter("tipo_pedido"); // "mesa" o "domicilio"

                Pedido nuevoPedido = new Pedido();
                nuevoPedido.setFecha_horas(LocalDateTime.now());
                nuevoPedido.setUsuarios_id_usuarios(usuario.getId_Usuarios());

                int idEstadoPendiente = resolverIdEstadoPedidoPorNombre(
                        estadosPedidosDAO.consultarTodos(conn), "pendiente", 1);
                nuevoPedido.setEstados_pedidos_id_estados_pedidos(idEstadoPendiente);

                Integer idMesaSeleccionada = null;
                if ("mesa".equals(tipoPedido)) {
                    String mesaStr = request.getParameter("mesas_id_mesas");
                    if (mesaStr != null && !mesaStr.isBlank()) {
                        idMesaSeleccionada = Integer.parseInt(mesaStr);
                    }
                    nuevoPedido.setMesas_id_mesas(idMesaSeleccionada);
                    nuevoPedido.setDireccion_entrega(null);
                    nuevoPedido.setTelefono_contacto(request.getParameter("telefono_contacto"));
                } else {
                    nuevoPedido.setMesas_id_mesas(null);
                    nuevoPedido.setDireccion_entrega(request.getParameter("direccion_entrega"));
                    nuevoPedido.setTelefono_contacto(request.getParameter("telefono_contacto"));
                }

                boolean pedidoInsertado = pedidoDAO.insertar(nuevoPedido, conn);

                if (pedidoInsertado) {
                    // Como PedidoDAO no retorna la llave generada, se ubica el
                    // pedido recién creado por el mayor ID perteneciente a este mesero.
                    int idPedidoNuevo = obtenerUltimoIdPedido(pedidoDAO.consultar(conn), usuario.getId_Usuarios());

                    if (idPedidoNuevo > 0) {
                        String[] idsProductos = request.getParameterValues("producto_id");
                        String[] cantidades = request.getParameterValues("cantidad");
                        String[] notas = request.getParameterValues("nota");

                        if (idsProductos != null) {
                            for (int i = 0; i < idsProductos.length; i++) {
                                int cantidad = (cantidades != null && i < cantidades.length
                                        && cantidades[i] != null && !cantidades[i].isBlank())
                                        ? Integer.parseInt(cantidades[i]) : 0;

                                if (cantidad > 0) {
                                    int idProducto = Integer.parseInt(idsProductos[i]);
                                    Productos producto = productosDAO.consultarPorId(idProducto, conn);

                                    if (producto != null) {
                                        DetallePedidos linea = new DetallePedidos();
                                        linea.setCantidades(cantidad);
                                        linea.setPrecio_unitario(producto.getPrecios());
                                        linea.setNotas_especiales(
                                                (notas != null && i < notas.length) ? notas[i] : null);
                                        linea.setProductos_id_productos(idProducto);
                                        linea.setPedidos_id_pedidos(idPedidoNuevo);

                                        detalleDAO.insertar(linea, conn);
                                    }
                                }
                            }
                        }
                    }

                    // Si el pedido es en mesa, se marca la mesa como Ocupada (2)
                    if (idMesaSeleccionada != null) {
                        Mesas mesa = mesasDAO.consultarMesa(idMesaSeleccionada, conn);
                        if (mesa != null) {
                            mesa.setEstados_mesa_id_estados_mesa(2);
                            mesasDAO.actualizarMesa(mesa, conn);
                        }
                    }
                }

            } catch (Exception e) {
                System.err.println("Error al registrar el pedido del mesero: " + e.getMessage());
                e.printStackTrace();
            }
        }

        response.sendRedirect(request.getContextPath() + "/mesero/pedidos");
    }

    /**
     * Busca, dentro de una lista de pedidos, el mayor id_pedidos que
     * pertenezca al usuario indicado. Se usa para ubicar el pedido recién
     * insertado ya que el DAO de Pedido no expone la llave generada.
     */
    private int obtenerUltimoIdPedido(List<Pedido> pedidos, int idUsuario) {
        int maxId = -1;
        if (pedidos != null) {
            for (Pedido p : pedidos) {
                if (p.getUsuarios_id_usuarios() == idUsuario && p.getId_pedidos() > maxId) {
                    maxId = p.getId_pedidos();
                }
            }
        }
        return maxId;
    }

    /**
     * Resuelve el ID de un estado de pedido buscando coincidencia (parcial,
     * sin distinguir mayúsculas) en su nombre. Si no encuentra ninguna
     * coincidencia, retorna el valor por defecto indicado.
     */
    private int resolverIdEstadoPedidoPorNombre(List<EstadoPedido> estados, String nombreBuscado, int valorPorDefecto) {
        if (estados != null) {
            for (EstadoPedido e : estados) {
                if (e.getNombres_estado_pedidos() != null
                        && normalizar(e.getNombres_estado_pedidos()).contains(normalizar(nombreBuscado))) {
                    return e.getId_estados_pedidos();
                }
            }
        }
        return valorPorDefecto;
    }

    /**
     * Misma lógica que {@link #resolverIdEstadoPedidoPorNombre}, pero para la
     * tabla estados_productos.
     */
    private int resolverIdEstadoProductoPorNombre(List<EstadosProductos> estados, String nombreBuscado, int valorPorDefecto) {
        if (estados != null) {
            for (EstadosProductos e : estados) {
                if (e.getNombre_estado_productos() != null
                        && normalizar(e.getNombre_estado_productos()).contains(normalizar(nombreBuscado))) {
                    return e.getId_estados_productos();
                }
            }
        }
        return valorPorDefecto;
    }

    private String normalizar(String texto) {
        return texto == null ? "" : texto.trim().toLowerCase();
    }

    private boolean esRol(Usuarios usuario, String nombreEsperado) {
        try {
            RolesDAO rolesDAO = new RolesDAO();
            Roles rol = rolesDAO.consultarRol(usuario.getRoles_id_roles());
            return rol != null && rol.getNombre_rol() != null
                    && rol.getNombre_rol().trim().equalsIgnoreCase(nombreEsperado);
        } catch (Exception e) {
            return false;
        }
    }
}