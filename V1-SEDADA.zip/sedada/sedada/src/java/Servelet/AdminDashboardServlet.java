package Servelet;

import Controlador.Conexion;
import Controlador.FacturasDAO;
import Controlador.MesasDAO;
import Controlador.PedidoDAO;
import Controlador.CategoriaDAO;
import Modelo.Facturas;
import Modelo.Mesas;
import Modelo.Pedido;
import Modelo.Categoria;
import Modelo.Usuarios;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "AdminDashboardServlet", urlPatterns = {"/admin/admin_dashboard"})
public class AdminDashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        Usuarios usuario = (Usuarios) session.getAttribute("usuarioLogueado");

        try (Connection conn = Conexion.getConnection()) {
            PedidoDAO pedidoDAO = new PedidoDAO();
            MesasDAO mesasDAO = new MesasDAO();
            FacturasDAO facturasDAO = new FacturasDAO();
            CategoriaDAO categoriaDAO = new CategoriaDAO();

            List<Pedido> listaPedidos = pedidoDAO.consultar(conn);
            List<Mesas> listaMesas = mesasDAO.consultarTodas(conn);
            List<Facturas> listaFacturas = facturasDAO.consultar(conn);
            List<Categoria> listaCategorias = categoriaDAO.consultarTodas(conn);

            request.setAttribute("totalPedidos", listaPedidos != null ? listaPedidos.size() : 0);
            request.setAttribute("totalMesas", listaMesas != null ? listaMesas.size() : 0);
            request.setAttribute("totalCategorias", listaCategorias != null ? listaCategorias.size() : 0);
            request.setAttribute("listaPedidosRecientes", listaPedidos);
            request.setAttribute("listaFacturas", listaFacturas);

        } catch (Exception e) {
            System.err.println("Error al cargar datos del Dashboard: " + e.getMessage());
            e.printStackTrace();
        }

        request.getRequestDispatcher("/admin/admin_dashboard.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}