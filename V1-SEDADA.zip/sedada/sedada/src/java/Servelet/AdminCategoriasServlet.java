package Servelet;

import Controlador.CategoriaDAO;
import Modelo.Categoria;
import Modelo.Usuarios;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "AdminCategoriasServlet", urlPatterns = {"/admin/categorias", "/admin/categoria"})
public class AdminCategoriasServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("usuarioLogueado") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=sesion");
            return;
        }

        String accion = request.getParameter("accion");
        CategoriaDAO categoriaDAO = new CategoriaDAO();

        if ("eliminar".equals(accion)) {
            try {
                String idParam = request.getParameter("id");
                if (idParam != null && !idParam.trim().isEmpty()) {
                    int idCat = Integer.parseInt(idParam.trim());
                    categoriaDAO.eliminarCategoria(idCat);
                }
            } catch (Exception e) {
                System.err.println("Error al eliminar categoría (posible restricción de llave foránea): " + e.getMessage());
                e.printStackTrace();
            }
            response.sendRedirect(request.getContextPath() + "/admin/categorias");
            return;
        }

        String idDetalle = request.getParameter("detalle_id");
        if (idDetalle != null && !idDetalle.trim().isEmpty()) {
            try {
                int catId = Integer.parseInt(idDetalle.trim());
                Categoria categoriaSeleccionada = categoriaDAO.consultarCategoria(catId);
                request.setAttribute("categoriaSeleccionada", categoriaSeleccionada);
            } catch (Exception e) {
                System.err.println("Error al cargar detalle de categoría: " + e.getMessage());
            }
        }

        try {
            List<Categoria> listaCategorias = categoriaDAO.consultarTodas();
            request.setAttribute("listaCategorias", listaCategorias);
        } catch (Exception e) {
            System.err.println("Error al cargar categorías: " + e.getMessage());
            e.printStackTrace();
        }

        request.getRequestDispatcher("/admin/admin_categorias.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String accion = request.getParameter("accion");
        CategoriaDAO categoriaDAO = new CategoriaDAO();

        if ("insertar_categoria".equals(accion)) {
            try {
                String nombre = request.getParameter("nombre_categorias");
                if (nombre != null && !nombre.trim().isEmpty()) {
                    Categoria nuevaCat = new Categoria();
                    nuevaCat.setNombre_categorias(nombre.trim());
                    categoriaDAO.insertarCategoria(nuevaCat);
                }
            } catch (Exception e) {
                System.err.println("Error al insertar categoría: " + e.getMessage());
                e.printStackTrace();
            }
        } else if ("actualizar_categoria".equals(accion)) {
            try {
                String idParam = request.getParameter("id_categorias");
                String nombre = request.getParameter("nombre_categorias");
                if (idParam != null && !idParam.trim().isEmpty() && nombre != null && !nombre.trim().isEmpty()) {
                    Categoria catMod = new Categoria();
                    catMod.setId_categorias(Integer.parseInt(idParam.trim()));
                    catMod.setNombre_categorias(nombre.trim());
                    categoriaDAO.actualizarCategoria(catMod);
                }
            } catch (Exception e) {
                System.err.println("Error al actualizar categoría: " + e.getMessage());
                e.printStackTrace();
            }
        }

        response.sendRedirect(request.getContextPath() + "/admin/categorias");
    }
}