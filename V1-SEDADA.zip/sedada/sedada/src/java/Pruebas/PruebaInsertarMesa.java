package Pruebas;

import Controlador.MesasDAO;
import Modelo.Mesas;
import java.util.Scanner;

public class PruebaInsertarMesa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MesasDAO dao = new MesasDAO();
        Mesas mesa = new Mesas();
        
        System.out.print("Digite el número de la mesa: ");
        mesa.setNumero_mesas(scanner.nextInt());
        
        System.out.print("Digite la capacidad (número de personas): ");
        mesa.setCapacidades(scanner.nextInt());
        
        System.out.print("Digite el ID del estado inicial de la mesa: ");
        mesa.setEstados_mesa_id_estados_mesa(scanner.nextInt());
        
        boolean resultado = dao.insertarMesa(mesa);
        
        if (resultado) {
            System.out.println("¡Mesa insertada correctamente!");
        } else {
            System.out.println("Error al insertar la mesa.");
        }
        scanner.close();
    }
}