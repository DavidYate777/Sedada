package Pruebas;

import Controlador.MesasDAO;
import java.util.Scanner;

public class PruebaEliminarMesa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MesasDAO dao = new MesasDAO();
        
        System.out.print("Digite el ID de la mesa que desea eliminar físicamente: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminarMesa(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Mesa eliminada correctamente!");
        } else {
            System.out.println("Error al eliminar la mesa (puede estar asociada a pedidos activos).");
        }
        scanner.close();
    }
}