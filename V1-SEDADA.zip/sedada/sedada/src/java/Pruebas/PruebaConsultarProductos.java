package Pruebas;

import Controlador.ProductosDAO;
import Modelo.Productos;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarProductos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ProductosDAO dao = new ProductosDAO();
        
        System.out.print("Digite el ID del producto que desea consultar: ");
        int idProductoBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando producto con ID: " + idProductoBuscado + " ---");
        Productos producto = dao.consultarPorId(idProductoBuscado);
        
        if (producto != null) {
            System.out.println("Producto encontrado: " + producto.getNombres_productos());
            System.out.println("Descripción: " + producto.getDescripciones());
            System.out.println("Precio: " + producto.getPrecios());
        } else {
            System.out.println("No se encontró ningún producto con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todos los productos? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<Productos> lista = dao.consultar();
            System.out.println("\n--- Listando todos los productos ---");
            for (Productos p : lista) {
                System.out.println("ID: " + p.getId_productos() + " | Nombre: " + p.getNombres_productos() + " | Precio: " + p.getPrecios());
            }
        }
        scanner.close();
    }
}