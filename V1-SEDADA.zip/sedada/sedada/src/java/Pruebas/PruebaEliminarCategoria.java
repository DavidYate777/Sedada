package Pruebas;

import Controlador.CategoriaDAO;
import java.util.Scanner;

public class PruebaEliminarCategoria {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CategoriaDAO dao = new CategoriaDAO();
        
        System.out.print("Digite el ID de la categoría que desea eliminar: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminarCategoria(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Categoría eliminada correctamente!");
        } else {
            System.out.println("Error al eliminar la categoría (puede estar asociada a productos existentes).");
        }
        scanner.close();
    }
}