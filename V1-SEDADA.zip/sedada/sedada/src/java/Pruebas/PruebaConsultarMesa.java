package Pruebas;

import Controlador.MesasDAO;
import Modelo.Mesas;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarMesa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MesasDAO dao = new MesasDAO();
        
        System.out.print("Digite el ID de la mesa que desea consultar: ");
        int idMesaBuscada = scanner.nextInt();
        
        System.out.println("\n--- Consultando mesa con ID: " + idMesaBuscada + " ---");
        Mesas mesa = dao.consultarMesa(idMesaBuscada);
        
        if (mesa != null) {
            System.out.println("Mesa encontrada:");
            System.out.println("Número de Mesa: " + mesa.getNumero_mesas());
            System.out.println("Capacidad: " + mesa.getCapacidades());
            System.out.println("Estado ID: " + mesa.getEstados_mesa_id_estados_mesa());
        } else {
            System.out.println("No se encontró ninguna mesa con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todas las mesas? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<Mesas> lista = dao.consultarTodas();
            System.out.println("\n--- Listando todas las mesas ---");
            for (Mesas m : lista) {
                System.out.println("ID: " + m.getId_mesas() + " | N° Mesa: " + m.getNumero_mesas() + " | Capacidad: " + m.getCapacidades());
            }
        }
        scanner.close();
    }
}