package Pruebas;

import Controlador.ProductosDAO;
import java.util.Scanner;

public class PruebaActivarProducto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ProductosDAO dao = new ProductosDAO();
        
        System.out.print("Digite el ID del producto que desea activar: ");
        int idProducto = scanner.nextInt();
        
        System.out.print("Digite el ID del estado activo para productos en la BD: ");
        int idEstadoActivo = scanner.nextInt();
        
        boolean resultado = dao.activarProducto(idProducto, idEstadoActivo);
        
        if (resultado) {
            System.out.println("¡Producto activado correctamente!");
        } else {
            System.out.println("Error al activar el producto.");
        }
        scanner.close();
    }
}