package Pruebas;

import Controlador.PagosDAO;
import java.util.Scanner;

public class PruebaInactivarPago {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PagosDAO dao = new PagosDAO();
        
        System.out.print("Digite el ID del pago que desea inactivar: ");
        int idPago = scanner.nextInt();
        
        boolean resultado = dao.inactivarPago(idPago);
        
        if (resultado) {
            System.out.println("¡Pago inactivado correctamente!");
        } else {
            System.out.println("Error al inactivar el pago (verifique si la columna 'estado' existe en la tabla pago).");
        }
        scanner.close();
    }
}