package Pruebas;

import Controlador.DetalleFacturaDAO;
import java.util.Scanner;

public class PruebaEliminarDetalleFactura {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DetalleFacturaDAO dao = new DetalleFacturaDAO();
        
        System.out.print("Digite el ID del detalle de factura que desea eliminar: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminar(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Detalle de factura eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el detalle de factura.");
        }
        scanner.close();
    }
}