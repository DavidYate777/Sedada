package Pruebas;

import Controlador.PedidoDAO;
import java.util.Scanner;

public class PruebaInactivarPedido {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PedidoDAO dao = new PedidoDAO();
        
        System.out.print("Digite el ID del pedido que desea inactivar/cancelar: ");
        int idPedido = scanner.nextInt();
        
        System.out.print("Digite el ID del estado inactivo/cancelado para pedidos en la BD: ");
        int idEstadoInactivo = scanner.nextInt();
        
        boolean resultado = dao.inactivarPedido(idPedido, idEstadoInactivo);
        
        if (resultado) {
            System.out.println("¡Pedido inactivado correctamente!");
        } else {
            System.out.println("Error al inactivar el pedido.");
        }
        scanner.close();
    }
}