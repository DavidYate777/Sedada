package Pruebas;

import Controlador.MetodosPagoDAO;
import java.util.Scanner;

public class PruebaEliminarMetodoPago {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MetodosPagoDAO dao = new MetodosPagoDAO();
        
        System.out.print("Digite el ID del método de pago que desea eliminar: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminarMetodoPago(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Método de pago eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el método de pago (puede estar asociado a registros en la tabla pago).");
        }
        scanner.close();
    }
}