package Pruebas;

import Controlador.CategoriaDAO;
import Modelo.Categoria;
import java.util.Scanner;

public class PruebaInsertarCategoria {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CategoriaDAO dao = new CategoriaDAO();
        Categoria categoria = new Categoria();
        
        System.out.print("Digite el nombre de la nueva categoría (ej. Bebidas, Comidas Rápidas): ");
        categoria.setNombre_categorias(scanner.nextLine());
        
        boolean resultado = dao.insertarCategoria(categoria);
        
        if (resultado) {
            System.out.println("¡Categoría insertada correctamente!");
        } else {
            System.out.println("Error al insertar la categoría.");
        }
        scanner.close();
    }
}