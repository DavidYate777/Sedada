package Pruebas;

import Controlador.EstadosPagoDAO;
import Modelo.EstadosPago;
import java.util.Scanner;

public class PruebaInsertarEstadoPago {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosPagoDAO dao = new EstadosPagoDAO();
        EstadosPago estado = new EstadosPago();
        
        System.out.print("Digite el nombre del nuevo estado de pago (ej. Pagado, Pendiente): ");
        estado.setNombres_estados_pago(scanner.nextLine());
        
        boolean resultado = dao.insertarEstadoPago(estado);
        
        if (resultado) {
            System.out.println("¡Estado de pago insertado correctamente!");
        } else {
            System.out.println("Error al insertar el estado de pago.");
        }
        scanner.close();
    }
}