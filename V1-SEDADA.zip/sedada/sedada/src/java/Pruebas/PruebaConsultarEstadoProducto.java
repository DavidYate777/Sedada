package Pruebas;

import Controlador.EstadosProductosDAO;
import Modelo.EstadosProductos;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarEstadoProducto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosProductosDAO dao = new EstadosProductosDAO();
        
        System.out.print("Digite el ID del estado de producto que desea consultar: ");
        int idBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando estado de producto con ID: " + idBuscado + " ---");
        EstadosProductos estado = dao.consultarPorId(idBuscado);
        
        if (estado != null) {
            System.out.println("Estado encontrado: ID = " + estado.getId_estados_productos() + " | Nombre = " + estado.getNombre_estado_productos());
        } else {
            System.out.println("No se encontró ningún estado de producto con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todos los estados de productos? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<EstadosProductos> lista = dao.consultar();
            System.out.println("\n--- Listando todos los estados de productos ---");
            for (EstadosProductos ep : lista) {
                System.out.println("ID: " + ep.getId_estados_productos() + " | Nombre: " + ep.getNombre_estado_productos());
            }
        }
        scanner.close();
    }
}