package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuarios;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarUsuarios {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UsuarioDAO dao = new UsuarioDAO();
        
        System.out.print("Digite el ID del usuario que desea consultar: ");
        int idUsuarioBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando usuario con ID: " + idUsuarioBuscado + " ---");
        Usuarios usuario = dao.consultarPorId(idUsuarioBuscado);
        
        if (usuario != null) {
            System.out.println("Usuario encontrado: " + usuario.getNombre_usuarios() + " " + usuario.getApellido_usuarios());
            System.out.println("Correo: " + usuario.getCorreos());
        } else {
            System.out.println("No se encontró el usuario con el ID especificado.");
        }
        
        System.out.println("\n¿Desea ver la lista completa de todos los usuarios? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<Usuarios> lista = dao.consultar();
            System.out.println("\n--- Listando todos los usuarios ---");
            for (Usuarios u : lista) {
                System.out.println("ID: " + u.getId_Usuarios() + " | Nombre: " + u.getNombre_usuarios());
            }
        }
        scanner.close();
    }
}