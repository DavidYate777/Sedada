package Pruebas;

import Controlador.PedidoDAO;
import Modelo.Pedido;
import java.time.LocalDateTime;
import java.util.Scanner;

public class PruebaActualizarPedido {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PedidoDAO dao = new PedidoDAO();
        
        System.out.print("Digite el ID del pedido que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        Pedido pedido = dao.consultarPorId(idAModificar);
        
        if (pedido != null) {
            System.out.println("Pedido encontrado. Fecha/Hora actual: " + pedido.getFecha_horas());
            
            // Como la base de datos maneja timestamp with time zone, actualizamos con la fecha actual o la requerida al inicio del día
            pedido.setFecha_horas(LocalDateTime.now());
            
            System.out.print("Digite el nuevo ID de la mesa asignada: ");
            pedido.setMesas_id_mesas(scanner.nextInt());
            scanner.nextLine(); // Limpiar buffer
            
            System.out.print("Digite la nueva dirección de entrega: ");
            pedido.setDireccion_entrega(scanner.nextLine());
            
            System.out.print("Digite el nuevo teléfono de contacto: ");
            pedido.setTelefono_contacto(scanner.nextLine());
            
            System.out.print("Digite el nuevo ID del estado del pedido: ");
            pedido.setEstados_pedidos_id_estados_pedidos(scanner.nextInt());
            
            boolean resultado = dao.actualizar(pedido);
            
            if (resultado) {
                System.out.println("¡Pedido actualizado correctamente!");
            } else {
                System.out.println("Error al actualizar el pedido.");
            }
        } else {
            System.out.println("El pedido con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}