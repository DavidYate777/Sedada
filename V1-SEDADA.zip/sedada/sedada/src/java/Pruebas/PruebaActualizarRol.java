package Pruebas;

import Controlador.RolesDAO;
import Modelo.Roles;
import java.util.Scanner;

public class PruebaActualizarRol {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RolesDAO dao = new RolesDAO();
        
        System.out.print("Digite el ID del rol que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        Roles rol = dao.consultarRol(idAModificar);
        
        if (rol != null) {
            System.out.println("Nombre actual del rol: " + rol.getNombre_rol());
            
            System.out.print("Digite el nuevo nombre para el rol: ");
            rol.setNombre_rol(scanner.nextLine());
            
            boolean resultado = dao.actualizarRol(rol);
            
            if (resultado) {
                System.out.println("¡Rol actualizado correctamente!");
            } else {
                System.out.println("Error al actualizar el rol.");
            }
        } else {
            System.out.println("El rol con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}