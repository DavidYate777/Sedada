package Pruebas;

import Controlador.EstadosProductosDAO;
import Modelo.EstadosProductos;
import java.util.Scanner;

public class PruebaInsertarEstadoProducto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosProductosDAO dao = new EstadosProductosDAO();
        EstadosProductos estado = new EstadosProductos();
        
        System.out.print("Digite el nombre del nuevo estado de producto (ej. Disponible, Agotado): ");
        estado.setNombre_estado_productos(scanner.nextLine());
        
        boolean resultado = dao.insertar(estado);
        
        if (resultado) {
            System.out.println("¡Estado de producto insertado correctamente!");
        } else {
            System.out.println("Error al insertar el estado de producto.");
        }
        scanner.close();
    }
}