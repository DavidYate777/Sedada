package Pruebas;

import Controlador.EstadosPagoDAO;
import java.util.Scanner;

public class PruebaEliminarEstadoPago {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosPagoDAO dao = new EstadosPagoDAO();
        
        System.out.print("Digite el ID del estado de pago que desea eliminar: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminarEstadoPago(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Estado de pago eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el estado de pago (puede estar asociado a facturas existentes).");
        }
        scanner.close();
    }
}