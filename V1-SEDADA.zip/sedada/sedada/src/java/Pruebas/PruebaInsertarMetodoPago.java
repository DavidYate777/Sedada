package Pruebas;

import Controlador.MetodosPagoDAO;
import Modelo.MetodosPago;
import java.util.Scanner;

public class PruebaInsertarMetodoPago {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MetodosPagoDAO dao = new MetodosPagoDAO();
        MetodosPago metodo = new MetodosPago();
        
        System.out.print("Digite el nombre del nuevo método de pago (ej. Efectivo, Tarjeta): ");
        metodo.setNombre_metodo_pago(scanner.nextLine());
        
        boolean resultado = dao.insertarMetodoPago(metodo);
        
        if (resultado) {
            System.out.println("¡Método de pago insertado correctamente!");
        } else {
            System.out.println("Error al insertar el método de pago.");
        }
        scanner.close();
    }
}