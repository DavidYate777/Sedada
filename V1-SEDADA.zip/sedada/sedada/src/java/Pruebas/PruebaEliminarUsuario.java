package Pruebas;

import Controlador.UsuarioDAO;
import java.util.Scanner;

public class PruebaEliminarUsuario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UsuarioDAO dao = new UsuarioDAO();
        
        System.out.print("Digite el ID del usuario que desea eliminar de la base de datos: ");
        int idUsuarioAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminar(idUsuarioAEliminar);
        
        if (resultado) {
            System.out.println("¡Usuario eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el usuario (verifique si tiene registros asociados en otras tablas).");
        }
        scanner.close();
    }
}