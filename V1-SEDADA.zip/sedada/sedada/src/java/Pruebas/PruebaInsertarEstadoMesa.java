package Pruebas;

import Controlador.EstadosMesaDAO;
import Modelo.EstadosMesa;
import java.util.Scanner;

public class PruebaInsertarEstadoMesa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosMesaDAO dao = new EstadosMesaDAO();
        EstadosMesa estado = new EstadosMesa();
        
        System.out.print("Digite el nombre del nuevo estado de mesa (ej. Disponible, Ocupada): ");
        estado.setNombre_estado(scanner.nextLine());
        
        boolean resultado = dao.insertarEstadoMesa(estado);
        
        if (resultado) {
            System.out.println("¡Estado de mesa insertado correctamente!");
        } else {
            System.out.println("Error al insertar el estado de mesa.");
        }
        scanner.close();
    }
}