package Pruebas;

import Controlador.PedidoDAO;
import java.util.Scanner;

public class PruebaEliminarPedido {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PedidoDAO dao = new PedidoDAO();
        
        System.out.print("Digite el ID del pedido que desea eliminar físicamente: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminar(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Pedido eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el pedido (puede tener detalles de pedidos o facturas asociadas).");
        }
        scanner.close();
    }
}