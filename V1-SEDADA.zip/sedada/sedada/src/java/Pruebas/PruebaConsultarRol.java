package Pruebas;

import Controlador.RolesDAO;
import Modelo.Roles;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarRol {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RolesDAO dao = new RolesDAO();
        
        System.out.print("Digite el ID del rol que desea consultar: ");
        int idRolBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando rol con ID: " + idRolBuscado + " ---");
        Roles rol = dao.consultarRol(idRolBuscado);
        
        if (rol != null) {
            System.out.println("Rol encontrado: ID = " + rol.getId_roles() + " | Nombre = " + rol.getNombre_rol());
        } else {
            System.out.println("No se encontró ningún rol con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todos los roles? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<Roles> lista = dao.consultarTodos();
            System.out.println("\n--- Listando todos los roles ---");
            for (Roles r : lista) {
                System.out.println("ID: " + r.getId_roles() + " | Nombre: " + r.getNombre_rol());
            }
        }
        scanner.close();
    }
}