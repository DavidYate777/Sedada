package Pruebas;

import Controlador.PedidoDAO;
import Modelo.Pedido;
import java.time.LocalDateTime;
import java.util.Scanner;

public class PruebaInsertarPedido {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PedidoDAO dao = new PedidoDAO();
        Pedido pedido = new Pedido();
        
        // La fecha y hora se asignan automáticamente de forma limpia con LocalDateTime
        pedido.setFecha_horas(LocalDateTime.now());
        
        System.out.print("Digite el ID del usuario que realiza el pedido: ");
        pedido.setUsuarios_id_usuarios(scanner.nextInt());
        
        System.out.print("Digite el ID de la mesa asignada (o 0 si es a domicilio): ");
        int idMesa = scanner.nextInt();
        if (idMesa > 0) {
            pedido.setMesas_id_mesas(idMesa);
        } else {
            pedido.setMesas_id_mesas(null);
        }
        scanner.nextLine(); // Limpiar buffer
        
        System.out.print("Digite la dirección de entrega: ");
        pedido.setDireccion_entrega(scanner.nextLine());
        
        System.out.print("Digite el teléfono de contacto: ");
        pedido.setTelefono_contacto(scanner.nextLine());
        
        System.out.print("Digite el ID del estado inicial del pedido: ");
        pedido.setEstados_pedidos_id_estados_pedidos(scanner.nextInt());
        
        boolean resultado = dao.insertar(pedido);
        
        if (resultado) {
            System.out.println("¡Pedido insertado correctamente!");
        } else {
            System.out.println("Error al insertar el pedido.");
        }
        scanner.close();
    }
}