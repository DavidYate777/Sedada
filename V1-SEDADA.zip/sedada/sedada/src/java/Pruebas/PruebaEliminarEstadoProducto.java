package Pruebas;

import Controlador.EstadosProductosDAO;
import java.util.Scanner;

public class PruebaEliminarEstadoProducto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosProductosDAO dao = new EstadosProductosDAO();
        
        System.out.print("Digite el ID del estado de producto que desea eliminar: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminar(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Estado de producto eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el estado de producto (puede estar asignado a productos activos).");
        }
        scanner.close();
    }
}