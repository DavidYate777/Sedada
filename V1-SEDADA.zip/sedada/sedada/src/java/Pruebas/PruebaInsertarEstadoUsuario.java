package Pruebas;

import Controlador.EstadosUsuariosDAO;
import Modelo.EstadosUsuarios;
import java.util.Scanner;

public class PruebaInsertarEstadoUsuario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosUsuariosDAO dao = new EstadosUsuariosDAO();
        EstadosUsuarios estado = new EstadosUsuarios();
        
        System.out.print("Digite el nombre del nuevo estado de usuario (ej. Activo, Inactivo): ");
        estado.setNombre_estado(scanner.nextLine());
        
        boolean resultado = dao.insertarEstadoUsuario(estado);
        
        if (resultado) {
            System.out.println("¡Estado de usuario insertado correctamente!");
        } else {
            System.out.println("Error al insertar el estado de usuario.");
        }
        scanner.close();
    }
}