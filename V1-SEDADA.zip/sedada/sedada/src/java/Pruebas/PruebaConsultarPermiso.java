package Pruebas;

import Controlador.PermisosDAO;
import Modelo.Permisos;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarPermiso {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PermisosDAO dao = new PermisosDAO();
        
        System.out.print("Digite el ID del permiso que desea consultar: ");
        int idPermisoBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando permiso con ID: " + idPermisoBuscado + " ---");
        Permisos permiso = dao.consultarPermiso(idPermisoBuscado);
        
        if (permiso != null) {
            System.out.println("Permiso encontrado: " + permiso.getNombre_permiso());
            System.out.println("Descripción: " + permiso.getDescripcion_permiso());
        } else {
            System.out.println("No se encontró ningún permiso con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todos los permisos? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<Permisos> lista = dao.consultarTodos();
            System.out.println("\n--- Listando todos los permisos ---");
            for (Permisos p : lista) {
                System.out.println("ID: " + p.getId_permisos() + " | Nombre: " + p.getNombre_permiso());
            }
        }
        scanner.close();
    }
}