package Pruebas;

import Controlador.ImpuestosDianDAO;
import java.util.Scanner;

public class PruebaEliminarImpuesto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ImpuestosDianDAO dao = new ImpuestosDianDAO();
        
        System.out.print("Digite el ID del impuesto DIAN que desea eliminar físicamente: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminarImpuesto(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Impuesto DIAN eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el impuesto (puede estar asociado a productos activos).");
        }
        scanner.close();
    }
}