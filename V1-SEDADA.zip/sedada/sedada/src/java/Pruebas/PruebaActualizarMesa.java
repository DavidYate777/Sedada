package Pruebas;

import Controlador.MesasDAO;
import Modelo.Mesas;
import java.util.Scanner;

public class PruebaActualizarMesa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MesasDAO dao = new MesasDAO();
        
        System.out.print("Digite el ID de la mesa que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        
        Mesas mesa = dao.consultarMesa(idAModificar);
        
        if (mesa != null) {
            System.out.println("Mesa actual - N°: " + mesa.getNumero_mesas() + " | Capacidad: " + mesa.getCapacidades());
            
            System.out.print("Digite el nuevo número de la mesa: ");
            mesa.setNumero_mesas(scanner.nextInt());
            
            System.out.print("Digite la nueva capacidad: ");
            mesa.setCapacidades(scanner.nextInt());
            
            System.out.print("Digite el nuevo ID del estado de la mesa: ");
            mesa.setEstados_mesa_id_estados_mesa(scanner.nextInt());
            
            boolean resultado = dao.actualizarMesa(mesa);
            
            if (resultado) {
                System.out.println("¡Mesa actualizada correctamente!");
            } else {
                System.out.println("Error al actualizar la mesa.");
            }
        } else {
            System.out.println("La mesa con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}