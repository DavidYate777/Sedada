package Pruebas;

import Controlador.FacturasDAO;
import Modelo.Facturas;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Scanner;

public class PruebaInsertarFactura {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        FacturasDAO dao = new FacturasDAO();
        Facturas factura = new Facturas();
        
        scanner.useLocale(java.util.Locale.US); // Asegurar el uso de punto para decimales
        
        System.out.print("Digite el número de la factura (ej. FAC-001): ");
        factura.setNumero_facturas(scanner.nextLine());
        
        System.out.print("Digite la fecha de la factura (Formato YYYY-MM-DD): ");
        factura.setFechas_facturas(LocalDate.parse(scanner.nextLine()));
        
        System.out.print("Digite el subtotal: ");
        factura.setSubtotales(scanner.nextBigDecimal());
        
        System.out.print("Digite los impuestos: ");
        factura.setImpuestos(scanner.nextBigDecimal());
        
        System.out.print("Digite el total: ");
        factura.setTotales(scanner.nextBigDecimal());
        
        System.out.print("Digite el ID del pedido asociado: ");
        factura.setPedidos_id_pedidos(scanner.nextInt());
        
        System.out.print("Digite el ID del estado de pago inicial: ");
        factura.setEstados_pago_id_estados_pago(scanner.nextInt());
        
        boolean resultado = dao.insertar(factura);
        
        if (resultado) {
            System.out.println("¡Factura insertada correctamente!");
        } else {
            System.out.println("Error al insertar la factura.");
        }
        scanner.close();
    }
}