package Pruebas;

import Controlador.PagosDAO;
import Modelo.Pago;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarPago {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PagosDAO dao = new PagosDAO();
        
        System.out.print("Digite el ID del pago que desea consultar: ");
        int idPagoBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando pago con ID: " + idPagoBuscado + " ---");
        Pago pago = dao.consultarPago(idPagoBuscado);
        
        if (pago != null) {
            System.out.println("Pago encontrado:");
            System.out.println("ID Pago: " + pago.getId_pago());
            System.out.println("ID Factura: " + pago.getFacturas_id_facturas());
            System.out.println("ID Método de Pago: " + pago.getMetodos_pago_id_metodos_pago());
        } else {
            System.out.println("No se encontró ningún pago con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todos los pagos? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<Pago> lista = dao.consultarTodos();
            System.out.println("\n--- Listando todos los pagos ---");
            for (Pago p : lista) {
                System.out.println("ID Pago: " + p.getId_pago() + " | Factura ID: " + p.getFacturas_id_facturas() + " | Método Pago ID: " + p.getMetodos_pago_id_metodos_pago());
            }
        }
        scanner.close();
    }
}