package Pruebas;

import Controlador.EstadosUsuariosDAO;
import Modelo.EstadosUsuarios;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarEstadoUsuario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosUsuariosDAO dao = new EstadosUsuariosDAO();
        
        System.out.print("Digite el ID del estado de usuario que desea consultar: ");
        int idBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando estado de usuario con ID: " + idBuscado + " ---");
        EstadosUsuarios estado = dao.consultarEstadoUsuario(idBuscado);
        
        if (estado != null) {
            System.out.println("Estado encontrado: ID = " + estado.getId_estados_usuario() + " | Nombre = " + estado.getNombre_estado());
        } else {
            System.out.println("No se encontró ningún estado de usuario con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todos los estados de usuario? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<EstadosUsuarios> lista = dao.consultarTodos();
            System.out.println("\n--- Listando todos los estados de usuario ---");
            for (EstadosUsuarios e : lista) {
                System.out.println("ID: " + e.getId_estados_usuario() + " | Nombre: " + e.getNombre_estado());
            }
        }
        scanner.close();
    }
}