package Pruebas;

import Controlador.FacturasDAO;
import java.util.Scanner;

public class PruebaActivarFactura {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        FacturasDAO dao = new FacturasDAO();
        
        System.out.print("Digite el ID de la factura que desea activar: ");
        int idFactura = scanner.nextInt();
        
        System.out.print("Digite el ID del estado de pago activo en la BD: ");
        int idEstadoActivo = scanner.nextInt();
        
        boolean resultado = dao.activarFactura(idFactura, idEstadoActivo);
        
        if (resultado) {
            System.out.println("¡Factura activada correctamente!");
        } else {
            System.out.println("Error al activar la factura.");
        }
        scanner.close();
    }
}