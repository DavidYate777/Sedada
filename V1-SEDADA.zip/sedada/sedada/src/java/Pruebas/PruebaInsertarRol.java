package Pruebas;

import Controlador.RolesDAO;
import Modelo.Roles;
import java.util.Scanner;

public class PruebaInsertarRol {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RolesDAO dao = new RolesDAO();
        Roles rol = new Roles();
        
        System.out.print("Digite el ID del nuevo rol: ");
        rol.setId_roles(scanner.nextInt());
        scanner.nextLine(); // Limpiar el buffer
        
        System.out.print("Digite el nombre del rol (ej. Administrador, Mesero): ");
        rol.setNombre_rol(scanner.nextLine());
        
        boolean resultado = dao.insertarRol(rol);
        
        if (resultado) {
            System.out.println("¡Rol insertado correctamente!");
        } else {
            System.out.println("Error al insertar el rol.");
        }
        scanner.close();
    }
}