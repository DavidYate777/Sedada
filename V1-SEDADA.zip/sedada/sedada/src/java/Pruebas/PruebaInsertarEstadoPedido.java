package Pruebas;

import Controlador.EstadosPedidosDAO;
import Modelo.EstadoPedido;
import java.util.Scanner;

public class PruebaInsertarEstadoPedido {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosPedidosDAO dao = new EstadosPedidosDAO();
        EstadoPedido estado = new EstadoPedido();
        
        System.out.print("Digite el nombre del nuevo estado de pedido (ej. Pendiente, Entregado): ");
        estado.setNombres_estado_pedidos(scanner.nextLine());
        
        boolean resultado = dao.insertarEstadoPedido(estado);
        
        if (resultado) {
            System.out.println("¡Estado de pedido insertado correctamente!");
        } else {
            System.out.println("Error al insertar el estado de pedido.");
        }
        scanner.close();
    }
}