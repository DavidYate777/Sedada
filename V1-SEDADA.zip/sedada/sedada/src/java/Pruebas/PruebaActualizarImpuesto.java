package Pruebas;

import Controlador.ImpuestosDianDAO;
import Modelo.ImpuestosDian;
import java.time.LocalDate;
import java.util.Scanner;

public class PruebaActualizarImpuesto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ImpuestosDianDAO dao = new ImpuestosDianDAO();
        
        scanner.useLocale(java.util.Locale.US);
        
        System.out.print("Digite el ID del impuesto DIAN que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        ImpuestosDian impuesto = dao.consultarImpuesto(idAModificar);
        
        if (impuesto != null) {
            System.out.println("Impuesto actual: " + impuesto.getNombres_impuestos() + " (" + impuesto.getPorcentajes() + "%)");
            
            System.out.print("Digite el nuevo nombre del impuesto: ");
            impuesto.setNombres_impuestos(scanner.nextLine());
            
            System.out.print("Digite el nuevo porcentaje: ");
            impuesto.setPorcentajes(scanner.nextBigDecimal());
            scanner.nextLine(); // Limpiar buffer
            
            System.out.print("Digite la nueva fecha de inicio (YYYY-MM-DD): ");
            impuesto.setFecha_inicio(LocalDate.parse(scanner.nextLine()));
            
            System.out.print("Digite la nueva fecha de fin (YYYY-MM-DD): ");
            impuesto.setFecha_fin(LocalDate.parse(scanner.nextLine()));
            
            boolean resultado = dao.actualizarImpuesto(impuesto);
            
            if (resultado) {
                System.out.println("¡Impuesto DIAN actualizado correctamente!");
            } else {
                System.out.println("Error al actualizar el impuesto DIAN.");
            }
        } else {
            System.out.println("El impuesto con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}