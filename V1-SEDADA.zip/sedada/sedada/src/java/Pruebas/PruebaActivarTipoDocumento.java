package Pruebas;

import Controlador.TipoDeDocumentosDAO;
import java.util.Scanner;

public class PruebaActivarTipoDocumento {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoDeDocumentosDAO dao = new TipoDeDocumentosDAO();
        
        System.out.print("Digite el ID del tipo de documento que desea activar: ");
        int idTipo = scanner.nextInt();
        
        System.out.print("Digite el ID del estado activo en su base de datos: ");
        int idEstadoActivo = scanner.nextInt();
        
        boolean resultado = dao.activarTipoDocumento(idTipo, idEstadoActivo);
        
        if (resultado) {
            System.out.println("¡Tipo de documento activado correctamente!");
        } else {
            System.out.println("Error al activar el tipo de documento.");
        }
        scanner.close();
    }
}