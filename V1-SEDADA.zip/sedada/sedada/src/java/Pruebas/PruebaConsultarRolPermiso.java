package Pruebas;

import Controlador.RolPermisoDAO;
import Modelo.RolPermisos;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarRolPermiso {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RolPermisoDAO dao = new RolPermisoDAO();
        
        System.out.print("Digite el ID del rol que desea consultar: ");
        int idRol = scanner.nextInt();
        
        System.out.print("Digite el ID del permiso que desea consultar: ");
        int idPermiso = scanner.nextInt();
        
        System.out.println("\n--- Consultando relación Rol-Permiso ---");
        RolPermisos rolPermiso = dao.consultarRolPermiso(idRol, idPermiso);
        
        if (rolPermiso != null) {
            System.out.println("¡Relación encontrada! Rol ID: " + rolPermiso.getRoles_id_roles() + " | Permiso ID: " + rolPermiso.getPermisos_id_permisos());
        } else {
            System.out.println("No se encontró ninguna relación con los IDs especificados.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todas las relaciones Rol-Permiso? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<RolPermisos> lista = dao.consultarTodos();
            System.out.println("\n--- Listando todas las relaciones ---");
            for (RolPermisos rp : lista) {
                System.out.println("Rol ID: " + rp.getRoles_id_roles() + " | Permiso ID: " + rp.getPermisos_id_permisos());
            }
        }
        scanner.close();
    }
}