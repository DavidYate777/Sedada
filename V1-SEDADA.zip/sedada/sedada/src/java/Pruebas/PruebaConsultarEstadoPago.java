package Pruebas;

import Controlador.EstadosPagoDAO;
import Modelo.EstadosPago;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarEstadoPago {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosPagoDAO dao = new EstadosPagoDAO();
        
        System.out.print("Digite el ID del estado de pago que desea consultar: ");
        int idBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando estado de pago con ID: " + idBuscado + " ---");
        EstadosPago estado = dao.consultarEstadoPago(idBuscado);
        
        if (estado != null) {
            System.out.println("Estado encontrado: ID = " + estado.getId_estados_pago() + " | Nombre = " + estado.getNombres_estados_pago());
        } else {
            System.out.println("No se encontró ningún estado de pago con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todos los estados de pago? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<EstadosPago> lista = dao.consultarTodos();
            System.out.println("\n--- Listando todos los estados de pago ---");
            for (EstadosPago ep : lista) {
                System.out.println("ID: " + ep.getId_estados_pago() + " | Nombre: " + ep.getNombres_estados_pago());
            }
        }
        scanner.close();
    }
}