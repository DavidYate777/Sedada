package Pruebas;

import Controlador.RolPermisoDAO;
import Modelo.RolPermisos;
import java.util.Scanner;

public class PruebaInsertarRolPermiso {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RolPermisoDAO dao = new RolPermisoDAO();
        RolPermisos rolPermiso = new RolPermisos();
        
        System.out.print("Digite el ID del rol: ");
        rolPermiso.setRoles_id_roles(scanner.nextInt());
        
        System.out.print("Digite el ID del permiso que se le asignará al rol: ");
        rolPermiso.setPermisos_id_permisos(scanner.nextInt());
        
        boolean resultado = dao.insertarRolPermiso(rolPermiso);
        
        if (resultado) {
            System.out.println("¡Relación Rol-Permiso insertada correctamente!");
        } else {
            System.out.println("Error al insertar la relación (verifique que existan el rol y el permiso, o que no esté duplicada).");
        }
        scanner.close();
    }
}