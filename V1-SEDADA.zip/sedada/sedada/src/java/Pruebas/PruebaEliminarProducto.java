package Pruebas;

import Controlador.ProductosDAO;
import java.util.Scanner;

public class PruebaEliminarProducto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ProductosDAO dao = new ProductosDAO();
        
        System.out.print("Digite el ID del producto que desea eliminar físicamente: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminar(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Producto eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el producto (puede tener registros asociados en detalles de pedidos).");
        }
        scanner.close();
    }
}