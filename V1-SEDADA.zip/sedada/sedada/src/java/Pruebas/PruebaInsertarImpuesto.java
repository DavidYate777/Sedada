package Pruebas;

import Controlador.ImpuestosDianDAO;
import Modelo.ImpuestosDian;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Scanner;

public class PruebaInsertarImpuesto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ImpuestosDianDAO dao = new ImpuestosDianDAO();
        ImpuestosDian impuesto = new ImpuestosDian();
        
        scanner.useLocale(java.util.Locale.US); // Para asegurar el manejo correcto de puntos decimales
        
        System.out.print("Digite el nombre del impuesto (ej. IVA 19%): ");
        impuesto.setNombres_impuestos(scanner.nextLine());
        
        System.out.print("Digite el porcentaje (ej. 19.00): ");
        impuesto.setPorcentajes(scanner.nextBigDecimal());
        scanner.nextLine(); // Limpiar buffer
        
        System.out.print("Digite la fecha de inicio (Formato YYYY-MM-DD): ");
        impuesto.setFecha_inicio(LocalDate.parse(scanner.nextLine()));
        
        System.out.print("Digite la fecha de fin (Formato YYYY-MM-DD): ");
        impuesto.setFecha_fin(LocalDate.parse(scanner.nextLine()));
        
        boolean resultado = dao.insertarImpuesto(impuesto);
        
        if (resultado) {
            System.out.println("¡Impuesto DIAN insertado correctamente!");
        } else {
            System.out.println("Error al insertar el impuesto DIAN.");
        }
        scanner.close();
    }
}