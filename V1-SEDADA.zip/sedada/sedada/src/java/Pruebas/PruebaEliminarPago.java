package Pruebas;

import Controlador.PagosDAO;
import java.util.Scanner;

public class PruebaEliminarPago {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PagosDAO dao = new PagosDAO();
        
        System.out.print("Digite el ID del pago que desea eliminar físicamente: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminarPago(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Pago eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el pago.");
        }
        scanner.close();
    }
}