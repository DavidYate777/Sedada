package Pruebas;

import Controlador.RolesDAO;
import java.util.Scanner;

public class PruebaInactivarRol {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RolesDAO dao = new RolesDAO();
        
        System.out.print("Digite el ID del rol que desea inactivar: ");
        int idRol = scanner.nextInt();
        
        boolean resultado = dao.inactivarRol(idRol);
        
        if (resultado) {
            System.out.println("¡Rol inactivado correctamente!");
        } else {
            System.out.println("Error al inactivar el rol (verifique si la columna 'estado' existe en la tabla roles).");
        }
        scanner.close();
    }
}