package Pruebas;

import Controlador.ProductosDAO;
import Modelo.Productos;
import java.math.BigDecimal;
import java.util.Scanner;

public class PruebaActualizarProducto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ProductosDAO dao = new ProductosDAO();
        
        scanner.useLocale(java.util.Locale.US);
        
        System.out.print("Digite el ID del producto que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        Productos producto = dao.consultarPorId(idAModificar);
        
        if (producto != null) {
            System.out.println("Producto actual: " + producto.getNombres_productos());
            
            System.out.print("Digite el nuevo nombre del producto: ");
            producto.setNombres_productos(scanner.nextLine());
            
            System.out.print("Digite la nueva descripción: ");
            producto.setDescripciones(scanner.nextLine());
            
            System.out.print("Digite el nuevo precio: ");
            producto.setPrecios(BigDecimal.valueOf(scanner.nextDouble()));
            scanner.nextLine(); // Limpiar buffer
            
            boolean resultado = dao.actualizar(producto);
            
            if (resultado) {
                System.out.println("¡Producto actualizado correctamente!");
            } else {
                System.out.println("Error al actualizar el producto.");
            }
        } else {
            System.out.println("El producto con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}