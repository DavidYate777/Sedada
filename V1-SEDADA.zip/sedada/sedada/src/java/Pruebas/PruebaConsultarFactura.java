package Pruebas;

import Controlador.FacturasDAO;
import Modelo.Facturas;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarFactura {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        FacturasDAO dao = new FacturasDAO();
        
        System.out.print("Digite el ID de la factura que desea consultar: ");
        int idFacturaBuscada = scanner.nextInt();
        
        System.out.println("\n--- Consultando factura con ID: " + idFacturaBuscada + " ---");
        Facturas factura = dao.consultarPorId(idFacturaBuscada);
        
        if (factura != null) {
            System.out.println("Factura encontrada:");
            System.out.println("Número de Factura: " + factura.getNumero_facturas());
            System.out.println("Fecha: " + factura.getFechas_facturas());
            System.out.println("Total: " + factura.getTotales());
            System.out.println("Estado de Pago ID: " + factura.getEstados_pago_id_estados_pago());
        } else {
            System.out.println("No se encontró ninguna factura con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todas las facturas? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<Facturas> lista = dao.consultar();
            System.out.println("\n--- Listando todas las facturas ---");
            for (Facturas f : lista) {
                System.out.println("ID: " + f.getId_facturas() + " | N°: " + f.getNumero_facturas() + " | Total: " + f.getTotales());
            }
        }
        scanner.close();
    }
}