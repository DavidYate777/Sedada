package Pruebas;

import Controlador.DetallePedidosDAO;
import Modelo.DetallePedidos;
import java.math.BigDecimal;
import java.util.Scanner;

public class PruebaActualizarDetallePedido {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DetallePedidosDAO dao = new DetallePedidosDAO();
        
        scanner.useLocale(java.util.Locale.US);
        
        System.out.print("Digite el ID del detalle de pedido que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        // Como el DAO no tiene consultarPorId explícito, podemos listar o instanciar directo con el ID conocido
        DetallePedidos detalle = new DetallePedidos();
        detalle.setId_detalle_pedido(idAModificar);
        
        System.out.print("Digite la nueva cantidad: ");
        detalle.setCantidades(scanner.nextInt());
        
        System.out.print("Digite el nuevo precio unitario: ");
        detalle.setPrecio_unitario(scanner.nextBigDecimal());
        scanner.nextLine(); // Limpiar buffer
        
        System.out.print("Digite las nuevas notas especiales: ");
        detalle.setNotas_especiales(scanner.nextLine());
        
        System.out.print("Digite el nuevo ID del producto: ");
        detalle.setProductos_id_productos(scanner.nextInt());
        
        System.out.print("Digite el nuevo ID del pedido: ");
        detalle.setPedidos_id_pedidos(scanner.nextInt());
        
        boolean resultado = dao.actualizar(detalle);
        
        if (resultado) {
            System.out.println("¡Detalle de pedido actualizado correctamente!");
        } else {
            System.out.println("Error al actualizar el detalle de pedido (verifique si el ID existe).");
        }
        scanner.close();
    }
}