package Pruebas;

import Controlador.EstadosPedidosDAO;
import java.util.Scanner;

public class PruebaEliminarEstadoPedido {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosPedidosDAO dao = new EstadosPedidosDAO();
        
        System.out.print("Digite el ID del estado de pedido que desea eliminar: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminarEstadoPedido(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Estado de pedido eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el estado de pedido (puede estar asociado a pedidos existentes).");
        }
        scanner.close();
    }
}   