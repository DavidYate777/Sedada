package Pruebas;

import Controlador.FacturasDAO;
import java.util.Scanner;

public class PruebaEliminarFactura {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        FacturasDAO dao = new FacturasDAO();
        
        System.out.print("Digite el ID de la factura que desea eliminar físicamente: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminar(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Factura eliminada correctamente!");
        } else {
            System.out.println("Error al eliminar la factura (puede tener pagos o detalles asociados).");
        }
        scanner.close();
    }
}