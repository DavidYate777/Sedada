package Pruebas;

import Controlador.TurnosDAO;
import Modelo.Turnos;
import java.time.LocalTime;
import java.util.Scanner;

public class PruebaActualizarTurno {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TurnosDAO dao = new TurnosDAO();
        
        System.out.print("Digite el ID del turno que desea actualizar: ");
        int idTurnoAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        Turnos turno = dao.consultarTurno(idTurnoAModificar);
        
        if (turno != null) {
            System.out.println("Turno actual: " + turno.getNombre_turno());
            
            System.out.print("Digite el nuevo nombre del turno: ");
            turno.setNombre_turno(scanner.nextLine());
            
            System.out.print("Digite la nueva hora de entrada (HH:MM): ");
            turno.setHora_entrada(LocalTime.parse(scanner.nextLine() + ":00"));
            
            System.out.print("Digite la nueva hora de salida (HH:MM): ");
            turno.setHora_salida(LocalTime.parse(scanner.nextLine() + ":00"));
            
            System.out.print("Digite el nuevo ID del usuario asignado: ");
            turno.setUsuarios_id_Usuarios(scanner.nextInt());
            
            boolean resultado = dao.actualizarTurno(turno); // Método correcto del DAO
            
            if (resultado) {
                System.out.println("¡Turno actualizado correctamente!");
            } else {
                System.out.println("Error al actualizar el turno.");
            }
        } else {
            System.out.println("El turno con ID " + idTurnoAModificar + " no existe.");
        }
        scanner.close();
    }
}