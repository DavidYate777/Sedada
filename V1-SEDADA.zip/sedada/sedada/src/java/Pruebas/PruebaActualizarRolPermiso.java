package Pruebas;

import Controlador.RolPermisoDAO;
import Modelo.RolPermisos;
import java.util.Scanner;

public class PruebaActualizarRolPermiso {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RolPermisoDAO dao = new RolPermisoDAO();
        
        System.out.print("Digite el ID del rol al que pertenece la relación: ");
        int idRol = scanner.nextInt();
        
        System.out.print("Digite el ID del permiso ACTUAL (el que desea cambiar): ");
        int permisoAntiguo = scanner.nextInt();
        
        // Verificamos si existe la relación antes de modificarla
        RolPermisos existente = dao.consultarRolPermiso(idRol, permisoAntiguo);
        
        if (existente != null) {
            System.out.print("Digite el NUEVO ID del permiso: ");
            int permisoNuevo = scanner.nextInt();
            
            RolPermisos rolPermisoActualizar = new RolPermisos();
            rolPermisoActualizar.setRoles_id_roles(idRol);
            rolPermisoActualizar.setPermisos_id_permisos(permisoNuevo);
            
            boolean resultado = dao.actualizarRolPermiso(rolPermisoActualizar, permisoAntiguo);
            
            if (resultado) {
                System.out.println("¡Relación Rol-Permiso actualizada correctamente!");
            } else {
                System.out.println("Error al actualizar la relación.");
            }
        } else {
            System.out.println("No existe una relación registrada con ese Rol y Permiso.");
        }
        scanner.close();
    }
}