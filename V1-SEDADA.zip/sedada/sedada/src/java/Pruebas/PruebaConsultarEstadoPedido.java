package Pruebas;

import Controlador.EstadosPedidosDAO;
import Modelo.EstadoPedido;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarEstadoPedido {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosPedidosDAO dao = new EstadosPedidosDAO();
        
        System.out.print("Digite el ID del estado de pedido que desea consultar: ");
        int idBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando estado de pedido con ID: " + idBuscado + " ---");
        EstadoPedido estado = dao.consultarEstadoPedido(idBuscado);
        
        if (estado != null) {
            System.out.println("Estado encontrado: ID = " + estado.getId_estados_pedidos() + " | Nombre = " + estado.getNombres_estado_pedidos());
        } else {
            System.out.println("No se encontró ningún estado de pedido con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todos los estados de pedido? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<EstadoPedido> lista = dao.consultarTodos();
            System.out.println("\n--- Listando todos los estados de pedido ---");
            for (EstadoPedido ep : lista) {
                System.out.println("ID: " + ep.getId_estados_pedidos() + " | Nombre: " + ep.getNombres_estado_pedidos());
            }
        }
        scanner.close();
    }
}