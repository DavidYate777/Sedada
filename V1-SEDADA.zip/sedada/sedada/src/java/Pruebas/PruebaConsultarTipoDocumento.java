package Pruebas;

import Controlador.TipoDeDocumentosDAO;
import Modelo.TipoDeDocumentos;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarTipoDocumento {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoDeDocumentosDAO dao = new TipoDeDocumentosDAO();
        
        System.out.print("Digite el ID del tipo de documento que desea consultar: ");
        int idBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando tipo de documento con ID: " + idBuscado + " ---");
        TipoDeDocumentos tipo = dao.consultarPorId(idBuscado);
        
        if (tipo != null) {
            System.out.println("Documento encontrado: " + tipo.getNombre_documento());
        } else {
            System.out.println("No se encontró ningún tipo de documento con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de tipos de documentos? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<TipoDeDocumentos> lista = dao.consultar();
            System.out.println("\n--- Listando todos los tipos de documentos ---");
            for (TipoDeDocumentos t : lista) {
                System.out.println("ID: " + t.getId_tipo_de_documento() + " | Nombre: " + t.getNombre_documento());
            }
        }
        scanner.close();
    }
}