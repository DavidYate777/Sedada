package Pruebas;

import Controlador.PagosDAO;
import Modelo.Pago;
import java.util.Scanner;

public class PruebaInsertarPago {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PagosDAO dao = new PagosDAO();
        Pago pago = new Pago();
        
        System.out.print("Digite el ID del nuevo pago: ");
        pago.setId_pago(scanner.nextInt());
        
        System.out.print("Digite el ID de la factura asociada: ");
        pago.setFacturas_id_facturas(scanner.nextInt());
        
        System.out.print("Digite el ID del método de pago: ");
        pago.setMetodos_pago_id_metodos_pago(scanner.nextInt());
        
        boolean resultado = dao.insertarPago(pago);
        
        if (resultado) {
            System.out.println("¡Pago insertado correctamente!");
        } else {
            System.out.println("Error al insertar el pago.");
        }
        scanner.close();
    }
}