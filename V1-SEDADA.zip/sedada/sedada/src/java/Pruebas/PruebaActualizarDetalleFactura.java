package Pruebas;

import Controlador.DetalleFacturaDAO;
import Modelo.DetalleFactura;
import java.math.BigDecimal;
import java.util.Scanner;

public class PruebaActualizarDetalleFactura {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DetalleFacturaDAO dao = new DetalleFacturaDAO();
        
        scanner.useLocale(java.util.Locale.US);
        
        System.out.print("Digite el ID del detalle de factura que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        
        DetalleFactura detalle = new DetalleFactura();
        detalle.setId_detalle_factura(idAModificar);
        
        System.out.print("Digite la nueva cantidad: ");
        detalle.setCantidades(scanner.nextInt());
        
        System.out.print("Digite el nuevo precio unitario facturado: ");
        detalle.setPrecios_unitarios_facturados(scanner.nextBigDecimal());
        
        System.out.print("Digite el nuevo valor del IVA de la línea: ");
        detalle.setValores_iva_lineas(scanner.nextBigDecimal());
        
        System.out.print("Digite el nuevo ID de la factura asociada: ");
        detalle.setFacturas_id_facturas(scanner.nextInt());
        
        System.out.print("Digite el nuevo ID del detalle de pedido asociado: ");
        detalle.setDetalle_pedidos_id_detalle_pedidos(scanner.nextInt());
        
        boolean resultado = dao.actualizar(detalle);
        
        if (resultado) {
            System.out.println("¡Detalle de factura actualizado correctamente!");
        } else {
            System.out.println("Error al actualizar el detalle de factura (verifique si el ID existe).");
        }
        scanner.close();
    }
}