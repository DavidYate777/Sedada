package Pruebas;

import Controlador.TurnosDAO;
import Modelo.Turnos;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarTurnos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TurnosDAO dao = new TurnosDAO();
        
        System.out.print("Digite el ID del turno que desea consultar: ");
        int idTurnoBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando turno con ID: " + idTurnoBuscado + " ---");
        Turnos turno = dao.consultarTurno(idTurnoBuscado); // Método correcto del DAO
        
        if (turno != null) {
            System.out.println("Turno encontrado: " + turno.getNombre_turno());
            System.out.println("Entrada: " + turno.getHora_entrada() + " | Salida: " + turno.getHora_salida());
        } else {
            System.out.println("No se encontró el turno con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de turnos? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<Turnos> lista = dao.consultarTodos(); // Método correcto del DAO
            System.out.println("\n--- Listando todos los turnos ---");
            for (Turnos t : lista) {
                System.out.println("ID: " + t.getId_turnos() + " | Turno: " + t.getNombre_turno());
            }
        }
        scanner.close();
    }
}