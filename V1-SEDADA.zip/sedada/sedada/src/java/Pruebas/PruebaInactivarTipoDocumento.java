package Pruebas;

import Controlador.TipoDeDocumentosDAO;
import java.util.Scanner;

public class PruebaInactivarTipoDocumento {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoDeDocumentosDAO dao = new TipoDeDocumentosDAO();
        
        System.out.print("Digite el ID del tipo de documento que desea inactivar: ");
        int idTipo = scanner.nextInt();
        
        System.out.print("Digite el ID del estado inactivo en su base de datos: ");
        int idEstadoInactivo = scanner.nextInt();
        
        boolean resultado = dao.inactivarTipoDocumento(idTipo, idEstadoInactivo);
        
        if (resultado) {
            System.out.println("¡Tipo de documento inactivado correctamente!");
        } else {
            System.out.println("Error al inactivar el tipo de documento.");
        }
        scanner.close();
    }
}