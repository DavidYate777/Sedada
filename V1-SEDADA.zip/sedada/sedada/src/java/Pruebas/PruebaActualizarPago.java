package Pruebas;

import Controlador.PagosDAO;
import Modelo.Pago;
import java.util.Scanner;

public class PruebaActualizarPago {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PagosDAO dao = new PagosDAO();
        
        System.out.print("Digite el ID del pago que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        
        Pago pago = dao.consultarPago(idAModificar);
        
        if (pago != null) {
            System.out.println("Pago encontrado. Factura actual ID: " + pago.getFacturas_id_facturas() + " | Método actual ID: " + pago.getMetodos_pago_id_metodos_pago());
            
            System.out.print("Digite el nuevo ID de la factura asociada: ");
            pago.setFacturas_id_facturas(scanner.nextInt());
            
            System.out.print("Digite el nuevo ID del método de pago: ");
            pago.setMetodos_pago_id_metodos_pago(scanner.nextInt());
            
            boolean resultado = dao.actualizarPago(pago);
            
            if (resultado) {
                System.out.println("¡Pago actualizado correctamente!");
            } else {
                System.out.println("Error al actualizar el pago.");
            }
        } else {
            System.out.println("El pago con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}