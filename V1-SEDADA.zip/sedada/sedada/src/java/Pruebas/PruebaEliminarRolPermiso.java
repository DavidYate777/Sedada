package Pruebas;

import Controlador.RolPermisoDAO;
import java.util.Scanner;

public class PruebaEliminarRolPermiso {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RolPermisoDAO dao = new RolPermisoDAO();
        
        System.out.print("Digite el ID del rol de la relación a eliminar: ");
        int idRol = scanner.nextInt();
        
        System.out.print("Digite el ID del permiso de la relación a eliminar: ");
        int idPermiso = scanner.nextInt();
        
        boolean resultado = dao.eliminarRolPermiso(idRol, idPermiso);
        
        if (resultado) {
            System.out.println("¡Relación Rol-Permiso eliminada correctamente!");
        } else {
            System.out.println("Error al eliminar la relación (verifique que los IDs ingresados existan).");
        }
        scanner.close();
    }
}