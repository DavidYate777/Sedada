package Pruebas;

import Controlador.UsuarioDAO;
import java.util.Scanner;

public class PruebaActivarUsuario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UsuarioDAO dao = new UsuarioDAO();
        
        System.out.print("Digite el ID del usuario que desea activar: ");
        int idUsuario = scanner.nextInt();
        
        System.out.print("Digite el ID del estado activo en su base de datos: ");
        int idEstadoActivo = scanner.nextInt();
        
        boolean resultado = dao.activarUsuario(idUsuario, idEstadoActivo);
        
        if (resultado) {
            System.out.println("¡Usuario activado correctamente!");
        } else {
            System.out.println("Error al activar el usuario.");
        }
        scanner.close();
    }
}