package Pruebas;

import Controlador.TurnosDAO;
import Modelo.Turnos;
import java.time.LocalTime;
import java.util.Scanner;

public class PruebaInsertarTurno {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TurnosDAO dao = new TurnosDAO();
        Turnos turno = new Turnos();
        
        System.out.print("Digite el ID del turno: ");
        turno.setId_turnos(scanner.nextInt());
        scanner.nextLine(); // Limpiar buffer
        
        System.out.print("Digite el nombre del turno (ej. Mañana, Tarde): ");
        turno.setNombre_turno(scanner.nextLine());
        
        System.out.print("Digite la hora de entrada (Formato HH:MM, ej. 08:00): ");
        turno.setHora_entrada(LocalTime.parse(scanner.nextLine() + ":00"));
        
        System.out.print("Digite la hora de salida (Formato HH:MM, ej. 16:00): ");
        turno.setHora_salida(LocalTime.parse(scanner.nextLine() + ":00"));
        
        System.out.print("Digite el ID del usuario asignado a este turno: ");
        turno.setUsuarios_id_Usuarios(scanner.nextInt());
        
        boolean resultado = dao.insertarTurno(turno); // Método correcto del DAO
        
        if (resultado) {
            System.out.println("¡Turno insertado correctamente!");
        } else {
            System.out.println("Error al insertar el turno.");
        }
        scanner.close();
    }
}