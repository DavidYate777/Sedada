package Pruebas;

import Controlador.EstadosPagoDAO;
import Modelo.EstadosPago;
import java.util.Scanner;

public class PruebaActualizarEstadoPago {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosPagoDAO dao = new EstadosPagoDAO();
        
        System.out.print("Digite el ID del estado de pago que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        EstadosPago estado = dao.consultarEstadoPago(idAModificar);
        
        if (estado != null) {
            System.out.println("Nombre actual: " + estado.getNombres_estados_pago());
            
            System.out.print("Digite el nuevo nombre del estado de pago: ");
            estado.setNombres_estados_pago(scanner.nextLine());
            
            boolean resultado = dao.actualizarEstadoPago(estado);
            
            if (resultado) {
                System.out.println("¡Estado de pago actualizado correctamente!");
            } else {
                System.out.println("Error al actualizar el estado de pago.");
            }
        } else {
            System.out.println("El estado de pago con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}