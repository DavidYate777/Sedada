package Pruebas;

import Controlador.DetallePedidosDAO;
import Modelo.DetallePedidos;
import java.math.BigDecimal;
import java.util.Scanner;

public class PruebaInsertarDetallePedido {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DetallePedidosDAO dao = new DetallePedidosDAO();
        DetallePedidos detalle = new DetallePedidos();
        
        scanner.useLocale(java.util.Locale.US); // Manejo correcto de puntos decimales
        
        System.out.print("Digite la cantidad: ");
        detalle.setCantidades(scanner.nextInt());
        
        System.out.print("Digite el precio unitario: ");
        detalle.setPrecio_unitario(scanner.nextBigDecimal());
        scanner.nextLine(); // Limpiar buffer
        
        System.out.print("Digite notas especiales (ej. Sin cebolla): ");
        detalle.setNotas_especiales(scanner.nextLine());
        
        System.out.print("Digite el ID del producto: ");
        detalle.setProductos_id_productos(scanner.nextInt());
        
        System.out.print("Digite el ID del pedido asociado: ");
        detalle.setPedidos_id_pedidos(scanner.nextInt());
        
        boolean resultado = dao.insertar(detalle);
        
        if (resultado) {
            System.out.println("¡Detalle de pedido insertado correctamente!");
        } else {
            System.out.println("Error al insertar el detalle de pedido.");
        }
        scanner.close();
    }
}