package Pruebas;

import Controlador.MetodosPagoDAO;
import Modelo.MetodosPago;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarMetodoPago {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MetodosPagoDAO dao = new MetodosPagoDAO();
        
        System.out.print("Digite el ID del método de pago que desea consultar: ");
        int idBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando método de pago con ID: " + idBuscado + " ---");
        MetodosPago metodo = dao.consultarMetodoPago(idBuscado);
        
        if (metodo != null) {
            System.out.println("Método encontrado: ID = " + metodo.getId_metodos_pago() + " | Nombre = " + metodo.getNombre_metodo_pago());
        } else {
            System.out.println("No se encontró ningún método de pago con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todos los métodos de pago? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<MetodosPago> lista = dao.consultarTodos();
            System.out.println("\n--- Listando todos los métodos de pago ---");
            for (MetodosPago m : lista) {
                System.out.println("ID: " + m.getId_metodos_pago() + " | Nombre: " + m.getNombre_metodo_pago());
            }
        }
        scanner.close();
    }
}