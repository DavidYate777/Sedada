package Pruebas;

import Controlador.EstadosMesaDAO;
import Modelo.EstadosMesa;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarEstadoMesa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosMesaDAO dao = new EstadosMesaDAO();
        
        System.out.print("Digite el ID del estado de mesa que desea consultar: ");
        int idBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando estado de mesa con ID: " + idBuscado + " ---");
        EstadosMesa estado = dao.consultarEstadoMesa(idBuscado);
        
        if (estado != null) {
            System.out.println("Estado encontrado: ID = " + estado.getId_estados_mesa() + " | Nombre = " + estado.getNombre_estado());
        } else {
            System.out.println("No se encontró ningún estado de mesa con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todos los estados de mesa? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<EstadosMesa> lista = dao.consultarTodos();
            System.out.println("\n--- Listando todos los estados de mesa ---");
            for (EstadosMesa em : lista) {
                System.out.println("ID: " + em.getId_estados_mesa() + " | Nombre: " + em.getNombre_estado());
            }
        }
        scanner.close();
    }
}