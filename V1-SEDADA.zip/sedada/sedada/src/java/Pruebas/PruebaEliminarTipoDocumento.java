package Pruebas;

import Controlador.TipoDeDocumentosDAO;
import java.util.Scanner;

public class PruebaEliminarTipoDocumento {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoDeDocumentosDAO dao = new TipoDeDocumentosDAO();
        
        System.out.print("Digite el ID del tipo de documento que desea eliminar: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminar(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Tipo de documento eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar (es posible que esté asociado a usuarios u otros registros).");
        }
        scanner.close();
    }
}