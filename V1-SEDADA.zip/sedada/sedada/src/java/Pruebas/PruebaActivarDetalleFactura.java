package Pruebas;

import Controlador.DetalleFacturaDAO;
import java.util.Scanner;

public class PruebaActivarDetalleFactura {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DetalleFacturaDAO dao = new DetalleFacturaDAO();
        
        System.out.print("Digite el ID del detalle de factura que desea activar: ");
        int idDetalle = scanner.nextInt();
        
        System.out.print("Digite el ID del estado activo en su base de datos: ");
        int idEstadoActivo = scanner.nextInt();
        
        boolean resultado = dao.activarDetalleFactura(idDetalle, idEstadoActivo);
        
        if (resultado) {
            System.out.println("¡Detalle de factura activado correctamente!");
        } else {
            System.out.println("Error al activar el detalle de factura.");
        }
        scanner.close();
    }
}