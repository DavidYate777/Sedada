package Pruebas;

import Controlador.PedidoDAO;
import Modelo.Pedido;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarPedido {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PedidoDAO dao = new PedidoDAO();
        
        System.out.print("Digite el ID del pedido que desea consultar: ");
        int idPedidoBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando pedido con ID: " + idPedidoBuscado + " ---");
        Pedido pedido = dao.consultarPorId(idPedidoBuscado);
        
        if (pedido != null) {
            System.out.println("Pedido encontrado.");
            System.out.println("Fecha/Hora: " + pedido.getFecha_horas());
            System.out.println("Usuario ID: " + pedido.getUsuarios_id_usuarios() + " | Mesa ID: " + pedido.getMesas_id_mesas());
            System.out.println("Dirección: " + pedido.getDireccion_entrega() + " | Teléfono: " + pedido.getTelefono_contacto());
            System.out.println("Estado ID: " + pedido.getEstados_pedidos_id_estados_pedidos());
        } else {
            System.out.println("No se encontró ningún pedido con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todos los pedidos? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<Pedido> lista = dao.consultar();
            System.out.println("\n--- Listando todos los pedidos ---");
            for (Pedido p : lista) {
                System.out.println("ID: " + p.getId_pedidos() + " | Fecha/Hora: " + p.getFecha_horas() + " | Estado ID: " + p.getEstados_pedidos_id_estados_pedidos());
            }
        }
        scanner.close();
    }
}