package Pruebas;

import Controlador.ProductosDAO;
import Modelo.Productos;
import java.math.BigDecimal;
import java.util.Scanner;

public class PruebaInsertarProducto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ProductosDAO dao = new ProductosDAO();
        Productos producto = new Productos();
        
        scanner.useLocale(java.util.Locale.US); // Para manejar los decimales con punto (.)
        
        System.out.print("Digite el nombre del producto: ");
        producto.setNombres_productos(scanner.nextLine());
        
        System.out.print("Digite la descripción del producto: ");
        producto.setDescripciones(scanner.nextLine());
        
        System.out.print("Digite el precio del producto: ");
        producto.setPrecios(BigDecimal.valueOf(scanner.nextDouble()));
        scanner.nextLine(); // Limpiar buffer después de leer número
        
        System.out.print("Digite el ID de la categoría: ");
        producto.setCategorias_id_categorias(scanner.nextInt());
        
        System.out.print("Digite el ID del estado inicial del producto: ");
        producto.setEstados_productos_id_estados_productos(scanner.nextInt());
        
        System.out.print("Digite el ID del impuesto DIAN: ");
        producto.setImpuestos_dian_id_impuestos_dian(scanner.nextInt());
        
        boolean resultado = dao.insertar(producto);
        
        if (resultado) {
            System.out.println("¡Producto insertado correctamente!");
        } else {
            System.out.println("Error al insertar el producto.");
        }
        scanner.close();
    }
}