package Pruebas;

import Controlador.ImpuestosDianDAO;
import Modelo.ImpuestosDian;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarImpuesto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ImpuestosDianDAO dao = new ImpuestosDianDAO();
        
        System.out.print("Digite el ID del impuesto DIAN que desea consultar: ");
        int idImpuestoBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando impuesto con ID: " + idImpuestoBuscado + " ---");
        ImpuestosDian impuesto = dao.consultarImpuesto(idImpuestoBuscado);
        
        if (impuesto != null) {
            System.out.println("Impuesto encontrado:");
            System.out.println("Nombre: " + impuesto.getNombres_impuestos());
            System.out.println("Porcentaje: " + impuesto.getPorcentajes() + "%");
            System.out.println("Vigencia: Desde " + impuesto.getFecha_inicio() + " hasta " + impuesto.getFecha_fin());
        } else {
            System.out.println("No se encontró ningún impuesto DIAN con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todos los impuestos? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<ImpuestosDian> lista = dao.consultarTodos();
            System.out.println("\n--- Listando todos los impuestos DIAN ---");
            for (ImpuestosDian i : lista) {
                System.out.println("ID: " + i.getId_impuestos_dian() + " | Nombre: " + i.getNombres_impuestos() + " | Porcentaje: " + i.getPorcentajes() + "%");
            }
        }
        scanner.close();
    }
}