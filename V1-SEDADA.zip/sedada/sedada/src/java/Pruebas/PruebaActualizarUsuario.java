package Pruebas;

import Controlador.UsuarioDAO;
import Modelo.Usuarios;
import java.util.Scanner;

public class PruebaActualizarUsuario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UsuarioDAO dao = new UsuarioDAO();
        
        System.out.print("Digite el ID del usuario que desea actualizar: ");
        int idUsuarioAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer
        
        Usuarios usuario = dao.consultarPorId(idUsuarioAModificar);
        
        if (usuario != null) {
            System.out.println("Usuario actual: " + usuario.getNombre_usuarios() + " " + usuario.getApellido_usuarios());
            
            System.out.print("Digite el nuevo nombre: ");
            String nuevoNombre = scanner.nextLine();
            System.out.print("Digite la nueva dirección: ");
            String nuevaDireccion = scanner.nextLine();
            
            usuario.setNombre_usuarios(nuevoNombre);
            usuario.setDireccion_usuarios(nuevaDireccion);
            
            boolean resultado = dao.actualizar(usuario);
            
            if (resultado) {
                System.out.println("¡Usuario actualizado correctamente!");
            } else {
                System.out.println("Error al actualizar el usuario.");
            }
        } else {
            System.out.println("El usuario con ID " + idUsuarioAModificar + " no existe.");
        }
        scanner.close();
    }
}