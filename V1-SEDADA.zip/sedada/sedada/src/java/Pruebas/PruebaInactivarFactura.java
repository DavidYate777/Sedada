package Pruebas;

import Controlador.FacturasDAO;
import java.util.Scanner;

public class PruebaInactivarFactura {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        FacturasDAO dao = new FacturasDAO();
        
        System.out.print("Digite el ID de la factura que desea anular/inactivar: ");
        int idFactura = scanner.nextInt();
        
        System.out.print("Digite el ID del estado de pago inactivo/anulado en la BD: ");
        int idEstadoInactivo = scanner.nextInt();
        
        boolean resultado = dao.inactivarFactura(idFactura, idEstadoInactivo);
        
        if (resultado) {
            System.out.println("¡Factura inactivada/anulada correctamente!");
        } else {
            System.out.println("Error al cambiar el estado de la factura.");
        }
        scanner.close();
    }
}