package Pruebas;

import Controlador.TipoDeDocumentosDAO;
import Modelo.TipoDeDocumentos;
import java.util.Scanner;

public class PruebaInsertarTipoDocumento {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoDeDocumentosDAO dao = new TipoDeDocumentosDAO();
        TipoDeDocumentos tipo = new TipoDeDocumentos();
        
        System.out.print("Digite el nombre del nuevo tipo de documento (ej. Cédula de Ciudadanía): ");
        tipo.setNombre_documento(scanner.nextLine());
        
        boolean resultado = dao.insertar(tipo);
        
        if (resultado) {
            System.out.println("¡Tipo de documento insertado correctamente!");
        } else {
            System.out.println("Error al insertar el tipo de documento.");
        }
        scanner.close();
    }
}