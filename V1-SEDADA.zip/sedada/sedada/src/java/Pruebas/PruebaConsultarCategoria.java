package Pruebas;

import Controlador.CategoriaDAO;
import Modelo.Categoria;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarCategoria {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CategoriaDAO dao = new CategoriaDAO();
        
        System.out.print("Digite el ID de la categoría que desea consultar: ");
        int idBuscado = scanner.nextInt();
        
        System.out.println("\n--- Consultando categoría con ID: " + idBuscado + " ---");
        Categoria categoria = dao.consultarCategoria(idBuscado);
        
        if (categoria != null) {
            System.out.println("Categoría encontrada: ID = " + categoria.getId_categorias() + " | Nombre = " + categoria.getNombre_categorias());
        } else {
            System.out.println("No se encontró ninguna categoría con el ID especificado.");
        }
        
        System.out.print("\n¿Desea ver la lista completa de todas las categorías? (1. Sí / 2. No): ");
        int opcion = scanner.nextInt();
        if (opcion == 1) {
            List<Categoria> lista = dao.consultarTodas();
            System.out.println("\n--- Listando todas las categorías ---");
            for (Categoria c : lista) {
                System.out.println("ID: " + c.getId_categorias() + " | Nombre: " + c.getNombre_categorias());
            }
        }
        scanner.close();
    }
}