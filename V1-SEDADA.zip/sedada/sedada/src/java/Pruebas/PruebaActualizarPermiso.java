package Pruebas;

import Controlador.PermisosDAO;
import Modelo.Permisos;
import java.util.Scanner;

public class PruebaActualizarPermiso {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PermisosDAO dao = new PermisosDAO();
        
        System.out.print("Digite el ID del permiso que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        Permisos permiso = dao.consultarPermiso(idAModificar);
        
        if (permiso != null) {
            System.out.println("Nombre actual: " + permiso.getNombre_permiso());
            
            System.out.print("Digite el nuevo nombre del permiso: ");
            permiso.setNombre_permiso(scanner.nextLine());
            
            System.out.print("Digite la nueva descripción del permiso: ");
            permiso.setDescripcion_permiso(scanner.nextLine());
            
            boolean resultado = dao.actualizarPermiso(permiso);
            
            if (resultado) {
                System.out.println("¡Permiso actualizado correctamente!");
            } else {
                System.out.println("Error al actualizar el permiso.");
            }
        } else {
            System.out.println("El permiso con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}