package Pruebas;

import Controlador.PermisosDAO;
import java.util.Scanner;

public class PruebaEliminarPermiso {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PermisosDAO dao = new PermisosDAO();
        
        System.out.print("Digite el ID del permiso que desea eliminar físicamente: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminarPermiso(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Permiso eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el permiso (puede estar asociado a roles en la tabla rol_permisos).");
        }
        scanner.close();
    }
}