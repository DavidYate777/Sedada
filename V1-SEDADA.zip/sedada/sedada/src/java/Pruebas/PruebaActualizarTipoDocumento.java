package Pruebas;

import Controlador.TipoDeDocumentosDAO;
import Modelo.TipoDeDocumentos;
import java.util.Scanner;

public class PruebaActualizarTipoDocumento {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TipoDeDocumentosDAO dao = new TipoDeDocumentosDAO();
        
        System.out.print("Digite el ID del tipo de documento que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        TipoDeDocumentos tipo = dao.consultarPorId(idAModificar);
        
        if (tipo != null) {
            System.out.println("Nombre actual: " + tipo.getNombre_documento());
            
            System.out.print("Digite el nuevo nombre del documento: ");
            tipo.setNombre_documento(scanner.nextLine());
            
            boolean resultado = dao.actualizar(tipo);
            
            if (resultado) {
                System.out.println("¡Tipo de documento actualizado correctamente!");
            } else {
                System.out.println("Error al actualizar el tipo de documento.");
            }
        } else {
            System.out.println("El tipo de documento con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}