package Pruebas;

import Controlador.MetodosPagoDAO;
import Modelo.MetodosPago;
import java.util.Scanner;

public class PruebaActualizarMetodoPago {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MetodosPagoDAO dao = new MetodosPagoDAO();
        
        System.out.print("Digite el ID del método de pago que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        MetodosPago metodo = dao.consultarMetodoPago(idAModificar);
        
        if (metodo != null) {
            System.out.println("Nombre actual: " + metodo.getNombre_metodo_pago());
            
            System.out.print("Digite el nuevo nombre del método de pago: ");
            metodo.setNombre_metodo_pago(scanner.nextLine());
            
            boolean resultado = dao.actualizarMetodoPago(metodo);
            
            if (resultado) {
                System.out.println("¡Método de pago actualizado correctamente!");
            } else {
                System.out.println("Error al actualizar el método de pago.");
            }
        } else {
            System.out.println("El método de pago con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}