package Pruebas;

import Controlador.UsuarioDAO;
import java.util.Scanner;

public class PruebaInactivarUsuario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UsuarioDAO dao = new UsuarioDAO();
        
        System.out.print("Digite el ID del usuario que desea inactivar: ");
        int idUsuario = scanner.nextInt();
        
        System.out.print("Digite el ID del estado inactivo en su base de datos: ");
        int idEstadoInactivo = scanner.nextInt();
        
        boolean resultado = dao.inactivarUsuario(idUsuario, idEstadoInactivo);
        
        if (resultado) {
            System.out.println("¡Usuario inactivado correctamente!");
        } else {
            System.out.println("Error al inactivar el usuario.");
        }
        scanner.close();
    }
}