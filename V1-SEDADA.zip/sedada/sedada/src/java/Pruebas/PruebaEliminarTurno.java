package Pruebas;

import Controlador.TurnosDAO;
import java.util.Scanner;

public class PruebaEliminarTurno {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TurnosDAO dao = new TurnosDAO();
        
        System.out.print("Digite el ID del turno que desea eliminar: ");
        int idTurnoAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminarTurno(idTurnoAEliminar); // Método correcto del DAO
        
        if (resultado) {
            System.out.println("¡Turno eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el turno.");
        }
        scanner.close();
    }
}