package Pruebas;

import Controlador.RolesDAO;
import java.util.Scanner;

public class PruebaEliminarRol {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        RolesDAO dao = new RolesDAO();
        
        System.out.print("Digite el ID del rol que desea eliminar físicamente: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminarRol(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Rol eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el rol (es probable que esté asignado a usuarios activos).");
        }
        scanner.close();
    }
}