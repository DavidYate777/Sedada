package Pruebas;

import Controlador.PermisosDAO;
import Modelo.Permisos;
import java.util.Scanner;

public class PruebaInsertarPermiso {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PermisosDAO dao = new PermisosDAO();
        Permisos permiso = new Permisos();
        
        System.out.print("Digite el ID del nuevo permiso: ");
        permiso.setId_permisos(scanner.nextInt());
        scanner.nextLine(); // Limpiar buffer
        
        System.out.print("Digite el nombre del permiso: ");
        permiso.setNombre_permiso(scanner.nextLine());
        
        System.out.print("Digite la descripción del permiso: ");
        permiso.setDescripcion_permiso(scanner.nextLine());
        
        boolean resultado = dao.insertarPermiso(permiso);
        
        if (resultado) {
            System.out.println("¡Permiso insertado correctamente!");
        } else {
            System.out.println("Error al insertar el permiso.");
        }
        scanner.close();
    }
}