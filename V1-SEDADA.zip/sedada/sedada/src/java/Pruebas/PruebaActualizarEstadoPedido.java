package Pruebas;

import Controlador.EstadosPedidosDAO;
import Modelo.EstadoPedido;
import java.util.Scanner;

public class PruebaActualizarEstadoPedido {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosPedidosDAO dao = new EstadosPedidosDAO();
        
        System.out.print("Digite el ID del estado de pedido que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        EstadoPedido estado = dao.consultarEstadoPedido(idAModificar);
        
        if (estado != null) {
            System.out.println("Nombre actual: " + estado.getNombres_estado_pedidos());
            
            System.out.print("Digite el nuevo nombre del estado de pedido: ");
            estado.setNombres_estado_pedidos(scanner.nextLine());
            
            boolean resultado = dao.actualizarEstadoPedido(estado);
            
            if (resultado) {
                System.out.println("¡Estado de pedido actualizado correctamente!");
            } else {
                System.out.println("Error al actualizar el estado de pedido.");
            }
        } else {
            System.out.println("El estado de pedido con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}