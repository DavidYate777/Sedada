package Pruebas;

import Controlador.DetallePedidosDAO;
import Modelo.DetallePedidos;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarDetallePedido {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DetallePedidosDAO dao = new DetallePedidosDAO();
        
        System.out.println("--- Consultando todos los detalles de pedidos ---");
        List<DetallePedidos> lista = dao.consultar();
        
        if (!lista.isEmpty()) {
            for (DetallePedidos dp : lista) {
                System.out.println("ID Detalle: " + dp.getId_detalle_pedido() + 
                                   " | Cantidad: " + dp.getCantidades() + 
                                   " | Precio Unitario: " + dp.getPrecio_unitario() + 
                                   " | Producto ID: " + dp.getProductos_id_productos() + 
                                   " | Pedido ID: " + dp.getPedidos_id_pedidos());
            }
        } else {
            System.out.println("No se encontraron registros en la tabla detalle_pedidos.");
        }
        
        scanner.close();
    }
}