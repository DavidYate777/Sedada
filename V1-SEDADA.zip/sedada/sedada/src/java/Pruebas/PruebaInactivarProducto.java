package Pruebas;

import Controlador.ProductosDAO;
import java.util.Scanner;

public class PruebaInactivarProducto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ProductosDAO dao = new ProductosDAO();
        
        System.out.print("Digite el ID del producto que desea inactivar: ");
        int idProducto = scanner.nextInt();
        
        System.out.print("Digite el ID del estado inactivo para productos en la BD: ");
        int idEstadoInactivo = scanner.nextInt();
        
        boolean resultado = dao.inactivarProducto(idProducto, idEstadoInactivo);
        
        if (resultado) {
            System.out.println("¡Producto inactivado correctamente!");
        } else {
            System.out.println("Error al inactivar el producto.");
        }
        scanner.close();
    }
}