package Pruebas;

import Controlador.EstadosUsuariosDAO;
import Modelo.EstadosUsuarios;
import java.util.Scanner;

public class PruebaActualizarEstadoUsuario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosUsuariosDAO dao = new EstadosUsuariosDAO();
        
        System.out.print("Digite el ID del estado de usuario que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        EstadosUsuarios estado = dao.consultarEstadoUsuario(idAModificar);
        
        if (estado != null) {
            System.out.println("Nombre actual: " + estado.getNombre_estado());
            
            System.out.print("Digite el nuevo nombre del estado de usuario: ");
            estado.setNombre_estado(scanner.nextLine());
            
            boolean resultado = dao.actualizarEstadoUsuario(estado);
            
            if (resultado) {
                System.out.println("¡Estado de usuario actualizado correctamente!");
            } else {
                System.out.println("Error al actualizar el estado de usuario.");
            }
        } else {
            System.out.println("El estado de usuario con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}