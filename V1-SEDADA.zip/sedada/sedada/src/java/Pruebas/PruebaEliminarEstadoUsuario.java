package Pruebas;

import Controlador.EstadosUsuariosDAO;
import java.util.Scanner;

public class PruebaEliminarEstadoUsuario {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosUsuariosDAO dao = new EstadosUsuariosDAO();
        
        System.out.print("Digite el ID del estado de usuario que desea eliminar: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminarEstadoUsuario(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Estado de usuario eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el estado de usuario (puede estar asignado a usuarios existentes).");
        }
        scanner.close();
    }
}