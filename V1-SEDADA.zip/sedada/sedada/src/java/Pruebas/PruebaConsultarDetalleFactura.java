package Pruebas;

import Controlador.DetalleFacturaDAO;
import Modelo.DetalleFactura;
import java.util.List;
import java.util.Scanner;

public class PruebaConsultarDetalleFactura {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DetalleFacturaDAO dao = new DetalleFacturaDAO();
        
        System.out.println("--- Consultando todos los detalles de factura ---");
        List<DetalleFactura> lista = dao.consultar();
        
        if (!lista.isEmpty()) {
            for (DetalleFactura df : lista) {
                System.out.println("ID Detalle: " + df.getId_detalle_factura() + 
                                   " | Cantidad: " + df.getCantidades() + 
                                   " | Precio Facturado: " + df.getPrecios_unitarios_facturados() + 
                                   " | IVA Línea: " + df.getValores_iva_lineas() + 
                                   " | Factura ID: " + df.getFacturas_id_facturas() + 
                                   " | Detalle Pedido ID: " + df.getDetalle_pedidos_id_detalle_pedidos());
            }
        } else {
            System.out.println("No se encontraron registros en la tabla detalle_factura.");
        }
        
        scanner.close();
    }
}