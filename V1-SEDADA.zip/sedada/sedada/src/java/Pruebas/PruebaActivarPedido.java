package Pruebas;

import Controlador.PedidoDAO;
import java.util.Scanner;

public class PruebaActivarPedido {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PedidoDAO dao = new PedidoDAO();
        
        System.out.print("Digite el ID del pedido que desea activar: ");
        int idPedido = scanner.nextInt();
        
        System.out.print("Digite el ID del estado activo para pedidos en la BD: ");
        int idEstadoActivo = scanner.nextInt();
        
        boolean resultado = dao.activarPedido(idPedido, idEstadoActivo);
        
        if (resultado) {
            System.out.println("¡Pedido activado correctamente!");
        } else {
            System.out.println("Error al activar el pedido.");
        }
        scanner.close();
    }
}