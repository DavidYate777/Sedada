package Pruebas;

import Controlador.EstadosProductosDAO;
import Modelo.EstadosProductos;
import java.util.Scanner;

public class PruebaActualizarEstadoProducto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosProductosDAO dao = new EstadosProductosDAO();
        
        System.out.print("Digite el ID del estado de producto que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        EstadosProductos estado = dao.consultarPorId(idAModificar);
        
        if (estado != null) {
            System.out.println("Nombre actual: " + estado.getNombre_estado_productos());
            
            System.out.print("Digite el nuevo nombre del estado de producto: ");
            estado.setNombre_estado_productos(scanner.nextLine());
            
            boolean resultado = dao.actualizar(estado);
            
            if (resultado) {
                System.out.println("¡Estado de producto actualizado correctamente!");
            } else {
                System.out.println("Error al actualizar el estado de producto.");
            }
        } else {
            System.out.println("El estado de producto con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}