package Pruebas;

import Controlador.DetalleFacturaDAO;
import Modelo.DetalleFactura;
import java.math.BigDecimal;
import java.util.Scanner;

public class PruebaInsertarDetalleFactura {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DetalleFacturaDAO dao = new DetalleFacturaDAO();
        DetalleFactura detalle = new DetalleFactura();
        
        scanner.useLocale(java.util.Locale.US); // Manejo correcto de puntos decimales
        
        System.out.print("Digite la cantidad: ");
        detalle.setCantidades(scanner.nextInt());
        
        System.out.print("Digite el precio unitario facturado: ");
        detalle.setPrecios_unitarios_facturados(scanner.nextBigDecimal());
        
        System.out.print("Digite el valor del IVA de la línea: ");
        detalle.setValores_iva_lineas(scanner.nextBigDecimal());
        
        System.out.print("Digite el ID de la factura asociada: ");
        detalle.setFacturas_id_facturas(scanner.nextInt());
        
        System.out.print("Digite el ID del detalle de pedido asociado: ");
        detalle.setDetalle_pedidos_id_detalle_pedidos(scanner.nextInt());
        
        boolean resultado = dao.insertar(detalle);
        
        if (resultado) {
            System.out.println("¡Detalle de factura insertado correctamente!");
        } else {
            System.out.println("Error al insertar el detalle de factura.");
        }
        scanner.close();
    }
}