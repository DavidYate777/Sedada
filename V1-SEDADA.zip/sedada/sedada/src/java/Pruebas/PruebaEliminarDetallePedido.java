package Pruebas;

import Controlador.DetallePedidosDAO;
import java.util.Scanner;

public class PruebaEliminarDetallePedido {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DetallePedidosDAO dao = new DetallePedidosDAO();
        
        System.out.print("Digite el ID del detalle de pedido que desea eliminar: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminar(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Detalle de pedido eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el detalle de pedido.");
        }
        scanner.close();
    }
}