package Pruebas;

import Controlador.Conexion;
import java.util.Scanner;

public class PruebaConexion {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("==========================================");
        System.out.println("   UTILIDAD DE PRUEBA DE CONEXIÓN DAO   ");
        System.out.println("==========================================");
        System.out.print("¿Desea probar la conexión con Supabase ahora? (1. Sí / 2. No): ");
        
        int opcion = scanner.nextInt();
        
        if (opcion == 1) {
            System.out.println("\nEjecutando diagnóstico de conexión...");
            boolean exito = Conexion.probarConexion();
            
            if (exito) {
                System.out.println("\n[ÉXITO] La aplicación se comunica correctamente con Supabase.");
            } else {
                System.out.println("\n[FALLO] No se pudo establecer la conexión. Revise las credenciales o su red.");
            }
        } else {
            System.out.println("Prueba cancelada por el usuario.");
        }
        
        scanner.close();
    }
}