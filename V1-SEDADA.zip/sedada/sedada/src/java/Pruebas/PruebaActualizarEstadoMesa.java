package Pruebas;

import Controlador.EstadosMesaDAO;
import Modelo.EstadosMesa;
import java.util.Scanner;

public class PruebaActualizarEstadoMesa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosMesaDAO dao = new EstadosMesaDAO();
        
        System.out.print("Digite el ID del estado de mesa que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        EstadosMesa estado = dao.consultarEstadoMesa(idAModificar);
        
        if (estado != null) {
            System.out.println("Nombre actual: " + estado.getNombre_estado());
            
            System.out.print("Digite el nuevo nombre del estado de mesa: ");
            estado.setNombre_estado(scanner.nextLine());
            
            boolean resultado = dao.actualizarEstadoMesa(estado);
            
            if (resultado) {
                System.out.println("¡Estado de mesa actualizado correctamente!");
            } else {
                System.out.println("Error al actualizar el estado de mesa.");
            }
        } else {
            System.out.println("El estado de mesa con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}