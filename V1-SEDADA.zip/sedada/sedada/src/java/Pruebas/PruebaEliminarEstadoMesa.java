package Pruebas;

import Controlador.EstadosMesaDAO;
import java.util.Scanner;

public class PruebaEliminarEstadoMesa {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EstadosMesaDAO dao = new EstadosMesaDAO();
        
        System.out.print("Digite el ID del estado de mesa que desea eliminar: ");
        int idAEliminar = scanner.nextInt();
        
        boolean resultado = dao.eliminarEstadoMesa(idAEliminar);
        
        if (resultado) {
            System.out.println("¡Estado de mesa eliminado correctamente!");
        } else {
            System.out.println("Error al eliminar el estado de mesa (puede estar asociado a mesas existentes).");
        }
        scanner.close();
    }
}