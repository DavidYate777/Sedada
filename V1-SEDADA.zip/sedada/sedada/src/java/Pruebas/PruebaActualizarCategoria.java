package Pruebas;

import Controlador.CategoriaDAO;
import Modelo.Categoria;
import java.util.Scanner;

public class PruebaActualizarCategoria {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CategoriaDAO dao = new CategoriaDAO();
        
        System.out.print("Digite el ID de la categoría que desea actualizar: ");
        int idAModificar = scanner.nextInt();
        scanner.nextLine(); // Limpiar buffer
        
        Categoria categoria = dao.consultarCategoria(idAModificar);
        
        if (categoria != null) {
            System.out.println("Nombre actual: " + categoria.getNombre_categorias());
            
            System.out.print("Digite el nuevo nombre de la categoría: ");
            categoria.setNombre_categorias(scanner.nextLine());
            
            boolean resultado = dao.actualizarCategoria(categoria);
            
            if (resultado) {
                System.out.println("¡Categoría actualizada correctamente!");
            } else {
                System.out.println("Error al actualizar la categoría.");
            }
        } else {
            System.out.println("La categoría con ID " + idAModificar + " no existe.");
        }
        scanner.close();
    }
}