package Controlador;

import Modelo.Usuarios;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public Usuarios consultarPorId(int idUsuario, Connection conexion) {
        Usuarios usuario = null;
        String sql = "SELECT * FROM usuarios WHERE id_Usuarios = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    usuario = mapearUsuario(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar usuario por ID: " + e.getMessage());
        }

        return usuario;
    }

    public List<Usuarios> consultar(Connection conexion) {
        List<Usuarios> listaUsuarios = new ArrayList<>();
        String sql = "SELECT * FROM usuarios";

        try (PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                listaUsuarios.add(mapearUsuario(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar usuarios: " + e.getMessage());
        }

        return listaUsuarios;
    }

    public boolean insertar(Usuarios usuario, Connection conexion) {
        String sql = "INSERT INTO usuarios (nombre_usuarios, apellido_usuarios, direccion_usuarios, telefonos, numero_documentos, " +
                     "fecha_nacimientos, fecha_vencimiento_claves, correos, passwords, autorizacion_datos, " +
                     "roles_id_roles, estados_usuarios_id_estados_usuario, tipo_de_documentos_id_tipo_de_documento) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, usuario.getNombre_usuarios());
            ps.setString(2, usuario.getApellido_usuarios());
            ps.setString(3, usuario.getDireccion_usuarios());
            ps.setString(4, usuario.getTelefonos());
            ps.setString(5, usuario.getNumero_documentos());
            ps.setDate(6, usuario.getFecha_nacimientos() != null ? new java.sql.Date(usuario.getFecha_nacimientos().getTime()) : null);
            ps.setDate(7, usuario.getFecha_vencimiento_claves() != null ? new java.sql.Date(usuario.getFecha_vencimiento_claves().getTime()) : null);
            ps.setString(8, usuario.getCorreos());
            
            // Genera el hash BCrypt de la contraseña antes de guardar en BD
            String passwordEncriptada = encriptar(usuario.getPasswords());
            ps.setString(9, passwordEncriptada);
            
            ps.setBoolean(10, usuario.isAutorizacion_datos());
            ps.setInt(11, usuario.getRoles_id_roles());
            ps.setInt(12, usuario.getEstados_usuarios_id_estados_usuario());
            ps.setInt(13, usuario.getTipo_de_documentos_id_tipo_de_documento());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar usuario: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Usuarios usuario, Connection conexion) {
        String sql = "UPDATE usuarios SET nombre_usuarios = ?, apellido_usuarios = ?, direccion_usuarios = ?, " +
                     "telefonos = ?, numero_documentos = ?, fecha_nacimientos = ?, fecha_vencimiento_claves = ?, " +
                     "correos = ?, passwords = ?, autorizacion_datos = ?, roles_id_roles = ?, " +
                     "estados_usuarios_id_estados_usuario = ?, tipo_de_documentos_id_tipo_de_documento = ? " +
                     "WHERE id_Usuarios = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, usuario.getNombre_usuarios());
            ps.setString(2, usuario.getApellido_usuarios());
            ps.setString(3, usuario.getDireccion_usuarios());
            ps.setString(4, usuario.getTelefonos());
            ps.setString(5, usuario.getNumero_documentos());
            ps.setDate(6, usuario.getFecha_nacimientos() != null ? new java.sql.Date(usuario.getFecha_nacimientos().getTime()) : null);
            ps.setDate(7, usuario.getFecha_vencimiento_claves() != null ? new java.sql.Date(usuario.getFecha_vencimiento_claves().getTime()) : null);
            ps.setString(8, usuario.getCorreos());
            
            // Verifica si la clave ya es un hash BCrypt ($2a$ / $2b$). Si no lo es, la encripta.
            String pass = usuario.getPasswords();
            String passHash = (pass != null && (pass.startsWith("$2a$") || pass.startsWith("$2b$"))) 
                              ? pass : encriptar(pass);
            ps.setString(9, passHash);

            ps.setBoolean(10, usuario.isAutorizacion_datos());
            ps.setInt(11, usuario.getRoles_id_roles());
            ps.setInt(12, usuario.getEstados_usuarios_id_estados_usuario());
            ps.setInt(13, usuario.getTipo_de_documentos_id_tipo_de_documento());
            ps.setInt(14, usuario.getId_Usuarios());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar usuario: " + e.getMessage());
            return false;
        }
    }

    /**
     * Actualiza únicamente los datos personales editables del perfil activo.
     */
    public boolean actualizarPerfil(int idUsuario, String nombre, String apellido, String telefono, String direccion, Connection conexion) {
        String sql = "UPDATE usuarios SET nombre_usuarios = ?, apellido_usuarios = ?, telefonos = ?, direccion_usuarios = ? WHERE id_Usuarios = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, nombre);
            ps.setString(2, apellido);
            ps.setString(3, telefono);
            ps.setString(4, direccion);
            ps.setInt(5, idUsuario);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar perfil de usuario: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idUsuario, Connection conexion) {
        String sql = "DELETE FROM usuarios WHERE id_Usuarios = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idUsuario);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar usuario: " + e.getMessage());
            return false;
        }
    }

    public boolean activarUsuario(int idUsuario, int idEstadoActivo, Connection conexion) {
        String sql = "UPDATE usuarios SET estados_usuarios_id_estados_usuario = ? WHERE id_Usuarios = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idEstadoActivo);
            ps.setInt(2, idUsuario);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al activar usuario: " + e.getMessage());
            return false;
        }
    }

    public boolean inactivarUsuario(int idUsuario, int idEstadoInactivo, Connection conexion) {
        String sql = "UPDATE usuarios SET estados_usuarios_id_estados_usuario = ? WHERE id_Usuarios = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idEstadoInactivo);
            ps.setInt(2, idUsuario);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al inactivar usuario: " + e.getMessage());
            return false;
        }
    }

    public Usuarios validarUsuario(String correo, String password, Connection conexion) {
        String sql = "SELECT * FROM usuarios WHERE correos = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, correo);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Usuarios usuario = mapearUsuario(rs);
                    if (verificar(password, usuario.getPasswords())) {
                        return usuario;
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al validar usuario: " + e.getMessage());
        }

        return null;
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public Usuarios consultarPorId(int idUsuario) {
        try (Connection con = Conexion.getConnection()) {
            return consultarPorId(idUsuario, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar usuario por ID: " + e.getMessage());
            return null;
        }
    }

    public List<Usuarios> consultar() {
        try (Connection con = Conexion.getConnection()) {
            return consultar(con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar usuarios: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertar(Usuarios usuario) {
        try (Connection con = Conexion.getConnection()) {
            return insertar(usuario, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar usuario: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Usuarios usuario) {
        try (Connection con = Conexion.getConnection()) {
            return actualizar(usuario, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar usuario: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarPerfil(int idUsuario, String nombre, String apellido, String telefono, String direccion) {
        try (Connection con = Conexion.getConnection()) {
            return actualizarPerfil(idUsuario, nombre, apellido, telefono, direccion, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar perfil: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idUsuario) {
        try (Connection con = Conexion.getConnection()) {
            return eliminar(idUsuario, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar usuario: " + e.getMessage());
            return false;
        }
    }

    public boolean activarUsuario(int idUsuario, int idEstadoActivo) {
        try (Connection con = Conexion.getConnection()) {
            return activarUsuario(idUsuario, idEstadoActivo, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al activar usuario: " + e.getMessage());
            return false;
        }
    }

    public boolean inactivarUsuario(int idUsuario, int idEstadoInactivo) {
        try (Connection con = Conexion.getConnection()) {
            return inactivarUsuario(idUsuario, idEstadoInactivo, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al inactivar usuario: " + e.getMessage());
            return false;
        }
    }

    public Usuarios validarUsuario(String correo, String password) {
        try (Connection con = Conexion.getConnection()) {
            return validarUsuario(correo, password, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al validar usuario: " + e.getMessage());
            return null;
        }
    }

    // ==========================================
    // MÉTODOS AUXILIARES Y ENCRIPTACIÓN
    // ==========================================

    private Usuarios mapearUsuario(ResultSet rs) throws SQLException {
        Usuarios usuario = new Usuarios();
        usuario.setId_Usuarios(rs.getInt("id_Usuarios"));
        usuario.setNombre_usuarios(rs.getString("nombre_usuarios"));
        usuario.setApellido_usuarios(rs.getString("apellido_usuarios"));
        usuario.setDireccion_usuarios(rs.getString("direccion_usuarios"));
        usuario.setTelefonos(rs.getString("telefonos"));
        usuario.setNumero_documentos(rs.getString("numero_documentos"));
        usuario.setFecha_nacimientos(rs.getDate("fecha_nacimientos"));
        usuario.setFecha_vencimiento_claves(rs.getDate("fecha_vencimiento_claves"));
        usuario.setCorreos(rs.getString("correos"));
        usuario.setPasswords(rs.getString("passwords"));
        usuario.setAutorizacion_datos(rs.getBoolean("autorizacion_datos"));
        usuario.setRoles_id_roles(rs.getInt("roles_id_roles"));
        usuario.setEstados_usuarios_id_estados_usuario(rs.getInt("estados_usuarios_id_estados_usuario"));
        usuario.setTipo_de_documentos_id_tipo_de_documento(rs.getInt("tipo_de_documentos_id_tipo_de_documento"));
        return usuario;
    }

    private String encriptar(String passwordPlana) {
        if (passwordPlana == null || passwordPlana.isBlank()) {
            return null;
        }
        return BCrypt.hashpw(passwordPlana, BCrypt.gensalt(12));
    }

    private boolean verificar(String passwordPlana, String hashAlmacenado) {
        if (passwordPlana == null || hashAlmacenado == null || hashAlmacenado.isBlank()) {
            return false;
        }
        try {
            return BCrypt.checkpw(passwordPlana, hashAlmacenado);
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}