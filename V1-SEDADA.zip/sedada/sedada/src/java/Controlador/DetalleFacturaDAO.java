package Controlador;

import Modelo.DetalleFactura;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DetalleFacturaDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public boolean insertar(DetalleFactura detalleFactura, Connection conexion) {
        String sql = "INSERT INTO detalle_factura (cantidades, precios_unitarios_facturados, valores_iva_lineas, " +
                     "facturas_id_facturas, detalle_pedidos_id_detalle_pedidos) VALUES (?, ?, ?, ?, ?)";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, detalleFactura.getCantidades());
            ps.setBigDecimal(2, detalleFactura.getPrecios_unitarios_facturados());
            ps.setBigDecimal(3, detalleFactura.getValores_iva_lineas());
            ps.setInt(4, detalleFactura.getFacturas_id_facturas());
            ps.setInt(5, detalleFactura.getDetalle_pedidos_id_detalle_pedidos());
            
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar detalle de factura: " + e.getMessage());
            return false;
        }
    }

    public List<DetalleFactura> consultar(Connection conexion) {
        List<DetalleFactura> lista = new ArrayList<>();
        String sql = "SELECT id_detalle_factura, cantidades, precios_unitarios_facturados, valores_iva_lineas, " +
                     "facturas_id_facturas, detalle_pedidos_id_detalle_pedidos FROM detalle_factura";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                DetalleFactura detalle = new DetalleFactura();
                detalle.setId_detalle_factura(rs.getInt("id_detalle_factura"));
                detalle.setCantidades(rs.getInt("cantidades"));
                detalle.setPrecios_unitarios_facturados(rs.getBigDecimal("precios_unitarios_facturados"));
                detalle.setValores_iva_lineas(rs.getBigDecimal("valores_iva_lineas"));
                detalle.setFacturas_id_facturas(rs.getInt("facturas_id_facturas"));
                detalle.setDetalle_pedidos_id_detalle_pedidos(rs.getInt("detalle_pedidos_id_detalle_pedidos"));
                
                lista.add(detalle);
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar detalles de factura: " + e.getMessage());
        }
        
        return lista;
    }

    public boolean actualizar(DetalleFactura detalleFactura, Connection conexion) {
        String sql = "UPDATE detalle_factura SET cantidades = ?, precios_unitarios_facturados = ?, " +
                     "valores_iva_lineas = ?, facturas_id_facturas = ?, detalle_pedidos_id_detalle_pedidos = ? " +
                     "WHERE id_detalle_factura = ?";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, detalleFactura.getCantidades());
            ps.setBigDecimal(2, detalleFactura.getPrecios_unitarios_facturados());
            ps.setBigDecimal(3, detalleFactura.getValores_iva_lineas());
            ps.setInt(4, detalleFactura.getFacturas_id_facturas());
            ps.setInt(5, detalleFactura.getDetalle_pedidos_id_detalle_pedidos());
            ps.setInt(6, detalleFactura.getId_detalle_factura());
            
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar detalle de factura: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idDetalleFactura, Connection conexion) {
        String sql = "DELETE FROM detalle_factura WHERE id_detalle_factura = ?";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idDetalleFactura);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar detalle de factura: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public boolean insertar(DetalleFactura nuevoDetalle) {
        try (Connection con = Conexion.getConnection()) {
            return insertar(nuevoDetalle, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar detalle de factura: " + e.getMessage());
            return false;
        }
    }

    public List<DetalleFactura> consultar() {
        try (Connection con = Conexion.getConnection()) {
            return consultar(con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar detalles de factura: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean actualizar(DetalleFactura detalleActualizar) {
        try (Connection con = Conexion.getConnection()) {
            return actualizar(detalleActualizar, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar detalle de factura: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idAEliminar) {
        try (Connection con = Conexion.getConnection()) {
            return eliminar(idAEliminar, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar detalle de factura: " + e.getMessage());
            return false;
        }
    }

    public boolean activarDetalleFactura(int idDetalleFactura, int idEstadoActivo, Connection conexion) {
        String sql = "UPDATE detalle_factura SET estados_id_estado = ? WHERE id_detalle_factura = ?";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idEstadoActivo);
            ps.setInt(2, idDetalleFactura);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al activar detalle de factura: " + e.getMessage());
            return false;
        }
    }

    public boolean activarDetalleFactura(int idDetalleFactura, int idEstadoActivo) {
        try (Connection con = Conexion.getConnection()) {
            return activarDetalleFactura(idDetalleFactura, idEstadoActivo, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al activar detalle de factura: " + e.getMessage());
            return false;
        }
    }
}
