package Controlador;

import Modelo.Turnos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

public class TurnosDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public Turnos consultarTurno(int id, Connection conn) {
        Turnos miTurno = null;
        String querySql = "SELECT id_Turnos, nombre_turno, hora_entrada, hora_salida, Usuarios_id_Usuarios "
                        + "FROM Turnos WHERE id_Turnos = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miTurno = mapearTurno(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar el turno: " + e.getMessage());
        }

        return miTurno;
    }

    public List<Turnos> consultarTodos(Connection conn) {
        List<Turnos> lista = new ArrayList<>();
        String querySql = "SELECT id_Turnos, nombre_turno, hora_entrada, hora_salida, Usuarios_id_Usuarios FROM Turnos";

        try (PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearTurno(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar todos los turnos: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertarTurno(Turnos miTurno, Connection conn) {
        String querySql = "INSERT INTO Turnos (id_Turnos, nombre_turno, hora_entrada, hora_salida, Usuarios_id_Usuarios) "
                        + "VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, miTurno.getId_turnos());
            ps.setString(2, miTurno.getNombre_turno());
            ps.setTime(3, miTurno.getHora_entrada() != null ? Time.valueOf(miTurno.getHora_entrada()) : null);
            ps.setTime(4, miTurno.getHora_salida() != null ? Time.valueOf(miTurno.getHora_salida()) : null);
            ps.setInt(5, miTurno.getUsuarios_id_Usuarios());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Los datos no fueron insertados adecuadamente: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarTurno(Turnos miTurno, Connection conn) {
        String querySql = "UPDATE Turnos SET nombre_turno = ?, "
                        + "hora_entrada = ?, hora_salida = ?, Usuarios_id_Usuarios = ? "
                        + "WHERE id_Turnos = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miTurno.getNombre_turno());
            ps.setTime(2, miTurno.getHora_entrada() != null ? Time.valueOf(miTurno.getHora_entrada()) : null);
            ps.setTime(3, miTurno.getHora_salida() != null ? Time.valueOf(miTurno.getHora_salida()) : null);
            ps.setInt(4, miTurno.getUsuarios_id_Usuarios());
            ps.setInt(5, miTurno.getId_turnos());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar el turno: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarTurno(int id, Connection conn) {
        String querySql = "DELETE FROM Turnos WHERE id_Turnos = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar el turno: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public Turnos consultarTurno(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return consultarTurno(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al buscar el turno: " + e.getMessage());
            return null;
        }
    }

    public List<Turnos> consultarTodos() {
        try (Connection conn = Conexion.getConnection()) {
            return consultarTodos(conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar todos los turnos: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertarTurno(Turnos miTurno) {
        try (Connection conn = Conexion.getConnection()) {
            return insertarTurno(miTurno, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar el turno: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarTurno(Turnos miTurno) {
        try (Connection conn = Conexion.getConnection()) {
            return actualizarTurno(miTurno, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar el turno: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarTurno(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return eliminarTurno(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar el turno: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS AUXILIARES
    // ==========================================

    private Turnos mapearTurno(ResultSet rs) throws SQLException {
        Turnos miTurno = new Turnos();
        miTurno.setId_turnos(rs.getInt("id_Turnos"));
        miTurno.setNombre_turno(rs.getString("nombre_turno"));

        if (rs.getTime("hora_entrada") != null) {
            miTurno.setHora_entrada(rs.getTime("hora_entrada").toLocalTime());
        }
        if (rs.getTime("hora_salida") != null) {
            miTurno.setHora_salida(rs.getTime("hora_salida").toLocalTime());
        }

        miTurno.setUsuarios_id_Usuarios(rs.getInt("Usuarios_id_Usuarios"));
        return miTurno;
    }
}