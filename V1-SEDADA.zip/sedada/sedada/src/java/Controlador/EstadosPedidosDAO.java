package Controlador;

import Modelo.EstadoPedido;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstadosPedidosDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public EstadoPedido consultarEstadoPedido(int id, Connection conn) {
        EstadoPedido miEstado = null;
        String querySql = "SELECT id_estados_pedidos, nombres_estado_pedidos FROM estados_pedidos WHERE id_estados_pedidos = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miEstado = new EstadoPedido();
                    miEstado.setId_estados_pedidos(rs.getInt("id_estados_pedidos"));
                    miEstado.setNombres_estado_pedidos(rs.getString("nombres_estado_pedidos"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar el estado de pedido: " + e.getMessage());
        }

        return miEstado;
    }

    public List<EstadoPedido> consultarTodos(Connection conn) {
        List<EstadoPedido> lista = new ArrayList<>();
        String querySql = "SELECT id_estados_pedidos, nombres_estado_pedidos FROM estados_pedidos";

        try (PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                EstadoPedido estado = new EstadoPedido();
                estado.setId_estados_pedidos(rs.getInt("id_estados_pedidos"));
                estado.setNombres_estado_pedidos(rs.getString("nombres_estado_pedidos"));
                lista.add(estado);
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar todos los estados de pedido: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertarEstadoPedido(EstadoPedido miEstado, Connection conn) {
        String querySql = "INSERT INTO estados_pedidos (nombres_estado_pedidos) VALUES (?)";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miEstado.getNombres_estado_pedidos());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar el estado de pedido: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarEstadoPedido(EstadoPedido miEstado, Connection conn) {
        String querySql = "UPDATE estados_pedidos SET nombres_estado_pedidos = ? WHERE id_estados_pedidos = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miEstado.getNombres_estado_pedidos());
            ps.setInt(2, miEstado.getId_estados_pedidos());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar el estado de pedido: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarEstadoPedido(int id, Connection conn) {
        String querySql = "DELETE FROM estados_pedidos WHERE id_estados_pedidos = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar el estado de pedido: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public EstadoPedido consultarEstadoPedido(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return consultarEstadoPedido(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar el estado de pedido: " + e.getMessage());
            return null;
        }
    }

    public List<EstadoPedido> consultarTodos() {
        try (Connection conn = Conexion.getConnection()) {
            return consultarTodos(conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar todos los estados de pedido: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertarEstadoPedido(EstadoPedido miEstado) {
        try (Connection conn = Conexion.getConnection()) {
            return insertarEstadoPedido(miEstado, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar el estado de pedido: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarEstadoPedido(EstadoPedido miEstado) {
        try (Connection conn = Conexion.getConnection()) {
            return actualizarEstadoPedido(miEstado, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar el estado de pedido: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarEstadoPedido(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return eliminarEstadoPedido(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar el estado de pedido: " + e.getMessage());
            return false;
        }
    }
}