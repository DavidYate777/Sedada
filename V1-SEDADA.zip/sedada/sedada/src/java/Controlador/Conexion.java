package Controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {

    // ==========================================
    // CONFIGURACIÓN DE SUPABASE - SESSION POOLER
    // ==========================================

    private static final String URL =
            "jdbc:postgresql://aws-0-us-west-2.pooler.supabase.com:5432/postgres";

    private static final String USUARIO =
            "postgres.ymzkhuyohpyroiavnjmd";

    // ==========================================
    // CONTRASEÑA TEMPORAL
    // ==========================================
    // IMPORTANTE:
    // Esta contraseña está puesta temporalmente
    // únicamente para comprobar la conexión.
    //
    // Después de comprobar que funciona,
    // CAMBIAR LA CONTRASEÑA EN SUPABASE y
    // volveremos a utilizar una variable segura.
    // ==========================================

    private static final String PASSWORD =
            "3145669012aA*";

    // Constructor
    public Conexion() {
    }

    /**
     * Obtiene una conexión activa con Supabase.
     */
    public static Connection getConnection() throws SQLException {

        // Verificar contraseña
        if (PASSWORD == null || PASSWORD.isBlank()) {

            throw new SQLException(
                    "La contraseña de Supabase está vacía."
            );
        }

        // Cargar driver PostgreSQL
        try {

            Class.forName("org.postgresql.Driver");

        } catch (ClassNotFoundException e) {

            throw new SQLException(
                    "No se encontró el driver JDBC de PostgreSQL.",
                    e
            );
        }

        // Mostrar información de diagnóstico
        // NO muestra la contraseña.
        System.out.println(
                "USUARIO DE CONEXION: " + USUARIO
        );

        System.out.println(
                "SERVIDOR DE CONEXION: " + URL
        );

        System.out.println(
                "CONTRASEÑA CONFIGURADA: "
                + (!PASSWORD.isBlank())
        );

        // Intentar conexión
        return DriverManager.getConnection(
                URL,
                USUARIO,
                PASSWORD
        );
    }

    /**
     * Prueba la conexión con Supabase.
     */
    public static boolean probarConexion() {

        System.out.println(
                "Iniciando prueba de conexión..."
        );

        try (Connection conexion = getConnection()) {

            if (conexion != null && !conexion.isClosed()) {

                System.out.println(
                        "=========================================="
                );

                System.out.println(
                        "CONEXION EXITOSA CON SUPABASE"
                );

                System.out.println(
                        "=========================================="
                );

                System.out.println(
                        "Base de datos: "
                        + conexion.getCatalog()
                );

                System.out.println(
                        "Servidor: "
                        + conexion.getMetaData()
                                .getDatabaseProductName()
                );

                System.out.println(
                        "Version: "
                        + conexion.getMetaData()
                                .getDatabaseProductVersion()
                );

                System.out.println(
                        "=========================================="
                );

                return true;
            }

        } catch (SQLException e) {

            System.err.println(
                    "=========================================="
            );

            System.err.println(
                    "ERROR DE CONEXION CON SUPABASE"
            );

            System.err.println(
                    "=========================================="
            );

            System.err.println(
                    "Mensaje: " + e.getMessage()
            );

            e.printStackTrace();
        }

        return false;
    }
}