package Controlador;

import Modelo.Roles;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RolesDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public Roles consultarRol(int id, Connection conn) {
        Roles miRol = null;
        String querySql = "SELECT id_roles, nombre_rol FROM roles WHERE id_roles = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miRol = mapearRol(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar el rol: " + e.getMessage());
        }

        return miRol;
    }

    public List<Roles> consultarTodos(Connection conn) {
        List<Roles> lista = new ArrayList<>();
        String querySql = "SELECT id_roles, nombre_rol FROM roles";

        try (PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearRol(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar todos los roles: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertarRol(Roles miRol, Connection conn) {
        String querySql = "INSERT INTO roles (id_roles, nombre_rol) VALUES (?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, miRol.getId_roles());
            ps.setString(2, miRol.getNombre_rol());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar el rol: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarRol(Roles miRol, Connection conn) {
        String querySql = "UPDATE roles SET nombre_rol = ? WHERE id_roles = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miRol.getNombre_rol());
            ps.setInt(2, miRol.getId_roles());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar el rol: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarRol(int id, Connection conn) {
        String querySql = "DELETE FROM roles WHERE id_roles = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar el rol: " + e.getMessage());
            return false;
        }
    }

    public boolean inactivarRol(int id, Connection conn) {
        String querySql = "UPDATE roles SET estado = 'Inactivo' WHERE id_roles = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al inactivar el rol: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public Roles consultarRol(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return consultarRol(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar el rol: " + e.getMessage());
            return null;
        }
    }

    public List<Roles> consultarTodos() {
        try (Connection conn = Conexion.getConnection()) {
            return consultarTodos(conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar todos los roles: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertarRol(Roles miRol) {
        try (Connection conn = Conexion.getConnection()) {
            return insertarRol(miRol, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar el rol: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarRol(Roles miRol) {
        try (Connection conn = Conexion.getConnection()) {
            return actualizarRol(miRol, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar el rol: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarRol(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return eliminarRol(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar el rol: " + e.getMessage());
            return false;
        }
    }

    public boolean inactivarRol(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return inactivarRol(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al inactivar el rol: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS AUXILIARES
    // ==========================================

    private Roles mapearRol(ResultSet rs) throws SQLException {
        Roles rol = new Roles();
        rol.setId_roles(rs.getInt("id_roles"));
        rol.setNombre_rol(rs.getString("nombre_rol"));
        return rol;
    }
}