package Controlador;

import Modelo.TipoDeDocumentos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TipoDeDocumentosDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public TipoDeDocumentos consultarPorId(int idTipoDocumento, Connection conexion) {
        TipoDeDocumentos tipo = null;
        String sql = "SELECT id_tipo_de_documento, nombre_documento FROM tipo_de_documentos WHERE id_tipo_de_documento = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idTipoDocumento);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    tipo = mapearTipoDocumento(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar tipo de documento por ID: " + e.getMessage());
        }

        return tipo;
    }

    public List<TipoDeDocumentos> consultar(Connection conexion) {
        List<TipoDeDocumentos> lista = new ArrayList<>();
        String sql = "SELECT id_tipo_de_documento, nombre_documento FROM tipo_de_documentos";

        try (PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearTipoDocumento(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar tipos de documentos: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertar(TipoDeDocumentos tipoDocumento, Connection conexion) {
        String sql = "INSERT INTO tipo_de_documentos (nombre_documento) VALUES (?)";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, tipoDocumento.getNombre_documento());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar tipo de documento: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(TipoDeDocumentos tipoDocumento, Connection conexion) {
        String sql = "UPDATE tipo_de_documentos SET nombre_documento = ? WHERE id_tipo_de_documento = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, tipoDocumento.getNombre_documento());
            ps.setInt(2, tipoDocumento.getId_tipo_de_documento());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar tipo de documento: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idTipoDocumento, Connection conexion) {
        String sql = "DELETE FROM tipo_de_documentos WHERE id_tipo_de_documento = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idTipoDocumento);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar tipo de documento: " + e.getMessage());
            return false;
        }
    }

    public boolean activarTipoDocumento(int idTipoDocumento, int idEstadoActivo, Connection conexion) {
        String sql = "UPDATE tipo_de_documentos SET estados_id_estado = ? WHERE id_tipo_de_documento = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idEstadoActivo);
            ps.setInt(2, idTipoDocumento);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al activar tipo de documento: " + e.getMessage());
            return false;
        }
    }

    public boolean inactivarTipoDocumento(int idTipoDocumento, int idEstadoInactivo, Connection conexion) {
        String sql = "UPDATE tipo_de_documentos SET estados_id_estado = ? WHERE id_tipo_de_documento = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idEstadoInactivo);
            ps.setInt(2, idTipoDocumento);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al inactivar tipo de documento: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public TipoDeDocumentos consultarPorId(int idTipoDocumento) {
        try (Connection con = Conexion.getConnection()) {
            return consultarPorId(idTipoDocumento, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar tipo de documento por ID: " + e.getMessage());
            return null;
        }
    }

    public List<TipoDeDocumentos> consultar() {
        try (Connection con = Conexion.getConnection()) {
            return consultar(con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar tipos de documentos: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertar(TipoDeDocumentos tipoDocumento) {
        try (Connection con = Conexion.getConnection()) {
            return insertar(tipoDocumento, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar tipo de documento: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(TipoDeDocumentos tipoActualizar) {
        try (Connection con = Conexion.getConnection()) {
            return actualizar(tipoActualizar, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar tipo de documento: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idAEliminar) {
        try (Connection con = Conexion.getConnection()) {
            return eliminar(idAEliminar, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar tipo de documento: " + e.getMessage());
            return false;
        }
    }

    public boolean activarTipoDocumento(int idTipoDocumento, int idEstadoActivo) {
        try (Connection con = Conexion.getConnection()) {
            return activarTipoDocumento(idTipoDocumento, idEstadoActivo, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al activar tipo de documento: " + e.getMessage());
            return false;
        }
    }

    public boolean inactivarTipoDocumento(int idTipoDocumento, int idEstadoInactivo) {
        try (Connection con = Conexion.getConnection()) {
            return inactivarTipoDocumento(idTipoDocumento, idEstadoInactivo, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al inactivar tipo de documento: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS AUXILIARES
    // ==========================================

    private TipoDeDocumentos mapearTipoDocumento(ResultSet rs) throws SQLException {
        TipoDeDocumentos tipo = new TipoDeDocumentos();
        tipo.setId_tipo_de_documento(rs.getInt("id_tipo_de_documento"));
        tipo.setNombre_documento(rs.getString("nombre_documento"));
        return tipo;
    }
}