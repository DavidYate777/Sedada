package Controlador;

import Modelo.Categoria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public Categoria consultarCategoria(int id, Connection conn) {
        Categoria miCategoria = null;
        String querySql = "SELECT id_categorias, nombre_categorias FROM categorias WHERE id_categorias = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miCategoria = new Categoria();
                    miCategoria.setId_categorias(rs.getInt("id_categorias"));
                    miCategoria.setNombre_categorias(rs.getString("nombre_categorias"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar la categoría: " + e.getMessage());
        }

        return miCategoria;
    }

    public List<Categoria> consultarTodas(Connection conn) {
        List<Categoria> lista = new ArrayList<>();
        String querySql = "SELECT id_categorias, nombre_categorias FROM categorias";

        try (PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Categoria cat = new Categoria();
                cat.setId_categorias(rs.getInt("id_categorias"));
                cat.setNombre_categorias(rs.getString("nombre_categorias"));
                lista.add(cat);
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar todas las categorías: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertarCategoria(Categoria miCategoria, Connection conn) {
        // Se omite id_categorias para que PostgreSQL/Supabase use el autoincremental
        String querySql = "INSERT INTO categorias (nombre_categorias) VALUES (?)";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miCategoria.getNombre_categorias());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar la categoría: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarCategoria(Categoria miCategoria, Connection conn) {
        String querySql = "UPDATE categorias SET nombre_categorias = ? WHERE id_categorias = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miCategoria.getNombre_categorias());
            ps.setInt(2, miCategoria.getId_categorias());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar la categoría: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarCategoria(int id, Connection conn) {
        String querySql = "DELETE FROM categorias WHERE id_categorias = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar la categoría: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public Categoria consultarCategoria(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return consultarCategoria(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar categoría: " + e.getMessage());
            return null;
        }
    }

    public List<Categoria> consultarTodas() {
        try (Connection conn = Conexion.getConnection()) {
            return consultarTodas(conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar categorías: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertarCategoria(Categoria miCategoria) {
        try (Connection conn = Conexion.getConnection()) {
            return insertarCategoria(miCategoria, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar categoría: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarCategoria(Categoria miCategoria) {
        try (Connection conn = Conexion.getConnection()) {
            return actualizarCategoria(miCategoria, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar categoría: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarCategoria(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return eliminarCategoria(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar categoría: " + e.getMessage());
            return false;
        }
    }
}