package Controlador;

import Modelo.MetodosPago;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MetodosPagoDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public MetodosPago consultarMetodoPago(int id, Connection conn) {
        MetodosPago miMetodo = null;
        String querySql = "SELECT id_metodos_pago, nombre_metodo_pago FROM metodos_pago WHERE id_metodos_pago = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miMetodo = mapearMetodoPago(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar el método de pago: " + e.getMessage());
        }

        return miMetodo;
    }

    public List<MetodosPago> consultarTodos(Connection conn) {
        List<MetodosPago> lista = new ArrayList<>();
        String querySql = "SELECT id_metodos_pago, nombre_metodo_pago FROM metodos_pago";

        try (PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearMetodoPago(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar todos los métodos de pago: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertarMetodoPago(MetodosPago miMetodo, Connection conn) {
        String querySql = "INSERT INTO metodos_pago (nombre_metodo_pago) VALUES (?)";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miMetodo.getNombre_metodo_pago());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar el método de pago: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarMetodoPago(MetodosPago miMetodo, Connection conn) {
        String querySql = "UPDATE metodos_pago SET nombre_metodo_pago = ? WHERE id_metodos_pago = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miMetodo.getNombre_metodo_pago());
            ps.setInt(2, miMetodo.getId_metodos_pago());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar el método de pago: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarMetodoPago(int id, Connection conn) {
        String querySql = "DELETE FROM metodos_pago WHERE id_metodos_pago = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar el método de pago: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public MetodosPago consultarMetodoPago(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return consultarMetodoPago(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar el método de pago: " + e.getMessage());
            return null;
        }
    }

    public List<MetodosPago> consultarTodos() {
        try (Connection conn = Conexion.getConnection()) {
            return consultarTodos(conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar todos los métodos de pago: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertarMetodoPago(MetodosPago miMetodo) {
        try (Connection conn = Conexion.getConnection()) {
            return insertarMetodoPago(miMetodo, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar el método de pago: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarMetodoPago(MetodosPago miMetodo) {
        try (Connection conn = Conexion.getConnection()) {
            return actualizarMetodoPago(miMetodo, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar el método de pago: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarMetodoPago(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return eliminarMetodoPago(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar el método de pago: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS AUXILIARES
    // ==========================================

    private MetodosPago mapearMetodoPago(ResultSet rs) throws SQLException {
        MetodosPago metodo = new MetodosPago();
        metodo.setId_metodos_pago(rs.getInt("id_metodos_pago"));
        metodo.setNombre_metodo_pago(rs.getString("nombre_metodo_pago"));
        return metodo;
    }
}