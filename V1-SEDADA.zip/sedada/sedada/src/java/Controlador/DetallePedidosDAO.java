package Controlador;

import Modelo.DetallePedidos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DetallePedidosDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public boolean insertar(DetallePedidos detallePedido, Connection conexion) {
        String sql = "INSERT INTO detalle_pedidos (cantidades, precios_unitarios, notas_especiales, " +
                     "productos_id_productos, pedidos_id_pedidos) VALUES (?, ?, ?, ?, ?)";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, detallePedido.getCantidades());
            ps.setBigDecimal(2, detallePedido.getPrecio_unitario());
            ps.setString(3, detallePedido.getNotas_especiales());
            ps.setInt(4, detallePedido.getProductos_id_productos());
            ps.setInt(5, detallePedido.getPedidos_id_pedidos());
            
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar detalle de pedido: " + e.getMessage());
            return false;
        }
    }

    public List<DetallePedidos> consultar(Connection conexion) {
        List<DetallePedidos> lista = new ArrayList<>();
        String sql = "SELECT id_detalle_pedidos, cantidades, precios_unitarios, notas_especiales, " +
                     "productos_id_productos, pedidos_id_pedidos FROM detalle_pedidos";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                DetallePedidos detalle = new DetallePedidos();
                detalle.setId_detalle_pedido(rs.getInt("id_detalle_pedidos"));
                detalle.setCantidades(rs.getInt("cantidades"));
                detalle.setPrecio_unitario(rs.getBigDecimal("precios_unitarios"));
                detalle.setNotas_especiales(rs.getString("notas_especiales"));
                detalle.setProductos_id_productos(rs.getInt("productos_id_productos"));
                detalle.setPedidos_id_pedidos(rs.getInt("pedidos_id_pedidos"));
                
                lista.add(detalle);
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar detalles de pedidos: " + e.getMessage());
        }
        
        return lista;
    }

    public boolean actualizar(DetallePedidos detallePedido, Connection conexion) {
        String sql = "UPDATE detalle_pedidos SET cantidades = ?, precios_unitarios = ?, " +
                     "notas_especiales = ?, productos_id_productos = ?, pedidos_id_pedidos = ? " +
                     "WHERE id_detalle_pedidos = ?";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, detallePedido.getCantidades());
            ps.setBigDecimal(2, detallePedido.getPrecio_unitario());
            ps.setString(3, detallePedido.getNotas_especiales());
            ps.setInt(4, detallePedido.getProductos_id_productos());
            ps.setInt(5, detallePedido.getPedidos_id_pedidos());
            ps.setInt(6, detallePedido.getId_detalle_pedido());
            
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar detalle de pedido: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idDetallePedido, Connection conexion) {
        String sql = "DELETE FROM detalle_pedidos WHERE id_detalle_pedidos = ?";
        
        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idDetallePedido);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar detalle de pedido: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public boolean insertar(DetallePedidos nuevoDetalle) {
        try (Connection con = Conexion.getConnection()) {
            return insertar(nuevoDetalle, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar detalle de pedido: " + e.getMessage());
            return false;
        }
    }

    public List<DetallePedidos> consultar() {
        try (Connection con = Conexion.getConnection()) {
            return consultar(con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar detalles de pedidos: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean actualizar(DetallePedidos detalleActualizar) {
        try (Connection con = Conexion.getConnection()) {
            return actualizar(detalleActualizar, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar detalle de pedido: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idAEliminar) {
        try (Connection con = Conexion.getConnection()) {
            return eliminar(idAEliminar, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar detalle de pedido: " + e.getMessage());
            return false;
        }
    }
}