package Controlador;

import Modelo.EstadosMesa;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstadosMesaDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public EstadosMesa consultarEstadoMesa(int id, Connection conn) {
        EstadosMesa miEstado = null;
        String querySql = "SELECT id_estados_mesa, nombre_estado FROM estados_mesa WHERE id_estados_mesa = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miEstado = new EstadosMesa();
                    miEstado.setId_estados_mesa(rs.getInt("id_estados_mesa"));
                    miEstado.setNombre_estado(rs.getString("nombre_estado"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar el estado de mesa: " + e.getMessage());
        }

        return miEstado;
    }

    public List<EstadosMesa> consultarTodos(Connection conn) {
        List<EstadosMesa> lista = new ArrayList<>();
        String querySql = "SELECT id_estados_mesa, nombre_estado FROM estados_mesa";

        try (PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                EstadosMesa estado = new EstadosMesa();
                estado.setId_estados_mesa(rs.getInt("id_estados_mesa"));
                estado.setNombre_estado(rs.getString("nombre_estado"));
                lista.add(estado);
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar todos los estados de mesa: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertarEstadoMesa(EstadosMesa miEstado, Connection conn) {
        String querySql = "INSERT INTO estados_mesa (nombre_estado) VALUES (?)";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miEstado.getNombre_estado());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar el estado de mesa: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarEstadoMesa(EstadosMesa miEstado, Connection conn) {
        String querySql = "UPDATE estados_mesa SET nombre_estado = ? WHERE id_estados_mesa = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miEstado.getNombre_estado());
            ps.setInt(2, miEstado.getId_estados_mesa());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar el estado de mesa: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarEstadoMesa(int id, Connection conn) {
        String querySql = "DELETE FROM estados_mesa WHERE id_estados_mesa = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar el estado de mesa: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public EstadosMesa consultarEstadoMesa(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return consultarEstadoMesa(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar el estado de mesa: " + e.getMessage());
            return null;
        }
    }

    public List<EstadosMesa> consultarTodos() {
        try (Connection conn = Conexion.getConnection()) {
            return consultarTodos(conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar todos los estados de mesa: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertarEstadoMesa(EstadosMesa miEstado) {
        try (Connection conn = Conexion.getConnection()) {
            return insertarEstadoMesa(miEstado, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar el estado de mesa: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarEstadoMesa(EstadosMesa miEstado) {
        try (Connection conn = Conexion.getConnection()) {
            return actualizarEstadoMesa(miEstado, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar el estado de mesa: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarEstadoMesa(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return eliminarEstadoMesa(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar el estado de mesa: " + e.getMessage());
            return false;
        }
    }
}