package Controlador;

import Modelo.EstadosProductos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstadosProductosDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public EstadosProductos consultarPorId(int id, Connection conexion) {
        EstadosProductos estado = null;
        String sql = "SELECT id_estados_productos, nombre_estado_productos FROM estados_productos WHERE id_estados_productos = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    estado = new EstadosProductos();
                    estado.setId_estados_productos(rs.getInt("id_estados_productos"));
                    estado.setNombre_estado_productos(rs.getString("nombre_estado_productos"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar estado de producto por ID: " + e.getMessage());
        }

        return estado;
    }

    public List<EstadosProductos> consultar(Connection conexion) {
        List<EstadosProductos> lista = new ArrayList<>();
        String sql = "SELECT id_estados_productos, nombre_estado_productos FROM estados_productos";

        try (PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                EstadosProductos estado = new EstadosProductos();
                estado.setId_estados_productos(rs.getInt("id_estados_productos"));
                estado.setNombre_estado_productos(rs.getString("nombre_estado_productos"));
                lista.add(estado);
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar estados de productos: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertar(EstadosProductos estado, Connection conexion) {
        String sql = "INSERT INTO estados_productos (nombre_estado_productos) VALUES (?)";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, estado.getNombre_estado_productos());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar estado de producto: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(EstadosProductos estado, Connection conexion) {
        String sql = "UPDATE estados_productos SET nombre_estado_productos = ? WHERE id_estados_productos = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, estado.getNombre_estado_productos());
            ps.setInt(2, estado.getId_estados_productos());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar estado de producto: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idEstado, Connection conexion) {
        String sql = "DELETE FROM estados_productos WHERE id_estados_productos = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idEstado);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar estado de producto: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public EstadosProductos consultarPorId(int id) {
        try (Connection con = Conexion.getConnection()) {
            return consultarPorId(id, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar estado por ID: " + e.getMessage());
            return null;
        }
    }

    public List<EstadosProductos> consultar() {
        try (Connection con = Conexion.getConnection()) {
            return consultar(con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar estados: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertar(EstadosProductos estado) {
        try (Connection con = Conexion.getConnection()) {
            return insertar(estado, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar estado: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(EstadosProductos estado) {
        try (Connection con = Conexion.getConnection()) {
            return actualizar(estado, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar estado: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idEstado) {
        try (Connection con = Conexion.getConnection()) {
            return eliminar(idEstado, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar estado: " + e.getMessage());
            return false;
        }
    }
}