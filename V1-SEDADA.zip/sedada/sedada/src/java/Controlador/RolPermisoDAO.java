package Controlador;

import Modelo.RolPermisos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RolPermisoDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public RolPermisos consultarRolPermiso(int idRol, int idPermiso, Connection conn) {
        RolPermisos miRolPermiso = null;
        String querySql = "SELECT roles_id_roles, permisos_id_permisos "
                        + "FROM rol_permisos WHERE roles_id_roles = ? AND permisos_id_permisos = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, idRol);
            ps.setInt(2, idPermiso);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miRolPermiso = mapearRolPermiso(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar el rol-permiso: " + e.getMessage());
        }

        return miRolPermiso;
    }

    public List<RolPermisos> consultarTodos(Connection conn) {
        List<RolPermisos> lista = new ArrayList<>();
        String querySql = "SELECT roles_id_roles, permisos_id_permisos FROM rol_permisos";

        try (PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearRolPermiso(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar todos los rol-permisos: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertarRolPermiso(RolPermisos miRolPermiso, Connection conn) {
        String querySql = "INSERT INTO rol_permisos (roles_id_roles, permisos_id_permisos) VALUES (?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, miRolPermiso.getRoles_id_roles());
            ps.setInt(2, miRolPermiso.getPermisos_id_permisos());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar el rol-permiso: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarRolPermiso(RolPermisos miRolPermiso, int permisoAntiguo, Connection conn) {
        String querySql = "UPDATE rol_permisos SET permisos_id_permisos = ? "
                        + "WHERE roles_id_roles = ? AND permisos_id_permisos = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, miRolPermiso.getPermisos_id_permisos());
            ps.setInt(2, miRolPermiso.getRoles_id_roles());
            ps.setInt(3, permisoAntiguo);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar el rol-permiso: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarRolPermiso(int idRol, int idPermiso, Connection conn) {
        String querySql = "DELETE FROM rol_permisos WHERE roles_id_roles = ? AND permisos_id_permisos = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, idRol);
            ps.setInt(2, idPermiso);

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar el rol-permiso: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public RolPermisos consultarRolPermiso(int idRol, int idPermiso) {
        try (Connection conn = Conexion.getConnection()) {
            return consultarRolPermiso(idRol, idPermiso, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar el rol-permiso: " + e.getMessage());
            return null;
        }
    }

    public List<RolPermisos> consultarTodos() {
        try (Connection conn = Conexion.getConnection()) {
            return consultarTodos(conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar todos los rol-permisos: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertarRolPermiso(RolPermisos miRolPermiso) {
        try (Connection conn = Conexion.getConnection()) {
            return insertarRolPermiso(miRolPermiso, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar el rol-permiso: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarRolPermiso(RolPermisos miRolPermiso, int permisoAntiguo) {
        try (Connection conn = Conexion.getConnection()) {
            return actualizarRolPermiso(miRolPermiso, permisoAntiguo, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar el rol-permiso: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarRolPermiso(int idRol, int idPermiso) {
        try (Connection conn = Conexion.getConnection()) {
            return eliminarRolPermiso(idRol, idPermiso, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar el rol-permiso: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS AUXILIARES
    // ==========================================

    private RolPermisos mapearRolPermiso(ResultSet rs) throws SQLException {
        RolPermisos rolPermiso = new RolPermisos();
        rolPermiso.setRoles_id_roles(rs.getInt("roles_id_roles"));
        rolPermiso.setPermisos_id_permisos(rs.getInt("permisos_id_permisos"));
        return rolPermiso;
    }
}