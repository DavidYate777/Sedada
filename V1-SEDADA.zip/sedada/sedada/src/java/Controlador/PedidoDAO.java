package Controlador;

import Modelo.Pedido;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class PedidoDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public Pedido consultarPorId(int idPedido, Connection conexion) {
        Pedido pedido = null;
        String sql = "SELECT * FROM pedidos WHERE id_pedidos = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idPedido);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    pedido = mapearPedido(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar pedido por ID: " + e.getMessage());
        }

        return pedido;
    }

    public List<Pedido> consultar(Connection conexion) {
        List<Pedido> lista = new ArrayList<>();
        String sql = "SELECT * FROM pedidos";

        try (PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearPedido(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar pedidos: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertar(Pedido pedido, Connection conexion) {
        String sql = "INSERT INTO pedidos (usuarios_id_usuarios, cocinero_id_usuarios, domiciliario_id_usuarios, mesas_id_mesas, direccion_entrega, telefono_contacto, estados_pedidos_id_estados_pedidos) " +
                     "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, pedido.getUsuarios_id_usuarios());
            
            if (pedido.getCocinero_id_usuarios() != null) {
                ps.setInt(2, pedido.getCocinero_id_usuarios());
            } else {
                ps.setNull(2, java.sql.Types.INTEGER);
            }
            
            if (pedido.getDomiciliario_id_usuarios() != null) {
                ps.setInt(3, pedido.getDomiciliario_id_usuarios());
            } else {
                ps.setNull(3, java.sql.Types.INTEGER);
            }
            
            if (pedido.getMesas_id_mesas() != null) {
                ps.setInt(4, pedido.getMesas_id_mesas());
            } else {
                ps.setNull(4, java.sql.Types.INTEGER);
            }
            
            ps.setString(5, pedido.getDireccion_entrega());
            ps.setString(6, pedido.getTelefono_contacto());
            ps.setInt(7, pedido.getEstados_pedidos_id_estados_pedidos());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar pedido: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Pedido pedido, Connection conexion) {
        String sql = "UPDATE pedidos SET usuarios_id_usuarios = ?, cocinero_id_usuarios = ?, domiciliario_id_usuarios = ?, " +
                     "mesas_id_mesas = ?, direccion_entrega = ?, telefono_contacto = ?, estados_pedidos_id_estados_pedidos = ? " +
                     "WHERE id_pedidos = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, pedido.getUsuarios_id_usuarios());
            
            if (pedido.getCocinero_id_usuarios() != null) {
                ps.setInt(2, pedido.getCocinero_id_usuarios());
            } else {
                ps.setNull(2, java.sql.Types.INTEGER);
            }
            
            if (pedido.getDomiciliario_id_usuarios() != null) {
                ps.setInt(3, pedido.getDomiciliario_id_usuarios());
            } else {
                ps.setNull(3, java.sql.Types.INTEGER);
            }
            
            if (pedido.getMesas_id_mesas() != null) {
                ps.setInt(4, pedido.getMesas_id_mesas());
            } else {
                ps.setNull(4, java.sql.Types.INTEGER);
            }
            
            ps.setString(5, pedido.getDireccion_entrega());
            ps.setString(6, pedido.getTelefono_contacto());
            ps.setInt(7, pedido.getEstados_pedidos_id_estados_pedidos());
            ps.setInt(8, pedido.getId_pedidos());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar pedido: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idPedido, Connection conexion) {
        String sql = "DELETE FROM pedidos WHERE id_pedidos = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idPedido);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar pedido: " + e.getMessage());
            return false;
        }
    }

    public boolean cambiarEstadoPedido(int idPedido, int idEstado, Connection conexion) {
        String sql = "UPDATE pedidos SET estados_pedidos_id_estados_pedidos = ? WHERE id_pedidos = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idEstado);
            ps.setInt(2, idPedido);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al cambiar estado de pedido: " + e.getMessage());
            return false;
        }
    }

    public boolean activarPedido(int idPedido, int idEstadoActivo, Connection conexion) {
        return cambiarEstadoPedido(idPedido, idEstadoActivo, conexion);
    }

    public boolean inactivarPedido(int idPedido, int idEstadoInactivo, Connection conexion) {
        return cambiarEstadoPedido(idPedido, idEstadoInactivo, conexion);
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public Pedido consultarPorId(int idPedido) {
        try (Connection con = Conexion.getConnection()) {
            return consultarPorId(idPedido, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar pedido por ID: " + e.getMessage());
            return null;
        }
    }

    public List<Pedido> consultar() {
        try (Connection con = Conexion.getConnection()) {
            return consultar(con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar pedidos: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertar(Pedido nuevoPedido) {
        try (Connection con = Conexion.getConnection()) {
            return insertar(nuevoPedido, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar pedido: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Pedido pedidoActualizar) {
        try (Connection con = Conexion.getConnection()) {
            return actualizar(pedidoActualizar, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar pedido: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idAEliminar) {
        try (Connection con = Conexion.getConnection()) {
            return eliminar(idAEliminar, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar pedido: " + e.getMessage());
            return false;
        }
    }

    public boolean activarPedido(int idPedido, int idEstadoActivo) {
        try (Connection con = Conexion.getConnection()) {
            return activarPedido(idPedido, idEstadoActivo, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al activar pedido: " + e.getMessage());
            return false;
        }
    }

    public boolean inactivarPedido(int idPedido, int idEstadoInactivo) {
        try (Connection con = Conexion.getConnection()) {
            return inactivarPedido(idPedido, idEstadoInactivo, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al inactivar pedido: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS AUXILIARES
    // ==========================================

    private Pedido mapearPedido(ResultSet rs) throws SQLException {
        Pedido pedido = new Pedido();
        pedido.setId_pedidos(rs.getInt("id_pedidos"));
        
        Timestamp timestamp = rs.getTimestamp("fecha_horas");
        if (timestamp != null) {
            pedido.setFecha_horas(timestamp.toLocalDateTime());
        }
        
        pedido.setUsuarios_id_usuarios(rs.getInt("usuarios_id_usuarios"));
        
        int cocinero = rs.getInt("cocinero_id_usuarios");
        pedido.setCocinero_id_usuarios(rs.wasNull() ? null : cocinero);
        
        int domiciliario = rs.getInt("domiciliario_id_usuarios");
        pedido.setDomiciliario_id_usuarios(rs.wasNull() ? null : domiciliario);
        
        int mesa = rs.getInt("mesas_id_mesas");
        pedido.setMesas_id_mesas(rs.wasNull() ? null : mesa);
        
        pedido.setDireccion_entrega(rs.getString("direccion_entrega"));
        pedido.setTelefono_contacto(rs.getString("telefono_contacto"));
        pedido.setEstados_pedidos_id_estados_pedidos(rs.getInt("estados_pedidos_id_estados_pedidos"));
        
        return pedido;
    }
}