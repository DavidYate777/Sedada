package Controlador;

import Modelo.EstadosUsuarios;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstadosUsuariosDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public EstadosUsuarios consultarEstadoUsuario(int id, Connection conn) {
        EstadosUsuarios miEstado = null;
        String querySql = "SELECT id_estados_usuario, nombre_estado FROM estados_usuarios WHERE id_estados_usuario = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miEstado = new EstadosUsuarios();
                    miEstado.setId_estados_usuario(rs.getInt("id_estados_usuario"));
                    miEstado.setNombre_estado(rs.getString("nombre_estado"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar el estado de usuario: " + e.getMessage());
        }

        return miEstado;
    }

    public List<EstadosUsuarios> consultarTodos(Connection conn) {
        List<EstadosUsuarios> lista = new ArrayList<>();
        String querySql = "SELECT id_estados_usuario, nombre_estado FROM estados_usuarios";

        try (PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                EstadosUsuarios estado = new EstadosUsuarios();
                estado.setId_estados_usuario(rs.getInt("id_estados_usuario"));
                estado.setNombre_estado(rs.getString("nombre_estado"));
                lista.add(estado);
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar todos los estados de usuario: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertarEstadoUsuario(EstadosUsuarios miEstado, Connection conn) {
        String querySql = "INSERT INTO estados_usuarios (nombre_estado) VALUES (?)";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miEstado.getNombre_estado());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar el estado de usuario: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarEstadoUsuario(EstadosUsuarios miEstado, Connection conn) {
        String querySql = "UPDATE estados_usuarios SET nombre_estado = ? WHERE id_estados_usuario = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miEstado.getNombre_estado());
            ps.setInt(2, miEstado.getId_estados_usuario());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar el estado de usuario: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarEstadoUsuario(int id, Connection conn) {
        String querySql = "DELETE FROM estados_usuarios WHERE id_estados_usuario = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar el estado de usuario: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public EstadosUsuarios consultarEstadoUsuario(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return consultarEstadoUsuario(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar el estado de usuario: " + e.getMessage());
            return null;
        }
    }

    public List<EstadosUsuarios> consultarTodos() {
        try (Connection conn = Conexion.getConnection()) {
            return consultarTodos(conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar todos los estados de usuario: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertarEstadoUsuario(EstadosUsuarios miEstado) {
        try (Connection conn = Conexion.getConnection()) {
            return insertarEstadoUsuario(miEstado, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar el estado de usuario: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarEstadoUsuario(EstadosUsuarios miEstado) {
        try (Connection conn = Conexion.getConnection()) {
            return actualizarEstadoUsuario(miEstado, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar el estado de usuario: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarEstadoUsuario(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return eliminarEstadoUsuario(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar el estado de usuario: " + e.getMessage());
            return false;
        }
    }
}