package Controlador;

import Modelo.EstadosPago;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EstadosPagoDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public EstadosPago consultarEstadoPago(int id, Connection conn) {
        EstadosPago miEstado = null;
        String querySql = "SELECT id_estados_pago, nombres_estados_pago FROM estados_pago WHERE id_estados_pago = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miEstado = new EstadosPago();
                    miEstado.setId_estados_pago(rs.getInt("id_estados_pago"));
                    miEstado.setNombres_estados_pago(rs.getString("nombres_estados_pago"));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar el estado de pago: " + e.getMessage());
        }

        return miEstado;
    }

    public List<EstadosPago> consultarTodos(Connection conn) {
        List<EstadosPago> lista = new ArrayList<>();
        String querySql = "SELECT id_estados_pago, nombres_estados_pago FROM estados_pago";

        try (PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                EstadosPago estado = new EstadosPago();
                estado.setId_estados_pago(rs.getInt("id_estados_pago"));
                estado.setNombres_estados_pago(rs.getString("nombres_estados_pago"));
                lista.add(estado);
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar todos los estados de pago: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertarEstadoPago(EstadosPago miEstado, Connection conn) {
        String querySql = "INSERT INTO estados_pago (nombres_estados_pago) VALUES (?)";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miEstado.getNombres_estados_pago());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar el estado de pago: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarEstadoPago(EstadosPago miEstado, Connection conn) {
        String querySql = "UPDATE estados_pago SET nombres_estados_pago = ? WHERE id_estados_pago = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miEstado.getNombres_estados_pago());
            ps.setInt(2, miEstado.getId_estados_pago());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar el estado de pago: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarEstadoPago(int id, Connection conn) {
        String querySql = "DELETE FROM estados_pago WHERE id_estados_pago = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar el estado de pago: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public EstadosPago consultarEstadoPago(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return consultarEstadoPago(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar el estado de pago: " + e.getMessage());
            return null;
        }
    }

    public List<EstadosPago> consultarTodos() {
        try (Connection conn = Conexion.getConnection()) {
            return consultarTodos(conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar todos los estados de pago: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertarEstadoPago(EstadosPago miEstado) {
        try (Connection conn = Conexion.getConnection()) {
            return insertarEstadoPago(miEstado, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar el estado de pago: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarEstadoPago(EstadosPago miEstado) {
        try (Connection conn = Conexion.getConnection()) {
            return actualizarEstadoPago(miEstado, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar el estado de pago: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarEstadoPago(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return eliminarEstadoPago(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar el estado de pago: " + e.getMessage());
            return false;
        }
    }
}