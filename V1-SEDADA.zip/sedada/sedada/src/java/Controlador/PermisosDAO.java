package Controlador;

import Modelo.Permisos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PermisosDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public Permisos consultarPermiso(int id, Connection conn) {
        Permisos miPermiso = null;
        String querySql = "SELECT id_permisos, nombre_permiso, descripcion_permiso "
                        + "FROM permisos WHERE id_permisos = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miPermiso = mapearPermiso(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar el permiso: " + e.getMessage());
        }

        return miPermiso;
    }

    public List<Permisos> consultarTodos(Connection conn) {
        List<Permisos> lista = new ArrayList<>();
        String querySql = "SELECT id_permisos, nombre_permiso, descripcion_permiso FROM permisos";

        try (PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearPermiso(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar todos los permisos: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertarPermiso(Permisos miPermiso, Connection conn) {
        String querySql = "INSERT INTO permisos (id_permisos, nombre_permiso, descripcion_permiso) "
                        + "VALUES (?, ?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, miPermiso.getId_permisos());
            ps.setString(2, miPermiso.getNombre_permiso());
            ps.setString(3, miPermiso.getDescripcion_permiso());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar el permiso: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarPermiso(Permisos miPermiso, Connection conn) {
        String querySql = "UPDATE permisos SET nombre_permiso = ?, "
                        + "descripcion_permiso = ? WHERE id_permisos = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miPermiso.getNombre_permiso());
            ps.setString(2, miPermiso.getDescripcion_permiso());
            ps.setInt(3, miPermiso.getId_permisos());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar el permiso: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarPermiso(int id, Connection conn) {
        String querySql = "DELETE FROM permisos WHERE id_permisos = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar el permiso: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public Permisos consultarPermiso(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return consultarPermiso(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar el permiso: " + e.getMessage());
            return null;
        }
    }

    public List<Permisos> consultarTodos() {
        try (Connection conn = Conexion.getConnection()) {
            return consultarTodos(conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar todos los permisos: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertarPermiso(Permisos miPermiso) {
        try (Connection conn = Conexion.getConnection()) {
            return insertarPermiso(miPermiso, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar el permiso: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarPermiso(Permisos miPermiso) {
        try (Connection conn = Conexion.getConnection()) {
            return actualizarPermiso(miPermiso, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar el permiso: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarPermiso(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return eliminarPermiso(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar el permiso: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS AUXILIARES
    // ==========================================

    private Permisos mapearPermiso(ResultSet rs) throws SQLException {
        Permisos permiso = new Permisos();
        permiso.setId_permisos(rs.getInt("id_permisos"));
        permiso.setNombre_permiso(rs.getString("nombre_permiso"));
        permiso.setDescripcion_permiso(rs.getString("descripcion_permiso"));
        return permiso;
    }
}