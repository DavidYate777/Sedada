package Controlador;

import Modelo.Productos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductosDAO {

    public Productos consultarPorId(int idProducto, Connection conexion) {
        Productos producto = null;
        String sql = "SELECT id_productos, nombres_productos, descripciones, precios, " +
                     "categorias_id_categorias, estados_productos_id_estados_productos, " +
                     "impuestos_dian_id_impuestos_dian FROM productos WHERE id_productos = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idProducto);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    producto = mapearProducto(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar producto por ID: " + e.getMessage());
        }

        return producto;
    }

    public List<Productos> consultar(Connection conexion) {
        List<Productos> listaProductos = new ArrayList<>();
        String sql = "SELECT id_productos, nombres_productos, descripciones, precios, " +
                     "categorias_id_categorias, estados_productos_id_estados_productos, " +
                     "impuestos_dian_id_impuestos_dian FROM productos";

        try (PreparedStatement ps = conexion.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                listaProductos.add(mapearProducto(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar productos: " + e.getMessage());
        }

        return listaProductos;
    }

    public boolean insertar(Productos producto, Connection conexion) {
        String sql = "INSERT INTO productos (nombres_productos, descripciones, precios, " +
                     "categorias_id_categorias, estados_productos_id_estados_productos, " +
                     "impuestos_dian_id_impuestos_dian) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, producto.getNombres_productos());
            ps.setString(2, producto.getDescripciones());
            ps.setBigDecimal(3, producto.getPrecios());
            ps.setInt(4, producto.getCategorias_id_categorias());
            ps.setInt(5, producto.getEstados_productos_id_estados_productos());
            ps.setInt(6, producto.getImpuestos_dian_id_impuestos_dian());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar producto: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Productos producto, Connection conexion) {
        String sql = "UPDATE productos SET nombres_productos = ?, descripciones = ?, precios = ?, " +
                     "categorias_id_categorias = ?, estados_productos_id_estados_productos = ?, " +
                     "impuestos_dian_id_impuestos_dian = ? WHERE id_productos = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setString(1, producto.getNombres_productos());
            ps.setString(2, producto.getDescripciones());
            ps.setBigDecimal(3, producto.getPrecios());
            ps.setInt(4, producto.getCategorias_id_categorias());
            ps.setInt(5, producto.getEstados_productos_id_estados_productos());
            ps.setInt(6, producto.getImpuestos_dian_id_impuestos_dian());
            ps.setInt(7, producto.getId_productos());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar producto: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idProducto, Connection conexion) {
        String sql = "DELETE FROM productos WHERE id_productos = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idProducto);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar producto: " + e.getMessage());
            return false;
        }
    }

    // Métodos sobrecargados con conexión autogestionada
    public Productos consultarPorId(int idProducto) {
        try (Connection con = Conexion.getConnection()) {
            return consultarPorId(idProducto, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión: " + e.getMessage());
            return null;
        }
    }

    public List<Productos> consultar() {
        try (Connection con = Conexion.getConnection()) {
            return consultar(con);
        } catch (SQLException e) {
            System.err.println("Error de conexión: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertar(Productos nuevoProducto) {
        try (Connection con = Conexion.getConnection()) {
            return insertar(nuevoProducto, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizar(Productos prodActualizar) {
        try (Connection con = Conexion.getConnection()) {
            return actualizar(prodActualizar, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int idAEliminar) {
        try (Connection con = Conexion.getConnection()) {
            return eliminar(idAEliminar, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión: " + e.getMessage());
            return false;
        }
    }

    private Productos mapearProducto(ResultSet rs) throws SQLException {
        Productos producto = new Productos();
        producto.setId_productos(rs.getInt("id_productos"));
        producto.setNombres_productos(rs.getString("nombres_productos"));
        producto.setDescripciones(rs.getString("descripciones"));
        producto.setPrecios(rs.getBigDecimal("precios"));
        producto.setCategorias_id_categorias(rs.getInt("categorias_id_categorias"));
        producto.setEstados_productos_id_estados_productos(rs.getInt("estados_productos_id_estados_productos"));
        producto.setImpuestos_dian_id_impuestos_dian(rs.getInt("impuestos_dian_id_impuestos_dian"));
        return producto;
    }
    public boolean cambiarEstadoProducto(int idProducto, int idEstado, Connection conexion) {
        String sql = "UPDATE productos SET estados_productos_id_estados_productos = ? WHERE id_productos = ?";

        try (PreparedStatement ps = conexion.prepareStatement(sql)) {
            ps.setInt(1, idEstado);
            ps.setInt(2, idProducto);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al cambiar estado de producto: " + e.getMessage());
            return false;
        }
    }

    public boolean activarProducto(int idProducto, int idEstadoActivo, Connection conexion) {
        return cambiarEstadoProducto(idProducto, idEstadoActivo, conexion);
    }

    public boolean activarProducto(int idProducto, int idEstadoActivo) {
        try (Connection con = Conexion.getConnection()) {
            return activarProducto(idProducto, idEstadoActivo, con);
        } catch (SQLException e) {
            System.err.println("Error de conexión al activar: " + e.getMessage());
            return false;
        }
    }
    public boolean inactivarProducto(int idProducto, int idEstadoInactivo, Connection conexion) {
    return cambiarEstadoProducto(idProducto, idEstadoInactivo, conexion);
}

    public boolean inactivarProducto(int idProducto, int idEstadoInactivo) {
        try (Connection con = Conexion.getConnection()) {
            return inactivarProducto(idProducto, idEstadoInactivo, con);
    } catch (SQLException e) {
        System.err.println("Error de conexión al inactivar: " + e.getMessage());
        return false;
    }
}
}