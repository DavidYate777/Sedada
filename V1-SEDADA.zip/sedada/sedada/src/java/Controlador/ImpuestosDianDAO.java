package Controlador;

import Modelo.ImpuestosDian;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ImpuestosDianDAO {

    // ==========================================
    // MÉTODOS CON CONEXIÓN POR PARÁMETRO
    // ==========================================

    public ImpuestosDian consultarImpuesto(int id, Connection conn) {
        ImpuestosDian miImpuesto = null;
        String querySql = "SELECT id_impuestos_dian, nombres_impuestos, porcentajes, fechas_inicio, fechas_fin "
                        + "FROM impuestos_dian WHERE id_impuestos_dian = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    miImpuesto = mapearImpuesto(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar el impuesto: " + e.getMessage());
        }

        return miImpuesto;
    }

    public List<ImpuestosDian> consultarTodos(Connection conn) {
        List<ImpuestosDian> lista = new ArrayList<>();
        String querySql = "SELECT id_impuestos_dian, nombres_impuestos, porcentajes, fechas_inicio, fechas_fin FROM impuestos_dian";

        try (PreparedStatement ps = conn.prepareStatement(querySql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapearImpuesto(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error al consultar todos los impuestos: " + e.getMessage());
        }

        return lista;
    }

    public boolean insertarImpuesto(ImpuestosDian miImpuesto, Connection conn) {
        String querySql = "INSERT INTO impuestos_dian (nombres_impuestos, porcentajes, fechas_inicio, fechas_fin) "
                        + "VALUES (?, ?, ?, ?)";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miImpuesto.getNombres_impuestos());
            ps.setBigDecimal(2, miImpuesto.getPorcentajes());
            ps.setObject(3, miImpuesto.getFecha_inicio());
            ps.setObject(4, miImpuesto.getFecha_fin());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al insertar el impuesto: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarImpuesto(ImpuestosDian miImpuesto, Connection conn) {
        String querySql = "UPDATE impuestos_dian SET nombres_impuestos = ?, porcentajes = ?, "
                        + "fechas_inicio = ?, fechas_fin = ? WHERE id_impuestos_dian = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setString(1, miImpuesto.getNombres_impuestos());
            ps.setBigDecimal(2, miImpuesto.getPorcentajes());
            ps.setObject(3, miImpuesto.getFecha_inicio());
            ps.setObject(4, miImpuesto.getFecha_fin());
            ps.setInt(5, miImpuesto.getId_impuestos_dian());

            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al actualizar el impuesto: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarImpuesto(int id, Connection conn) {
        String querySql = "DELETE FROM impuestos_dian WHERE id_impuestos_dian = ?";

        try (PreparedStatement ps = conn.prepareStatement(querySql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error al eliminar el impuesto: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS SOBRECARGADOS (CONEXIÓN AUTOGESTIONADA)
    // ==========================================

    public ImpuestosDian consultarImpuesto(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return consultarImpuesto(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar el impuesto: " + e.getMessage());
            return null;
        }
    }

    public List<ImpuestosDian> consultarTodos() {
        try (Connection conn = Conexion.getConnection()) {
            return consultarTodos(conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al consultar todos los impuestos: " + e.getMessage());
            return new ArrayList<>();
        }
    }

    public boolean insertarImpuesto(ImpuestosDian miImpuesto) {
        try (Connection conn = Conexion.getConnection()) {
            return insertarImpuesto(miImpuesto, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al insertar el impuesto: " + e.getMessage());
            return false;
        }
    }

    public boolean actualizarImpuesto(ImpuestosDian miImpuesto) {
        try (Connection conn = Conexion.getConnection()) {
            return actualizarImpuesto(miImpuesto, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al actualizar el impuesto: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminarImpuesto(int id) {
        try (Connection conn = Conexion.getConnection()) {
            return eliminarImpuesto(id, conn);
        } catch (SQLException e) {
            System.err.println("Error de conexión al eliminar el impuesto: " + e.getMessage());
            return false;
        }
    }

    // ==========================================
    // MÉTODOS AUXILIARES
    // ==========================================

    private ImpuestosDian mapearImpuesto(ResultSet rs) throws SQLException {
        ImpuestosDian impuesto = new ImpuestosDian();
        impuesto.setId_impuestos_dian(rs.getInt("id_impuestos_dian"));
        impuesto.setNombres_impuestos(rs.getString("nombres_impuestos"));
        impuesto.setPorcentajes(rs.getBigDecimal("porcentajes"));
        impuesto.setFecha_inicio(rs.getObject("fechas_inicio", LocalDate.class));
        impuesto.setFecha_fin(rs.getObject("fechas_fin", LocalDate.class));
        return impuesto;
    }
}