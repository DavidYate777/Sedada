<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - SEDADA</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons (para los iconos de los modales y campos) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Estilos Propios -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">
</head>
<body class="min-vh-100 d-flex align-items-center justify-content-center p-3">

    <main class="card login-card shadow-lg border-0 w-100" style="max-width: 900px;">
        <div class="row g-0">
            
            <!-- Panel Izquierdo (Presentación - Visible en pantallas medianas y grandes) -->
            <section class="col-lg-5 d-none d-lg-flex flex-column justify-content-between p-5 text-white brand-section bg-dark">
                <div>
                    <span class="fw-bold tracking-wide fs-5">SEDADA</span>
                </div>
                <div class="my-auto py-4">
                    <h1 class="display-6 fw-bold mb-3">Bienvenido al sistema</h1>
                    <p class="text-white-50 small mb-0">
                        Plataforma de gestión institucional. Inicie sesión para acceder a los módulos administrativos y de control.
                    </p>
                </div>
                <div>
                    <small class="text-white-50">&copy; SEDADA System. Todos los derechos reservados.</small>
                </div>
            </section>

            <!-- Panel Derecho (Formulario de Login) -->
            <section class="col-lg-7 col-12 p-4 p-md-5 bg-white">
                <div class="mb-4">
                    <h2 class="h3 fw-bold text-dark mb-1">Iniciar Sesión</h2>
                    <p class="text-muted small">Ingrese sus credenciales de acceso</p>
                </div>

                <%-- Notificación de Error adaptada a los parámetros del Servlet --%>
                <%
                    String error = request.getParameter("error");
                    if (error != null) {
                        String mensajeError = "Las credenciales ingresadas son incorrectas. Intente nuevamente.";
                        if ("campos".equals(error)) {
                            mensajeError = "Por favor, complete todos los campos obligatorios.";
                        }
                %>
                    <div class="alert alert-danger alert-dismissible fade show small" role="alert">
                        <%= mensajeError %>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <%
                    }
                %>

                <form action="${pageContext.request.contextPath}/LoginServlet" method="POST">
                    
                    <!-- Campo Correo (name="email" coincide exactamente con el Servlet) -->
                    <div class="mb-3">
                        <label for="email" class="form-label small text-muted">Correo electrónico</label>
                        <div class="input-group">
                            <span class="input-group-text text-muted">
                                <svg width="16" height="16" fill="currentColor" class="bi bi-person" viewBox="0 0 16 16">
                                    <path d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z"/>
                                </svg>
                            </span>
                            <input type="email" class="form-control" id="email" name="email" placeholder="nombre@ejemplo.com" autocomplete="email" required>
                        </div>
                    </div>

                    <!-- Campo Contraseña (name="password" coincide exactamente con el Servlet) -->
                    <div class="mb-3">
                        <label for="password" class="form-label small text-muted">Contraseña</label>
                        <div class="input-group">
                            <span class="input-group-text text-muted">
                                <svg width="16" height="16" fill="currentColor" class="bi bi-lock" viewBox="0 0 16 16">
                                    <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2zM5 8h6a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/>
                                </svg>
                            </span>
                            <input type="password" class="form-control" id="password" name="password" placeholder="••••••••" autocomplete="current-password" required>
                            <button class="btn btn-outline-secondary btn-toggle-pass" type="button" id="togglePassword">MOSTRAR</button>
                        </div>
                    </div>

                    <!-- Opciones de Login -->
                    <div class="d-flex justify-content-between align-items-center mb-4 small">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="remember" name="remember">
                            <label class="form-check-label text-muted" for="remember">Recordar equipo</label>
                        </div>
                        <a href="#" class="text-decoration-none text-primary fw-semibold">¿Olvidó su contraseña?</a>
                    </div>

                    <!-- Botón Principal -->
                    <button type="submit" class="btn btn-dark w-100 py-2 fw-semibold mb-3">
                        Ingresar al Sistema
                    </button>

                    <div class="position-relative text-center my-3">
                        <hr class="text-muted">
                        <span class="position-absolute top-50 start-50 translate-middle bg-white px-3 text-muted extra-small" style="font-size: 0.75rem;">
                            Otras opciones
                        </span>
                    </div>

                    <!-- Botón Secundario -->
                    <button type="button" class="btn btn-outline-secondary w-100 py-2 fw-semibold mb-3">
                        Autenticación Alternativa
                    </button>

                    <div class="text-center small text-muted mb-3">
                        ¿No tiene una cuenta? <a href="#" class="text-decoration-none text-primary fw-semibold">Solicitar Registro</a>
                    </div>

                    <!-- Enlaces a Términos y Privacidad -->
                    <div class="text-center pt-2 border-top" style="font-size: 0.75rem;">
                        <span class="text-muted">Al ingresar, aceptas nuestros</span><br>
                        <a href="#" class="text-primary text-decoration-none fw-semibold me-1" data-bs-toggle="modal" data-bs-target="#modalTerminos">
                            <i class="fa-solid fa-file-contract me-1"></i>Términos y Condiciones
                        </a>
                        <span class="text-muted">•</span>
                        <a href="#" class="text-primary text-decoration-none fw-semibold ms-1" data-bs-toggle="modal" data-bs-target="#modalPrivacidad">
                            <i class="fa-solid fa-shield-halved me-1"></i>Política de Privacidad
                        </a>
                    </div>

                </form>
            </section>
        </div>
    </main>

    <!-- ========================================== -->
    <!-- MODAL: TÉRMINOS Y CONDICIONES              -->
    <!-- ========================================== -->
    <div class="modal fade" id="modalTerminos" tabindex="-1" aria-labelledby="modalTerminosLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
            <div class="modal-content border-0 shadow-lg" style="border-radius: 12px;">
                <div class="modal-header bg-dark text-white p-3">
                    <div class="d-flex align-items-center gap-2">
                        <div class="bg-primary text-white rounded-2 p-2 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
                            <i class="fa-solid fa-file-contract fs-6"></i>
                        </div>
                        <div>
                            <h6 class="modal-title fw-bold m-0" id="modalTerminosLabel">Términos y Condiciones de Uso</h6>
                            <small class="text-white-50" style="font-size: 0.72rem;">SEDADA System • Enterprise Operations</small>
                        </div>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <div class="modal-body p-4 text-secondary" style="font-size: 0.88rem; line-height: 1.6;">
                    <p class="fw-semibold text-dark mb-3">Última actualización: Septiembre 2026</p>
                    
                    <h6 class="fw-bold text-dark mt-3 mb-2"><i class="fa-solid fa-circle-check text-primary me-2"></i>1. Aceptación del Servicio</h6>
                    <p>Al acceder y utilizar el sistema <strong>SEDADA</strong> (Software Enterprise de Administración y Desarrollo de Alimentos), el usuario acepta cumplir de manera irrestricta con los términos y condiciones aquí estipulados. Si no está de acuerdo con estos términos, deberá abstenerse de utilizar el sistema.</p>

                    <h6 class="fw-bold text-dark mt-4 mb-2"><i class="fa-solid fa-user-shield text-primary me-2"></i>2. Credenciales y Responsabilidad de Cuenta</h6>
                    <p>Las credenciales de acceso (correo electrónico y contraseña) son personales e intransferibles. Cada colaborador es responsable de salvaguardar su clave. Cualquier operación realizada desde una cuenta activa será atribuida directamente al titular asignado por la administración.</p>

                    <h6 class="fw-bold text-dark mt-4 mb-2"><i class="fa-solid fa-cash-register text-primary me-2"></i>3. Uso Aceptable del Punto de Venta (POS)</h6>
                    <p>El sistema está diseñado exclusivamente para la gestión operativa de pedidos, facturación, comandas de cocina y control de inventario. Queda estrictamente prohibido:</p>
                    <ul class="ps-3">
                        <li>Alterar o manipular malintencionadamente los registros de facturación o comandas.</li>
                        <li>Compartir accesos con personal no autorizado externamente.</li>
                        <li>Intentar vulnerar la seguridad, la base de datos o la API de la plataforma.</li>
                    </ul>

                    <h6 class="fw-bold text-dark mt-4 mb-2"><i class="fa-solid fa-receipt text-primary me-2"></i>4. Cumplimiento Normativo y Facturación</h6>
                    <p>SEDADA integra parámetros operativos acordes a la normativa tributaria aplicable (incluyendo esquemas de Impoconsumo e IVA). La administración del establecimiento es responsable de garantizar la veracidad de los datos emitidos en los comprobantes finales.</p>

                    <h6 class="fw-bold text-dark mt-4 mb-2"><i class="fa-solid fa-triangle-exclamation text-primary me-2"></i>5. Disponibilidad del Sistema</h6>
                    <p>Aunque SEDADA opera con altos estándares de disponibilidad continua en infraestructura en la nube, la plataforma no se hace responsable por interrupciones derivadas de fallos en el proveedor local de red de internet o mantenimiento programado.</p>
                </div>

                <div class="modal-footer bg-light p-3 d-flex justify-content-between align-items-center">
                    <small class="text-muted" style="font-size: 0.75rem;"><i class="fa-solid fa-lock me-1"></i> Documento legal vinculado a su sesión de usuario</small>
                    <button type="button" class="btn btn-dark btn-sm fw-semibold px-4" data-bs-dismiss="modal">Entendido y Aceptar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- ========================================== -->
    <!-- MODAL: POLÍTICA DE PRIVACIDAD               -->
    <!-- ========================================== -->
    <div class="modal fade" id="modalPrivacidad" tabindex="-1" aria-labelledby="modalPrivacidadLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
            <div class="modal-content border-0 shadow-lg" style="border-radius: 12px;">
                <div class="modal-header bg-dark text-white p-3">
                    <div class="d-flex align-items-center gap-2">
                        <div class="bg-success text-white rounded-2 p-2 d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;">
                            <i class="fa-solid fa-shield-halved fs-6"></i>
                        </div>
                        <div>
                            <h6 class="modal-title fw-bold m-0" id="modalPrivacidadLabel">Política de Tratamiento de Datos Personales</h6>
                            <small class="text-white-50" style="font-size: 0.72rem;">Protección de Datos & Habeas Data</small>
                        </div>
                    </div>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <div class="modal-body p-4 text-secondary" style="font-size: 0.88rem; line-height: 1.6;">
                    <p class="fw-semibold text-dark mb-3">En cumplimiento de las normativas vigentes sobre Protección de Datos Personales (Ley 1581 de 2012 / Habeas Data).</p>
                    
                    <h6 class="fw-bold text-dark mt-3 mb-2"><i class="fa-solid fa-database text-success me-2"></i>1. Datos Recolectados</h6>
                    <p>SEDADA almacena y procesa información estrictamente necesaria para el desarrollo operativo, tales como:</p>
                    <ul class="ps-3">
                        <li><strong>Datos de usuarios del sistema:</strong> Nombres, apellidos, correo corporativo, número de documento y rol operativo.</li>
                        <li><strong>Datos de clientes (para domicilios y facturación):</strong> Teléfonos de contacto, dirección de entrega e identificación tributaria.</li>
                        <li><strong>Seguridad de claves:</strong> Las contraseñas de los usuarios no se almacenan en texto plano; son encriptadas mediante algoritmos de cifrado unidireccional de alto estándar (BCrypt).</li>
                    </ul>

                    <h6 class="fw-bold text-dark mt-4 mb-2"><i class="fa-solid fa-bullseye text-success me-2"></i>2. Finalidad del Tratamiento de Datos</h6>
                    <p>La información recolectada tiene como único fin:</p>
                    <ul class="ps-3">
                        <li>Autenticación y control de permisos basados en roles (Administrador, Mesero, Cajero, Cocina).</li>
                        <li>Generación de reportes de auditoría, trazabilidad de ventas e historial de comisiones/turnos.</li>
                        <li>Procesamiento correcto de entregas y coordinación de pedidos a domicilio.</li>
                    </ul>

                    <h6 class="fw-bold text-dark mt-4 mb-2"><i class="fa-solid fa-user-lock text-success me-2"></i>3. Confidencialidad y Seguridad</h6>
                    <p>SEDADA garantiza que la información no será cedida, vendida ni comercializada a terceros. La infraestructura hace uso de canales cifrados (SSL/TLS) para la transmisión de información con la base de datos central en la nube.</p>

                    <h6 class="fw-bold text-dark mt-4 mb-2"><i class="fa-solid fa-scale-balanced text-success me-2"></i>4. Derechos del Titular (ARCO)</h6>
                    <p>El titular de los datos tiene derecho a conocer, actualizar, rectificar y solicitar la supresión de sus datos personales de los registros del sistema, comunicándose directamente con el administrador general del establecimiento.</p>
                </div>

                <div class="modal-footer bg-light p-3 d-flex justify-content-between align-items-center">
                    <small class="text-muted" style="font-size: 0.75rem;"><i class="fa-solid fa-shield me-1"></i> Cifrado de contraseñas activo mediante BCrypt</small>
                    <button type="button" class="btn btn-dark btn-sm fw-semibold px-4" data-bs-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const togglePassword = document.getElementById("togglePassword");
        const password = document.getElementById("password");

        togglePassword.addEventListener("click", function () {
            const isPassword = password.type === "password";
            password.type = isPassword ? "text" : "password";
            this.textContent = isPassword ? "OCULTAR" : "MOSTRAR";
        });
    </script>
</body>
</html>