<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuarios" %>
<%@ page import="Modelo.Productos" %>
<%@ page import="java.util.List" %>
<%
    Usuarios user = (Usuarios) session.getAttribute("usuarioLogueado");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
    
    List<Productos> listaProductos = (List<Productos>) request.getAttribute("listaProductos");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inventario - SEDADA Enterprise OPS</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Archivo CSS centralizado -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">
</head>
<body class="admin-body">

    <!-- Menú Lateral -->
    <div class="admin-sidebar">
        <div class="brand d-flex align-items-center gap-2">
            <div class="bg-dark text-white rounded p-1 px-2 fw-bold" style="font-size: 0.8rem;">SD</div>
            <div>
                <div style="line-height: 1.2;">SEDADA</div>
                <small class="text-muted fw-normal" style="font-size: 0.70rem;">ENTERPRISE OPS</small>
            </div>
        </div>
        
        <div class="px-2 mt-2 flex-grow-1">
            <div class="text-muted px-3 mb-1" style="font-size: 0.65rem; letter-spacing: 0.5px;">MAIN MENU</div>
            <ul class="nav flex-column gap-1">
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/admin_dashboard" class="nav-link"><i class="fa-solid fa-shapes"></i> Resumen</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/pedidos" class="nav-link"><i class="fa-solid fa-cart-shopping"></i> Pedidos</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/inventario" class="nav-link active"><i class="fa-solid fa-boxes-stacked"></i> Inventario</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/mesas" class="nav-link"><i class="fa-solid fa-chair"></i> Mesas</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/usuarios" class="nav-link"><i class="fa-solid fa-users"></i> Usuarios</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/categorias" class="nav-link"><i class="fa-solid fa-layer-group"></i> Categorías</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/facturas" class="nav-link"><i class="fa-solid fa-file-invoice-dollar"></i> Facturación e Impuestos</a></li>
            </ul>
        </div>

        <div class="p-3 border-top">
            <a href="#" class="nav-link mb-2"><i class="fa-solid fa-circle-question"></i> Soporte</a>
            <a href="${pageContext.request.contextPath}/LoginServlet?accion=logout" class="nav-link text-danger"><i class="fa-solid fa-right-from-bracket"></i> Cerrar Sesión</a>
        </div>
    </div>

    <!-- Área de Contenido Principal -->
    <div class="admin-main-content">
        
        <!-- Barra Superior -->
        <div class="admin-top-navbar mb-3">
            <div class="text-muted small">SEDADA / Catálogo / <span class="text-dark fw-semibold">Inventario</span></div>
            <div class="position-relative">
                <i class="fa-solid fa-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted small"></i>
                <input type="text" class="form-control admin-search-box ps-5 text-muted small" placeholder="Search inventory...">
            </div>
            <div class="d-flex align-items-center gap-3">
                <i class="fa-regular fa-bell text-secondary fs-6" style="cursor: pointer;"></i>
                <a href="${pageContext.request.contextPath}/perfil" class="text-secondary d-flex align-items-center text-decoration-none" title="Configuración de Perfil">
                    <i class="fa-solid fa-gear fs-6"></i>
                </a>
                <div class="d-flex align-items-center gap-2 border-start ps-3">
                    <div class="bg-dark text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 32px; height: 32px; font-size: 0.8rem;">
                        <%= user.getNombre_usuarios().substring(0, 1).toUpperCase() %>
                    </div>
                    <div>
                        <span class="fw-semibold text-dark small d-block" style="line-height: 1;"><%= user.getNombre_usuarios() %></span>
                        <small class="text-muted" style="font-size: 0.7rem;">SEDADA Central</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Encabezado de la Sección -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold m-0" style="font-size: 1.4rem;">Product Inventory</h3>
                <p class="text-muted small m-0 mt-1">Manage your menu items, pricing, and categories.</p>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-outline-dark btn-sm fw-semibold bg-white px-3"><i class="fa-solid fa-download me-1"></i> Export</button>
                <button class="btn btn-dark btn-sm fw-semibold px-3" data-bs-toggle="modal" data-bs-target="#modalNuevoProducto">
                    <i class="fa-solid fa-plus me-1"></i> Add Product
                </button>
            </div>
        </div>

        <!-- Tabla de Inventario -->
        <div class="table-container">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="text-muted small bg-light">
                        <tr>
                            <th class="py-3 ps-3">PRODUCT NAME</th>
                            <th>DESCRIPTION</th>
                            <th>CATEGORY ID</th>
                            <th>PRICE</th>
                            <th>STATUS ID</th>
                            <th class="text-end pe-3">ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <% 
                            if (listaProductos != null && !listaProductos.isEmpty()) {
                                for (Productos prod : listaProductos) {
                        %>
                        <tr>
                            <td class="fw-semibold ps-3">
                                <div class="d-flex align-items-center gap-2">
                                    <div class="bg-light border rounded d-flex align-items-center justify-content-center text-muted" style="width: 36px; height: 36px;">
                                        <i class="fa-solid fa-utensils"></i>
                                    </div>
                                    <span><%= prod.getNombres_productos() %></span>
                                </div>
                            </td>
                            <td class="text-muted"><%= prod.getDescripciones() %></td>
                            <td class="text-muted">Cat. ID: <%= prod.getCategorias_id_categorias() %></td>
                            <td class="fw-bold">$<%= prod.getPrecios() %></td>
                            <td>
                                <span class="badge bg-secondary bg-opacity-10 text-secondary border px-2 py-1">
                                    Estado ID: <%= prod.getEstados_productos_id_estados_productos() %>
                                </span>
                            </td>
                            <td class="text-end pe-3">
                                <div class="d-flex justify-content-end gap-1">
                                    <button class="btn btn-sm btn-outline-dark py-0 px-2" data-bs-toggle="modal" data-bs-target="#modalEditar<%= prod.getId_productos() %>" title="Editar producto">
                                        <i class="fa-solid fa-pen"></i>
                                    </button>
                                    <a href="${pageContext.request.contextPath}/admin/inventario?accion=eliminar&id=<%= prod.getId_productos() %>" class="btn btn-sm btn-outline-danger py-0 px-2" onclick="return confirm('¿Desea eliminar este producto?');" title="Eliminar producto">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>

                        <!-- Modal Editar Producto -->
                        <div class="modal fade" id="modalEditar<%= prod.getId_productos() %>" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form action="${pageContext.request.contextPath}/admin/inventario" method="POST">
                                        <input type="hidden" name="accion" value="actualizar">
                                        <input type="hidden" name="id_productos" value="<%= prod.getId_productos() %>">
                                        <div class="modal-header">
                                            <h5 class="modal-title fw-bold fs-6">Editar Producto: <%= prod.getNombres_productos() %></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body small">
                                            <div class="mb-3">
                                                <label class="form-label fw-semibold">Nombre del Producto</label>
                                                <input type="text" class="form-control form-control-sm" name="nombre_productos" value="<%= prod.getNombres_productos() %>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label fw-semibold">Descripción</label>
                                                <input type="text" class="form-control form-control-sm" name="descripciones" value="<%= prod.getDescripciones() %>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label fw-semibold">Precio ($)</label>
                                                <input type="number" step="0.01" class="form-control form-control-sm" name="precio" value="<%= prod.getPrecios() %>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label fw-semibold">ID Categoría</label>
                                                <input type="number" class="form-control form-control-sm" name="categorias_id_categorias" value="<%= prod.getCategorias_id_categorias() %>" required>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                                            <button type="submit" class="btn btn-dark btn-sm">Guardar Cambios</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <% 
                                }
                            } else {
                        %>
                        <tr>
                            <td colspan="6" class="text-center py-4 text-muted">No hay productos registrados en el inventario.</td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- Modal Añadir Producto (Crear) -->
    <div class="modal fade" id="modalNuevoProducto" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="${pageContext.request.contextPath}/admin/inventario" method="POST">
                    <input type="hidden" name="accion" value="insertar">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold fs-6">Añadir Nuevo Producto</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body small">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Nombre del Producto</label>
                            <input type="text" class="form-control form-control-sm" name="nombre_productos" placeholder="Ej. Lomo Saltado" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Descripción</label>
                            <input type="text" class="form-control form-control-sm" name="descripciones" placeholder="Ej. Plato típico con carne" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Precio ($)</label>
                            <input type="number" step="0.01" class="form-control form-control-sm" name="precio" placeholder="Ej. 24.00" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">ID Categoría</label>
                            <input type="number" class="form-control form-control-sm" name="categorias_id_categorias" placeholder="Ej. 1" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-dark btn-sm">Agregar Producto</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>