<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuarios" %>
<%@ page import="java.util.List" %>
<%
    Usuarios user = (Usuarios) session.getAttribute("usuarioLogueado");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
    
    List<Usuarios> listaUsuarios = (List<Usuarios>) request.getAttribute("listaUsuarios");
    Integer totalColaboradores = (Integer) request.getAttribute("totalColaboradores");
    Long usuariosActivos = (Long) request.getAttribute("usuariosActivos");
    
    if (totalColaboradores == null) totalColaboradores = 0;
    if (usuariosActivos == null) usuariosActivos = 0L;
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Usuarios - SEDADA Enterprise OPS</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Archivo CSS centralizado -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">
</head>
<body class="admin-body">

    <!-- Menú Lateral -->
    <div class="admin-sidebar">
        <div class="brand d-flex align-items-center gap-2">
            <div class="bg-dark text-white rounded p-1 px-2 fw-bold" style="font-size: 0.8rem;">SD</div>
            <div>
                <div style="line-height: 1.2;">SEDADA</div>
                <small class="text-muted fw-normal" style="font-size: 0.70rem;">ENTERPRISE OPS</small>
            </div>
        </div>
        
        <div class="px-2 mt-2 flex-grow-1">
            <div class="text-muted px-3 mb-1" style="font-size: 0.65rem; letter-spacing: 0.5px;">MAIN MENU</div>
            <ul class="nav flex-column gap-1">
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/admin_dashboard" class="nav-link"><i class="fa-solid fa-shapes"></i> Resumen</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/pedidos" class="nav-link"><i class="fa-solid fa-cart-shopping"></i> Pedidos</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/inventario" class="nav-link"><i class="fa-solid fa-boxes-stacked"></i> Inventario</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/mesas" class="nav-link"><i class="fa-solid fa-chair"></i> Mesas</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/usuarios" class="nav-link active"><i class="fa-solid fa-users"></i> Usuarios</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/categorias" class="nav-link"><i class="fa-solid fa-layer-group"></i> Categorías</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/facturas" class="nav-link"><i class="fa-solid fa-file-invoice-dollar"></i> Facturación e Impuestos</a></li>
            </ul>
        </div>

        <div class="p-3 border-top">
            <a href="#" class="nav-link mb-2"><i class="fa-solid fa-circle-question"></i> Soporte</a>
            <a href="${pageContext.request.contextPath}/LoginServlet?accion=logout" class="nav-link text-danger"><i class="fa-solid fa-right-from-bracket"></i> Cerrar Sesión</a>
        </div>
    </div>

    <!-- Área de Contenido Principal -->
    <div class="admin-main-content">
        
        <!-- Barra Superior -->
        <div class="admin-top-navbar mb-3">
            <div class="text-muted small">SEDADA / Recursos Humanos / <span class="text-dark fw-semibold">Gestión de Usuarios</span></div>
            <div class="position-relative">
                <i class="fa-solid fa-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted small"></i>
                <input type="text" class="form-control admin-search-box ps-5 text-muted small" placeholder="Search orders, inventory items, or staff...">
            </div>
            <div class="d-flex align-items-center gap-3">
                <i class="fa-regular fa-bell text-secondary fs-6" style="cursor: pointer;"></i>
                <a href="${pageContext.request.contextPath}/perfil" class="text-secondary d-flex align-items-center text-decoration-none" title="Configuración de Perfil">
                    <i class="fa-solid fa-gear fs-6"></i>
                </a>
                <div class="d-flex align-items-center gap-2 border-start ps-3">
                    <div class="bg-dark text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 32px; height: 32px; font-size: 0.8rem;">
                        <%= user.getNombre_usuarios().substring(0, 1).toUpperCase() %>
                    </div>
                    <div>
                        <span class="fw-semibold text-dark small d-block" style="line-height: 1;"><%= user.getNombre_usuarios() %></span>
                        <small class="text-muted" style="font-size: 0.7rem;">SEDADA Central</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- ERP Sub-header -->
        <div class="mb-2">
            <div class="text-muted small fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">SEDADA ERP • RECURSOS HUMANOS • <span class="text-success">Supabase Sync: Activo</span></div>
        </div>

        <!-- Encabezado de la Sección y Botones -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold m-0" style="font-size: 1.4rem;">Gestión de Usuarios y Personal</h3>
                <p class="text-muted small m-0 mt-1">Administra los roles, permisos de acceso y estados del equipo de trabajo sincronizados con PostgreSQL/Supabase.</p>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-outline-dark btn-sm fw-semibold bg-white px-3"><i class="fa-solid fa-download me-1"></i> Exportar Nómina</button>
                <button class="btn btn-dark btn-sm fw-semibold px-3" data-bs-toggle="modal" data-bs-target="#modalNuevoUsuario">
                    <i class="fa-solid fa-user-plus me-1"></i> + Nuevo Usuario
                </button>
            </div>
        </div>

        <!-- Tarjetas de Métricas -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">TOTAL COLABORADORES</span>
                        <div class="bg-light p-2 rounded-2 text-primary"><i class="fa-solid fa-users"></i></div>
                    </div>
                    <h3 class="fw-bold m-0"><%= totalColaboradores %></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;"><i class="fa-solid fa-circle text-success me-1" style="font-size: 8px;"></i> USUARIOS ACTIVOS</span>
                        <div class="bg-light p-2 rounded-2 text-success"><i class="fa-solid fa-shield-halved"></i></div>
                    </div>
                    <h3 class="fw-bold m-0"><%= usuariosActivos %> <span class="text-muted fw-normal fs-6">de <%= totalColaboradores %></span></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;"><i class="fa-solid fa-circle text-warning me-1" style="font-size: 8px;"></i> TURNOS EN CURSO</span>
                        <div class="bg-light p-2 rounded-2 text-warning"><i class="fa-solid fa-clock"></i></div>
                    </div>
                    <h3 class="fw-bold m-0" style="font-size: 1.15rem;">Turno Matutino</h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">ROLES OPERATIVOS</span>
                        <div class="bg-light p-2 rounded-2 text-info"><i class="fa-solid fa-id-badge"></i></div>
                    </div>
                    <h3 class="fw-bold m-0">4 <span class="text-muted fw-normal fs-6">Roles Activos</span></h3>
                </div>
            </div>
        </div>

        <!-- Tabla de Usuarios -->
        <div class="table-container">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="text-muted small bg-light">
                        <tr>
                            <th class="py-3 ps-3">COLABORADOR / IDENTIDAD</th>
                            <th>DOCUMENTO LEGAL</th>
                            <th>ROL ASIGNADO</th>
                            <th>CONTACTO & RESIDENCIA</th>
                            <th>ESTADO</th>
                            <th class="text-end pe-3">ACCIONES</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <% 
                            if (listaUsuarios != null && !listaUsuarios.isEmpty()) {
                                for (Usuarios u : listaUsuarios) {
                                    String iniciales = (u.getNombre_usuarios() != null && !u.getNombre_usuarios().isEmpty() ? u.getNombre_usuarios().substring(0, 1) : "U") +
                                                       (u.getApellido_usuarios() != null && !u.getApellido_usuarios().isEmpty() ? u.getApellido_usuarios().substring(0, 1) : "");
                                    
                                    boolean activo = u.getEstados_usuarios_id_estados_usuario() == 1;
                        %>
                        <tr>
                            <td class="ps-3">
                                <div class="d-flex align-items-center gap-2">
                                    <div class="bg-dark text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 36px; height: 36px; font-size: 0.8rem;">
                                        <%= iniciales.toUpperCase() %>
                                    </div>
                                    <div>
                                        <div class="fw-bold text-dark"><%= u.getNombre_usuarios() %> <%= u.getApellido_usuarios() %></div>
                                        <div class="text-muted" style="font-size: 0.75rem;"><%= u.getCorreos() %></div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <div class="fw-semibold">Doc: <%= u.getNumero_documentos() %></div>
                                <div class="text-muted" style="font-size: 0.75rem;">Tipo ID: <%= u.getTipo_de_documentos_id_tipo_de_documento() %></div>
                            </td>
                            <td>
                                <span class="badge bg-primary bg-opacity-10 text-primary border border-primary-subtle px-2 py-1">
                                    Rol ID: <%= u.getRoles_id_roles() %>
                                </span>
                            </td>
                            <td>
                                <div><i class="fa-solid fa-phone text-muted me-1 small"></i> <%= u.getTelefonos() %></div>
                                <div class="text-muted" style="font-size: 0.75rem;"><%= u.getDireccion_usuarios() %></div>
                            </td>
                            <td>
                                <span class="badge <%= activo ? "bg-success text-success" : "bg-secondary text-secondary" %> bg-opacity-10 border px-2 py-1">
                                    <i class="fa-solid fa-circle me-1" style="font-size: 5px;"></i> <%= activo ? "Activo" : "Inactivo" %>
                                </span>
                            </td>
                            <td class="text-end pe-3">
                                <div class="d-flex justify-content-end gap-1">
                                    <button class="btn btn-sm btn-outline-dark py-0 px-2" data-bs-toggle="modal" data-bs-target="#modalEditarUsuario<%= u.getId_Usuarios() %>" title="Editar usuario">
                                        <i class="fa-solid fa-pen"></i>
                                    </button>
                                    <a href="${pageContext.request.contextPath}/admin/usuarios?accion=eliminar&id=<%= u.getId_Usuarios() %>" class="btn btn-sm btn-outline-danger py-0 px-2" onclick="return confirm('¿Desea eliminar este usuario?');" title="Eliminar usuario">
                                        <i class="fa-solid fa-trash-can"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>

                        <!-- Modal Editar Usuario -->
                        <div class="modal fade" id="modalEditarUsuario<%= u.getId_Usuarios() %>" tabindex="-1" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form action="${pageContext.request.contextPath}/admin/usuarios" method="POST">
                                        <input type="hidden" name="accion" value="actualizar">
                                        <input type="hidden" name="id_Usuarios" value="<%= u.getId_Usuarios() %>">
                                        <div class="modal-header">
                                            <h5 class="modal-title fw-bold fs-6">Editar Usuario: <%= u.getNombre_usuarios() %></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body small">
                                            <div class="mb-2">
                                                <label class="form-label fw-semibold">Nombres</label>
                                                <input type="text" class="form-control form-control-sm" name="nombre_usuarios" value="<%= u.getNombre_usuarios() %>" required>
                                            </div>
                                            <div class="mb-2">
                                                <label class="form-label fw-semibold">Apellidos</label>
                                                <input type="text" class="form-control form-control-sm" name="apellido_usuarios" value="<%= u.getApellido_usuarios() %>" required>
                                            </div>
                                            <div class="mb-2">
                                                <label class="form-label fw-semibold">Correo Electrónico</label>
                                                <input type="email" class="form-control form-control-sm" name="correos" value="<%= u.getCorreos() %>" required>
                                            </div>
                                            <div class="mb-2">
                                                <label class="form-label fw-semibold">Contraseña</label>
                                                <input type="text" class="form-control form-control-sm" name="passwords" value="<%= u.getPasswords() %>" required>
                                            </div>
                                            <div class="mb-2">
                                                <label class="form-label fw-semibold">Teléfono</label>
                                                <input type="text" class="form-control form-control-sm" name="telefonos" value="<%= u.getTelefonos() %>" required>
                                            </div>
                                            <div class="mb-2">
                                                <label class="form-label fw-semibold">Dirección</label>
                                                <input type="text" class="form-control form-control-sm" name="direccion_usuarios" value="<%= u.getDireccion_usuarios() %>" required>
                                            </div>
                                            <div class="mb-2">
                                                <label class="form-label fw-semibold">Número de Documento</label>
                                                <input type="text" class="form-control form-control-sm" name="numero_documentos" value="<%= u.getNumero_documentos() %>" required>
                                            </div>
                                            <div class="mb-2">
                                                <label class="form-label fw-semibold">ID Tipo de Documento</label>
                                                <input type="number" class="form-control form-control-sm" name="tipo_de_documentos_id_tipo_de_documento" value="<%= u.getTipo_de_documentos_id_tipo_de_documento() %>" required>
                                            </div>
                                            <div class="mb-2">
                                                <label class="form-label fw-semibold">ID Rol</label>
                                                <input type="number" class="form-control form-control-sm" name="roles_id_roles" value="<%= u.getRoles_id_roles() %>" required>
                                            </div>
                                            <div class="mb-2">
                                                <label class="form-label fw-semibold">ID Estado de Usuario (1: Activo, etc.)</label>
                                                <input type="number" class="form-control form-control-sm" name="estados_usuarios_id_estados_usuario" value="<%= u.getEstados_usuarios_id_estados_usuario() %>" required>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                                            <button type="submit" class="btn btn-dark btn-sm">Guardar Cambios</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <% 
                                }
                            } else {
                        %>
                        <tr>
                            <td colspan="6" class="text-center py-4 text-muted">No hay usuarios registrados en el sistema.</td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- Modal Nuevo Usuario (Crear) -->
    <div class="modal fade" id="modalNuevoUsuario" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="${pageContext.request.contextPath}/admin/usuarios" method="POST">
                    <input type="hidden" name="accion" value="insertar">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold fs-6">Registrar Nuevo Colaborador</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body small">
                        <div class="mb-2">
                            <label class="form-label fw-semibold">Nombres</label>
                            <input type="text" class="form-control form-control-sm" name="nombre_usuarios" placeholder="Ej. Carlos" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label fw-semibold">Apellidos</label>
                            <input type="text" class="form-control form-control-sm" name="apellido_usuarios" placeholder="Ej. Sánchez" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label fw-semibold">Correo Electrónico</label>
                            <input type="email" class="form-control form-control-sm" name="correos" placeholder="carlos.s@sedada.com" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label fw-semibold">Contraseña</label>
                            <input type="password" class="form-control form-control-sm" name="passwords" placeholder="••••••••" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label fw-semibold">Teléfono</label>
                            <input type="text" class="form-control form-control-sm" name="telefonos" placeholder="+57 310 492 8812" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label fw-semibold">Dirección</label>
                            <input type="text" class="form-control form-control-sm" name="direccion_usuarios" placeholder="Cra 43A #14-25" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label fw-semibold">Número de Documento</label>
                            <input type="text" class="form-control form-control-sm" name="numero_documentos" placeholder="1.020.456.789" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label fw-semibold">ID Tipo de Documento</label>
                            <input type="number" class="form-control form-control-sm" name="tipo_de_documentos_id_tipo_de_documento" placeholder="1" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label fw-semibold">ID Rol</label>
                            <input type="number" class="form-control form-control-sm" name="roles_id_roles" placeholder="1" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-dark btn-sm">Registrar Colaborador</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>