<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuarios" %>
<%@ page import="Modelo.Facturas" %>
<%@ page import="Modelo.ImpuestosDian" %>
<%@ page import="java.util.List" %>
<%@ page import="java.math.BigDecimal" %>
<%
    Usuarios user = (Usuarios) session.getAttribute("usuarioLogueado");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
    
    List<Facturas> listaFacturas = (List<Facturas>) request.getAttribute("listaFacturas");
    List<ImpuestosDian> listaImpuestos = (List<ImpuestosDian>) request.getAttribute("listaImpuestos");
    Facturas facturaSeleccionada = (Facturas) request.getAttribute("facturaSeleccionada");
    
    BigDecimal totalInvoicedToday = (BigDecimal) request.getAttribute("totalInvoicedToday");
    BigDecimal totalTaxCollected = (BigDecimal) request.getAttribute("totalTaxCollected");
    
    if (totalInvoicedToday == null) totalInvoicedToday = BigDecimal.ZERO;
    if (totalTaxCollected == null) totalTaxCollected = BigDecimal.ZERO;
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facturación e Impuestos - SEDADA Enterprise OPS</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Archivo CSS centralizado -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">
</head>
<body class="admin-body">

    <!-- Menú Lateral -->
    <div class="admin-sidebar">
        <div class="brand d-flex align-items-center gap-2">
            <div class="bg-dark text-white rounded p-1 px-2 fw-bold" style="font-size: 0.8rem;">SD</div>
            <div>
                <div style="line-height: 1.2;">SEDADA</div>
                <small class="text-muted fw-normal" style="font-size: 0.70rem;">ENTERPRISE OPS</small>
            </div>
        </div>
        
        <div class="px-2 mt-2 flex-grow-1">
            <div class="text-muted px-3 mb-1" style="font-size: 0.65rem; letter-spacing: 0.5px;">MAIN MENU</div>
            <ul class="nav flex-column gap-1">
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/admin_dashboard" class="nav-link"><i class="fa-solid fa-shapes"></i> Resumen</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/pedidos" class="nav-link"><i class="fa-solid fa-cart-shopping"></i> Pedidos</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/inventario" class="nav-link"><i class="fa-solid fa-boxes-stacked"></i> Inventario</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/mesas" class="nav-link"><i class="fa-solid fa-chair"></i> Mesas</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/usuarios" class="nav-link"><i class="fa-solid fa-users"></i> Usuarios</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/categorias" class="nav-link"><i class="fa-solid fa-layer-group"></i> Categorías</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/facturas" class="nav-link active"><i class="fa-solid fa-file-invoice-dollar"></i> Facturación e Impuestos</a></li>
            </ul>
        </div>

        <div class="p-3 border-top">
            <a href="#" class="nav-link mb-2"><i class="fa-solid fa-circle-question"></i> Soporte</a>
            <a href="${pageContext.request.contextPath}/LoginServlet?accion=logout" class="nav-link text-danger"><i class="fa-solid fa-right-from-bracket"></i> Cerrar Sesión</a>
        </div>
    </div>

    <!-- Área de Contenido Principal (Diseño dividido dinámicamente) -->
    <div class="admin-main-content <%= facturaSeleccionada != null ? "d-flex gap-3 align-items-start" : "" %>">
        
        <!-- Columna Izquierda: Listado y Métricas de Facturación -->
        <div class="<%= facturaSeleccionada != null ? "flex-grow-1" : "w-100" %>">
            
            <!-- Barra Superior -->
            <div class="admin-top-navbar mb-3">
                <div class="text-muted small">SEDADA / Contabilidad / <span class="text-dark fw-semibold">Facturación e Impuestos</span></div>
                <div class="position-relative">
                    <i class="fa-solid fa-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted small"></i>
                    <input type="text" class="form-control admin-search-box ps-5 text-muted small" placeholder="Search invoices...">
                </div>
                <div class="d-flex align-items-center gap-3">
                    <i class="fa-regular fa-bell text-secondary fs-6" style="cursor: pointer;"></i>
                    <a href="${pageContext.request.contextPath}/perfil" class="text-secondary d-flex align-items-center text-decoration-none" title="Configuración de Perfil">
                        <i class="fa-solid fa-gear fs-6"></i>
                    </a>
                    <div class="d-flex align-items-center gap-2 border-start ps-3">
                        <div class="bg-dark text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 32px; height: 32px; font-size: 0.8rem;">
                            <%= user.getNombre_usuarios().substring(0, 1).toUpperCase() %>
                        </div>
                        <div>
                            <span class="fw-semibold text-dark small d-block" style="line-height: 1;"><%= user.getNombre_usuarios() %></span>
                            <small class="text-muted" style="font-size: 0.7rem;">SEDADA Central</small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Encabezado de la Sección -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h3 class="fw-bold m-0" style="font-size: 1.4rem;">Financial Summary</h3>
                    <p class="text-muted small m-0 mt-1">Today's billing overview and tax calculations.</p>
                </div>
                <div class="d-flex gap-2">
                    <button class="btn btn-outline-dark btn-sm fw-semibold bg-white px-3"><i class="fa-solid fa-download me-1"></i> Export PDF</button>
                    <button class="btn btn-dark btn-sm fw-semibold px-3" data-bs-toggle="modal" data-bs-target="#modalNuevaFactura">
                        <i class="fa-solid fa-plus me-1"></i> + New Invoice
                    </button>
                </div>
            </div>

            <!-- Tarjetas de Métricas Financieras -->
            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <div class="card card-metric">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">TOTAL INVOICED TODAY</span>
                            <div class="bg-light p-2 rounded-2 text-primary"><i class="fa-solid fa-wallet"></i></div>
                        </div>
                        <h3 class="fw-bold m-0">$<%= totalInvoicedToday %></h3>
                        <small class="text-success fw-semibold mt-1" style="font-size: 0.75rem;"><i class="fa-solid fa-arrow-trend-up me-1"></i> +8.2% vs yesterday</small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-metric">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">VAT COLLECTED (19%)</span>
                            <div class="bg-light p-2 rounded-2 text-success"><i class="fa-solid fa-percent"></i></div>
                        </div>
                        <h3 class="fw-bold m-0">$<%= totalTaxCollected %></h3>
                        <small class="text-muted mt-1" style="font-size: 0.75rem;">Pending remittance</small>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card card-metric">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">CONSUMPTION TAX (8%)</span>
                            <div class="bg-light p-2 rounded-2 text-warning"><i class="fa-solid fa-file-invoice-dollar"></i></div>
                        </div>
                        <h3 class="fw-bold m-0">$<%= totalTaxCollected.multiply(new BigDecimal("0.4")) %></h3>
                        <small class="text-muted mt-1" style="font-size: 0.75rem;">Local tax withholdings</small>
                    </div>
                </div>
            </div>

            <!-- Tabla de Historial de Facturas -->
            <div class="table-container">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h5 class="fw-bold m-0" style="font-size: 1.1rem;">Invoice History</h5>
                    <a href="#" class="text-decoration-none text-dark small fw-semibold">View All <i class="fa-solid fa-arrow-right small ms-1"></i></a>
                </div>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="text-muted small bg-light">
                            <tr>
                                <th class="py-3 ps-3">INVOICE #</th>
                                <th>DATE / TIME</th>
                                <th>TABLE / ORDER</th>
                                <th>PAYMENT METHOD</th>
                                <th>TOTAL (INC. TAX)</th>
                                <th>STATUS</th>
                                <th class="text-end pe-3">ACTIONS</th>
                            </tr>
                        </thead>
                        <tbody class="small">
                            <% 
                                if (listaFacturas != null && !listaFacturas.isEmpty()) {
                                    for (Facturas f : listaFacturas) {
                            %>
                            <tr>
                                <td class="fw-semibold ps-3">
                                    <a href="${pageContext.request.contextPath}/admin/facturas?detalle_id=<%= f.getId_facturas() %>" class="text-decoration-none text-dark">
                                        <%= f.getNumero_facturas() %>
                                    </a>
                                </td>
                                <td class="text-muted"><%= f.getFechas_facturas() != null ? f.getFechas_facturas().toString() : "Today" %></td>
                                <td class="text-muted">Pedido ID: <%= f.getPedidos_id_pedidos() %></td>
                                <td><i class="fa-regular fa-credit-card me-1 text-secondary"></i> Tarjeta / Ref.</td>
                                <td class="fw-bold">$<%= f.getTotales() %></td>
                                <td>
                                    <span class="badge bg-success bg-opacity-10 text-success border px-2 py-1">
                                        Paid
                                    </span>
                                </td>
                                <td class="text-end pe-3">
                                    <div class="d-flex justify-content-end gap-1">
                                        <a href="${pageContext.request.contextPath}/admin/facturas?detalle_id=<%= f.getId_facturas() %>" class="btn btn-sm btn-outline-dark py-0 px-2" title="Ver Detalle">
                                            <i class="fa-solid fa-eye"></i>
                                        </a>
                                        <a href="${pageContext.request.contextPath}/admin/facturas?accion=eliminar&id=<%= f.getId_facturas() %>" class="btn btn-sm btn-outline-danger py-0 px-2" onclick="return confirm('¿Desea eliminar esta factura?');" title="Eliminar">
                                            <i class="fa-solid fa-trash-can"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <% 
                                    }
                                } else {
                            %>
                            <tr>
                                <td colspan="7" class="text-center py-4 text-muted">No hay facturas registradas en el sistema.</td>
                            </tr>
                            <% } %>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <!-- Columna Derecha: Despliegue de Detalle de Factura Seleccionada (Estilo Side-by-Side Consistente) -->
        <% if (facturaSeleccionada != null) { %>
        <div class="card border-0 shadow-sm p-4 bg-white" style="width: 420px; min-width: 420px; border-radius: 8px; position: sticky; top: 20px;">
            <div class="d-flex justify-content-between align-items-start mb-3 border-bottom pb-3">
                <div>
                    <h5 class="fw-bold m-0 text-dark">Factura Electrónica</h5>
                    <span class="text-primary fw-bold fs-6"><%= facturaSeleccionada.getNumero_facturas() %></span>
                    <div class="text-muted" style="font-size: 0.75rem;">DIAN Sincronizado • Rango AUT 001-KUT 0000</div>
                </div>
                <div class="d-flex gap-1">
                    <button class="btn btn-sm btn-dark py-1 px-2" title="Descargar PDF"><i class="fa-solid fa-download"></i></button>
                    <a href="${pageContext.request.contextPath}/admin/facturas" class="btn btn-sm btn-outline-secondary py-1 px-2" title="Cerrar Detalle"><i class="fa-solid fa-xmark"></i></a>
                </div>
            </div>

            <div class="small mb-3 text-muted bg-light p-2 rounded-2">
                <div class="d-flex justify-content-between mb-1">
                    <span>Fecha y Hora: <strong><%= facturaSeleccionada.getFechas_facturas() %></strong></span>
                    <span>Mesa / Salón: <strong>Salón Principal</strong></span>
                </div>
                <div class="d-flex justify-content-between">
                    <span>Mesero / Atendido por: <strong>Admin SEDADA</strong></span>
                    <span>Cliente: <strong>Consumidor Final</strong></span>
                </div>
            </div>

            <h6 class="fw-bold small text-uppercase mb-2 text-secondary" style="letter-spacing: 0.5px;">Detalle de Pagos & Liquidación</h6>
            
            <div class="table-responsive mb-3">
                <table class="table table-sm align-middle small mb-0">
                    <thead class="text-muted bg-light">
                        <tr>
                            <th>CONCEPTO / REF</th>
                            <th class="text-end">VALOR</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Subtotal Pedido ID: <%= facturaSeleccionada.getPedidos_id_pedidos() %></td>
                            <td class="text-end">$<%= facturaSeleccionada.getSubtotales() %></td>
                        </tr>
                        <tr>
                            <td>Impuestos (IVA / DIAN)</td>
                            <td class="text-end">$<%= facturaSeleccionada.getImpuestos() %></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="bg-light p-3 rounded-2 small mb-3">
                <div class="fw-bold mb-1 text-dark"><i class="fa-regular fa-credit-card me-1"></i> Método de Pago & Conciliación</div>
                <div class="text-muted mb-1">Estado ID Estado Pago: <strong><%= facturaSeleccionada.getEstados_pago_id_estados_pago() %></strong></div>
                <div class="text-success fw-semibold"><i class="fa-solid fa-circle-check me-1"></i> Transacción Aprobada y Conciliada con Supabase</div>
            </div>

            <div class="border-top pt-3">
                <div class="d-flex justify-content-between mb-2 small text-muted">
                    <span>Subtotal Pago:</span>
                    <span>$<%= facturaSeleccionada.getSubtotales() %></span>
                </div>
                <div class="d-flex justify-content-between mb-2 small text-muted">
                    <span>Impuestos Totales:</span>
                    <span>$<%= facturaSeleccionada.getImpuestos() %></span>
                </div>
                <div class="d-flex justify-content-between fw-bold text-dark fs-5 mb-3">
                    <span>Total Pagado:</span>
                    <span class="text-primary">$<%= facturaSeleccionada.getTotales() %></span>
                </div>
            </div>

            <div class="text-center text-muted border-top pt-2" style="font-size: 0.7rem;">
                CUFE (Código Único de Factura Electrónica): <br>
                <span class="font-monospace text-dark">d41d8cd98f00b204e9800998ecf8427e</span>
            </div>
        </div>
        <% } %>

    </div>

    <!-- Modal Nueva Factura -->
    <div class="modal fade" id="modalNuevaFactura" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="${pageContext.request.contextPath}/admin/facturas" method="POST">
                    <input type="hidden" name="accion" value="insertar_factura">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold fs-6">Generar Nueva Factura</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body small">
                        <div class="mb-2">
                            <label class="form-label fw-semibold">Número de Factura</label>
                            <input type="text" class="form-control form-control-sm" name="numero_facturas" placeholder="Ej. INV-2026-1046" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label fw-semibold">Subtotal ($)</label>
                            <input type="number" step="0.01" class="form-control form-control-sm" name="subtotales" placeholder="Ej. 100.00" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label fw-semibold">Impuestos ($)</label>
                            <input type="number" step="0.01" class="form-control form-control-sm" name="impuestos" placeholder="Ej. 19.00" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label fw-semibold">Total con Impuestos ($)</label>
                            <input type="number" step="0.01" class="form-control form-control-sm" name="totales" placeholder="Ej. 119.00" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label fw-semibold">ID Pedido Asociado</label>
                            <input type="number" class="form-control form-control-sm" name="pedidos_id_pedidos" placeholder="Ej. 1" required>
                        </div>
                        <div class="mb-2">
                            <label class="form-label fw-semibold">ID Estado de Pago (Ej. 1: Pagado)</label>
                            <input type="number" class="form-control form-control-sm" name="estados_pago_id_estados_pago" value="1" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-dark btn-sm">Guardar Factura</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>