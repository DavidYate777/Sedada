<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuarios" %>
<%@ page import="Modelo.Pedido" %>
<%@ page import="java.util.List" %>
<%
    Usuarios user = (Usuarios) session.getAttribute("usuarioLogueado");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }
    
    List<Pedido> listaPedidos = (List<Pedido>) request.getAttribute("listaPedidosRecientes");
    Integer totalPedidos = (Integer) request.getAttribute("totalPedidos");
    Integer totalMesas = (Integer) request.getAttribute("totalMesas");
    Integer totalCategorias = (Integer) request.getAttribute("totalCategorias");

    if (totalPedidos == null) totalPedidos = 0;
    if (totalMesas == null) totalMesas = 0;
    if (totalCategorias == null) totalCategorias = 0;

    String inicialUsuario = (user.getNombre_usuarios() != null && !user.getNombre_usuarios().trim().isEmpty()) 
            ? user.getNombre_usuarios().trim().substring(0, 1).toUpperCase() : "U";
    String nombreUsuario = (user.getNombre_usuarios() != null && !user.getNombre_usuarios().trim().isEmpty()) 
            ? user.getNombre_usuarios() : "Usuario";
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - SEDADA System</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Archivo CSS centralizado -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">
</head>
<body class="admin-body">

    <!-- Menú Lateral -->
    <div class="admin-sidebar">
        <div class="brand d-flex align-items-center gap-2">
            <div class="bg-dark text-white rounded p-1 px-2 fw-bold" style="font-size: 0.8rem;">SD</div>
            <div>
                <div style="line-height: 1.2;">SEDADA</div>
                <small class="text-muted fw-normal" style="font-size: 0.70rem;">ENTERPRISE OPS</small>
            </div>
        </div>
        
        <div class="px-2 mt-2 flex-grow-1">
            <div class="text-muted px-3 mb-1" style="font-size: 0.65rem; letter-spacing: 0.5px;">MAIN MENU</div>
            <ul class="nav flex-column gap-1">
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/admin_dashboard" class="nav-link active"><i class="fa-solid fa-shapes"></i> Resumen</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/pedidos" class="nav-link"><i class="fa-solid fa-cart-shopping"></i> Pedidos</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/inventario" class="nav-link"><i class="fa-solid fa-boxes-stacked"></i> Inventario</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/mesas" class="nav-link"><i class="fa-solid fa-chair"></i> Mesas</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/usuarios" class="nav-link"><i class="fa-solid fa-users"></i> Usuarios</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/categorias" class="nav-link"><i class="fa-solid fa-layer-group"></i> Categorías</a></li>
                <li class="nav-item"><a href="${pageContext.request.contextPath}/admin/facturas" class="nav-link"><i class="fa-solid fa-file-invoice-dollar"></i> Facturación e Impuestos</a></li>
            </ul>
        </div>

        <div class="p-3 border-top">
            <a href="#" class="nav-link mb-2"><i class="fa-solid fa-circle-question"></i> Soporte</a>
            <a href="${pageContext.request.contextPath}/LoginServlet?accion=logout" class="nav-link text-danger"><i class="fa-solid fa-right-from-bracket"></i> Cerrar Sesión</a>
        </div>
    </div>

    <!-- Área de Contenido Principal -->
    <div class="admin-main-content">
        
        <!-- Barra Superior -->
        <div class="admin-top-navbar">
            <h4 class="m-0 fw-bold text-dark" style="font-size: 1.15rem;">SEDADA Manager Pro</h4>
            <div class="position-relative">
                <i class="fa-solid fa-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted small"></i>
                <input type="text" class="form-control admin-search-box ps-5 text-muted small" placeholder="Buscar pedidos, mesas o inventario...">
            </div>
            <div class="d-flex align-items-center gap-3">
                <i class="fa-regular fa-bell text-secondary fs-6" style="cursor: pointer;"></i>
                <a href="${pageContext.request.contextPath}/perfil" class="text-secondary d-flex align-items-center text-decoration-none" title="Configuración de Perfil">
                    <i class="fa-solid fa-gear fs-6"></i>
                </a>
                <div class="d-flex align-items-center gap-2 border-start ps-3">
                    <div class="bg-dark text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 32px; height: 32px; font-size: 0.8rem;">
                        <%= inicialUsuario %>
                    </div>
                    <span class="fw-semibold text-dark small"><%= nombreUsuario %></span>
                </div>
            </div>
        </div>

        <!-- Encabezado de la Sección -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold m-0" style="font-size: 1.5rem;">Resumen</h3>
                <p class="text-muted small m-0 mt-1">Métricas operativas del día y control de pedidos activos.</p>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-outline-dark btn-sm fw-semibold bg-white px-3"><i class="fa-solid fa-file-invoice me-1"></i> Nueva Factura</button>
                <button class="btn btn-dark btn-sm fw-semibold px-3"><i class="fa-solid fa-cash-register me-1"></i> Cerrar Caja</button>
            </div>
        </div>

        <!-- Tarjetas de Métricas -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="bg-light p-2 rounded-2 text-primary"><i class="fa-solid fa-wallet"></i></div>
                        <span class="badge bg-success bg-opacity-10 text-success fw-semibold small" style="font-size: 0.7rem;"><i class="fa-solid fa-arrow-trend-up me-1"></i> +8.2%</span>
                    </div>
                    <span class="text-muted fw-semibold" style="font-size: 0.75rem; letter-spacing: 0.5px;">VENTAS DEL DÍA</span>
                    <h3 class="fw-bold m-0 mt-1">$1,240<span class="text-muted fw-normal fs-6">k</span></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="bg-light p-2 rounded-2 text-warning"><i class="fa-solid fa-utensils"></i></div>
                    </div>
                    <span class="text-muted fw-semibold" style="font-size: 0.75rem; letter-spacing: 0.5px;">PEDIDOS ACTIVOS</span>
                    <h3 class="fw-bold m-0 mt-1"><%= totalPedidos %></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="bg-light p-2 rounded-2 text-info"><i class="fa-solid fa-chair"></i></div>
                        <span class="text-muted" style="font-size: 0.75rem;">Capacidad Total</span>
                    </div>
                    <span class="text-muted fw-semibold" style="font-size: 0.75rem; letter-spacing: 0.5px;">MESAS REGISTRADAS</span>
                    <h3 class="fw-bold m-0 mt-1"><%= totalMesas %></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div class="bg-light p-2 rounded-2 text-primary"><i class="fa-solid fa-layer-group"></i></div>
                    </div>
                    <span class="text-muted fw-semibold" style="font-size: 0.75rem; letter-spacing: 0.5px;">TOTAL CATEGORÍAS</span>
                    <h3 class="fw-bold m-0 mt-1"><%= totalCategorias %></h3>
                </div>
            </div>
        </div>

        <!-- Tabla de Órdenes Recientes -->
        <div class="table-container">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold m-0" style="font-size: 1.1rem;">Órdenes Recientes</h5>
                <a href="${pageContext.request.contextPath}/admin/pedidos" class="text-decoration-none text-dark small fw-semibold">Ver Todos <i class="fa-solid fa-arrow-right small ms-1"></i></a>
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="text-muted small bg-light">
                        <tr>
                            <th class="py-3 ps-3">ID PEDIDO</th>
                            <th>FECHA Y HORA</th>
                            <th>UBICACIÓN / MESA</th>
                            <th>ESTADO</th>
                            <th class="text-end pe-3">ACCIONES</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <% 
                            if (listaPedidos != null && !listaPedidos.isEmpty()) {
                                for (Pedido p : listaPedidos) {
                        %>
                        <tr>
                            <td class="fw-semibold ps-3">#ORD-0<%= p.getId_pedidos() %></td>
                            <td class="text-muted"><%= p.getFecha_horas() != null ? p.getFecha_horas().toString() : "Reciente" %></td>
                            <td><%= p.getDireccion_entrega() != null && !p.getDireccion_entrega().isBlank() ? p.getDireccion_entrega() : "Mesa ID: " + p.getMesas_id_mesas() %></td>
                            <td>
                                <span class="badge badge-status bg-warning bg-opacity-15 text-warning-emphasis border border-warning-subtle">
                                    <i class="fa-solid fa-circle small me-1" style="font-size: 5px;"></i> Estado ID: <%= p.getEstados_pedidos_id_estados_pedidos() %>
                                </span>
                            </td>
                            <td class="text-end pe-3">
                                <button class="btn btn-sm btn-light border py-0 px-2 text-secondary" title="Opciones"><i class="fa-solid fa-ellipsis-vertical"></i></button>
                            </td>
                        </tr>
                        <% 
                                }
                            } else {
                        %>
                        <tr>
                            <td colspan="5" class="text-center py-4 text-muted">No hay pedidos registrados actualmente en el sistema.</td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>