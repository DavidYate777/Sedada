<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuarios" %>
<%@ page import="Modelo.Pedido" %>
<%@ page import="java.util.List" %>
<%
    Usuarios user = (Usuarios) session.getAttribute("usuarioLogueado");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }

    Integer totalMesas = (Integer) request.getAttribute("totalMesas");
    Long mesasDisponibles = (Long) request.getAttribute("mesasDisponibles");
    Long mesasOcupadas = (Long) request.getAttribute("mesasOcupadas");
    Integer totalPedidosPropios = (Integer) request.getAttribute("totalPedidosPropios");
    List<Pedido> pedidosRecientes = (List<Pedido>) request.getAttribute("pedidosRecientes");

    if (totalMesas == null) totalMesas = 0;
    if (mesasDisponibles == null) mesasDisponibles = 0L;
    if (mesasOcupadas == null) mesasOcupadas = 0L;
    if (totalPedidosPropios == null) totalPedidosPropios = 0;
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel del Mesero - SEDADA Enterprise OPS</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Archivo CSS centralizado -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">
</head>
<body class="admin-body">

    <!-- Menú Lateral -->
    <div class="admin-sidebar">
        <div class="brand d-flex align-items-center gap-2">
            <div class="bg-dark text-white rounded p-1 px-2 fw-bold" style="font-size: 0.8rem;">SD</div>
            <div>
                <div style="line-height: 1.2;">SEDADA</div>
                <small class="text-muted fw-normal" style="font-size: 0.70rem;">MESERO OPS</small>
            </div>
        </div>

        <div class="px-2 mt-2 flex-grow-1">
            <div class="text-muted px-3 mb-1" style="font-size: 0.65rem; letter-spacing: 0.5px;">MENÚ PRINCIPAL</div>
            <ul class="nav flex-column gap-1">
                <li class="nav-item">
                    <a href="${pageContext.request.contextPath}/mesero/dashboard" class="nav-link active">
                        <i class="fa-solid fa-shapes"></i> Resumen
                    </a>
                </li>
                <li class="nav-item">
                    <a href="${pageContext.request.contextPath}/mesero/pedidos" class="nav-link">
                        <i class="fa-solid fa-cart-shopping"></i> Tomar Pedidos
                    </a>
                </li>
            </ul>
        </div>

        <div class="p-3 border-top">
            <a href="#" class="nav-link mb-2"><i class="fa-solid fa-circle-question"></i> Soporte</a>
            <a href="${pageContext.request.contextPath}/LoginServlet?accion=logout" class="nav-link text-danger">
                <i class="fa-solid fa-right-from-bracket"></i> Cerrar Sesión
            </a>
        </div>
    </div>

    <!-- Área de Contenido Principal -->
    <div class="admin-main-content">

        <!-- Barra Superior -->
        <div class="admin-top-navbar mb-3">
            <div class="text-muted small">SEDADA / Mesero / <span class="text-dark fw-semibold">Resumen</span></div>
            <div class="d-flex align-items-center gap-3">
                <i class="fa-regular fa-bell text-secondary fs-6" style="cursor: pointer;"></i>
                <a href="${pageContext.request.contextPath}/perfil" class="text-secondary d-flex align-items-center text-decoration-none" title="Configuración de Perfil">
                    <i class="fa-solid fa-gear fs-6"></i>
                </a>
                <div class="d-flex align-items-center gap-2 border-start ps-3">
                    <div class="bg-dark text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 32px; height: 32px; font-size: 0.8rem;">
                        <%= user.getNombre_usuarios().substring(0, 1).toUpperCase() %>
                    </div>
                    <div>
                        <span class="fw-semibold text-dark small d-block" style="line-height: 1;"><%= user.getNombre_usuarios() %></span>
                        <small class="text-muted" style="font-size: 0.7rem;">Mesero Activo</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Encabezado de la Sección -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold m-0" style="font-size: 1.4rem;">Bienvenido, <%= user.getNombre_usuarios() %></h3>
                <p class="text-muted small m-0 mt-1">Estado del salón y resumen de sus comandas registradas.</p>
            </div>
            <a href="${pageContext.request.contextPath}/mesero/pedidos" class="btn btn-dark btn-sm fw-semibold px-3">
                <i class="fa-solid fa-plus me-1"></i> Tomar Pedido
            </a>
        </div>

        <!-- Tarjetas de Métricas -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">MESAS EN EL SALÓN</span>
                        <div class="bg-light p-2 rounded-2 text-primary"><i class="fa-solid fa-utensils"></i></div>
                    </div>
                    <h3 class="fw-bold m-0"><%= totalMesas %> <span class="text-muted fw-normal fs-6">mesas</span></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;"><i class="fa-solid fa-circle text-success me-1" style="font-size: 8px;"></i> DISPONIBLES</span>
                        <div class="bg-light p-2 rounded-2 text-success"><i class="fa-solid fa-check"></i></div>
                    </div>
                    <h3 class="fw-bold m-0"><%= mesasDisponibles %></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;"><i class="fa-solid fa-circle text-primary me-1" style="font-size: 8px;"></i> OCUPADAS</span>
                        <div class="bg-light p-2 rounded-2 text-info"><i class="fa-solid fa-chair"></i></div>
                    </div>
                    <h3 class="fw-bold m-0"><%= mesasOcupadas %></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">MIS PEDIDOS REGISTRADOS</span>
                        <div class="bg-light p-2 rounded-2 text-dark"><i class="fa-solid fa-receipt"></i></div>
                    </div>
                    <h3 class="fw-bold m-0"><%= totalPedidosPropios %></h3>
                </div>
            </div>
        </div>

        <!-- Pedidos Recientes -->
        <div class="table-container">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold m-0" style="font-size: 1.1rem;">Mis Últimos Pedidos</h5>
                <a href="${pageContext.request.contextPath}/mesero/pedidos" class="small text-decoration-none fw-semibold text-dark">
                    Ver todos <i class="fa-solid fa-arrow-right ms-1"></i>
                </a>
            </div>
            <% if (pedidosRecientes != null && !pedidosRecientes.isEmpty()) { %>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="text-muted small bg-light">
                        <tr>
                            <th class="ps-3 py-3">PEDIDO #</th>
                            <th>TIPO</th>
                            <th>REFERENCIA / UBICACIÓN</th>
                            <th>FECHA Y HORA</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <% for (Pedido p : pedidosRecientes) { %>
                        <tr>
                            <td class="fw-semibold ps-3">#ORD-<%= p.getId_pedidos() %></td>
                            <td>
                                <span class="badge <%= p.getMesas_id_mesas() != null ? "bg-primary text-primary" : "bg-info text-info" %> bg-opacity-10 border px-2 py-1">
                                    <%= p.getMesas_id_mesas() != null ? "Mesa" : "Domicilio" %>
                                </span>
                            </td>
                            <td class="text-muted">
                                <%= p.getMesas_id_mesas() != null
                                        ? ("Mesa #" + p.getMesas_id_mesas())
                                        : (p.getDireccion_entrega() != null ? p.getDireccion_entrega() : "N/D") %>
                            </td>
                            <td class="text-muted"><%= p.getFecha_horas() != null ? p.getFecha_horas().toString() : "Reciente" %></td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>
            <% } else { %>
            <div class="p-4 text-center text-muted">
                <i class="fa-solid fa-cart-flatbed fs-2 mb-2 text-secondary opacity-50"></i>
                <p class="small mb-0">Aún no ha registrado pedidos en el turno actual. Use el botón "Tomar Pedido" para comenzar.</p>
            </div>
            <% } %>
        </div>

    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>