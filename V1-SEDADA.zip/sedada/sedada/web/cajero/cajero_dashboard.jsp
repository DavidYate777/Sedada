<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuarios" %>
<%@ page import="java.math.BigDecimal" %>
<%
    Usuarios user = (Usuarios) session.getAttribute("usuarioLogueado");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }

    Integer pedidosPorFacturar = (Integer) request.getAttribute("pedidosPorFacturar");
    Integer facturasPendientesPago = (Integer) request.getAttribute("facturasPendientesPago");
    Integer facturasHoy = (Integer) request.getAttribute("facturasHoy");
    BigDecimal totalFacturadoHoy = (BigDecimal) request.getAttribute("totalFacturadoHoy");
    Integer totalFacturas = (Integer) request.getAttribute("totalFacturas");

    if (pedidosPorFacturar == null) pedidosPorFacturar = 0;
    if (facturasPendientesPago == null) facturasPendientesPago = 0;
    if (facturasHoy == null) facturasHoy = 0;
    if (totalFacturadoHoy == null) totalFacturadoHoy = BigDecimal.ZERO;
    if (totalFacturas == null) totalFacturas = 0;
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel del Cajero - SEDADA Enterprise OPS</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Archivo CSS centralizado -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">
</head>
<body class="admin-body">

    <!-- Menú Lateral -->
    <div class="admin-sidebar">
        <div class="brand d-flex align-items-center gap-2">
            <div class="bg-dark text-white rounded p-1 px-2 fw-bold" style="font-size: 0.8rem;">SD</div>
            <div>
                <div style="line-height: 1.2;">SEDADA</div>
                <small class="text-muted fw-normal" style="font-size: 0.70rem;">CAJERO OPS</small>
            </div>
        </div>

        <div class="px-2 mt-2 flex-grow-1">
            <div class="text-muted px-3 mb-1" style="font-size: 0.65rem; letter-spacing: 0.5px;">MENÚ PRINCIPAL</div>
            <ul class="nav flex-column gap-1">
                <li class="nav-item">
                    <a href="${pageContext.request.contextPath}/cajero/dashboard" class="nav-link active">
                        <i class="fa-solid fa-shapes"></i> Resumen
                    </a>
                </li>
                <li class="nav-item">
                    <a href="${pageContext.request.contextPath}/cajero/facturacion" class="nav-link">
                        <i class="fa-solid fa-file-invoice-dollar"></i> Facturación
                    </a>
                </li>
            </ul>
        </div>

        <div class="p-3 border-top">
            <a href="#" class="nav-link mb-2"><i class="fa-solid fa-circle-question"></i> Soporte</a>
            <a href="${pageContext.request.contextPath}/LoginServlet?accion=logout" class="nav-link text-danger">
                <i class="fa-solid fa-right-from-bracket"></i> Cerrar Sesión
            </a>
        </div>
    </div>

    <!-- Área de Contenido Principal -->
    <div class="admin-main-content">

        <!-- Barra Superior -->
        <div class="admin-top-navbar mb-3">
            <div class="text-muted small">SEDADA / Cajero / <span class="text-dark fw-semibold">Resumen</span></div>
            <div class="d-flex align-items-center gap-3">
                <i class="fa-regular fa-bell text-secondary fs-6" style="cursor: pointer;"></i>
                <a href="${pageContext.request.contextPath}/perfil" class="text-secondary d-flex align-items-center text-decoration-none" title="Configuración de Perfil">
                    <i class="fa-solid fa-gear fs-6"></i>
                </a>
                <div class="d-flex align-items-center gap-2 border-start ps-3">
                    <div class="bg-dark text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 32px; height: 32px; font-size: 0.8rem;">
                        <%= user.getNombre_usuarios().substring(0, 1).toUpperCase() %>
                    </div>
                    <div>
                        <span class="fw-semibold text-dark small d-block" style="line-height: 1;"><%= user.getNombre_usuarios() %></span>
                        <small class="text-muted" style="font-size: 0.7rem;">Cajero Activo</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Encabezado de la Sección -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold m-0" style="font-size: 1.4rem;">Bienvenido, <%= user.getNombre_usuarios() %></h3>
                <p class="text-muted small m-0 mt-1">Resumen de facturación y pedidos pendientes de cobro.</p>
            </div>
            <a href="${pageContext.request.contextPath}/cajero/facturacion" class="btn btn-dark btn-sm fw-semibold px-3">
                <i class="fa-solid fa-file-invoice me-1"></i> Ir a Facturación
            </a>
        </div>

        <!-- Tarjetas de Métricas -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">PEDIDOS POR FACTURAR</span>
                        <div class="bg-light p-2 rounded-2 text-warning"><i class="fa-solid fa-clock"></i></div>
                    </div>
                    <h3 class="fw-bold m-0"><%= pedidosPorFacturar %></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">FACTURAS PENDIENTES</span>
                        <div class="bg-light p-2 rounded-2 text-danger"><i class="fa-solid fa-hourglass-half"></i></div>
                    </div>
                    <h3 class="fw-bold m-0"><%= facturasPendientesPago %></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">FACTURAS DE HOY</span>
                        <div class="bg-light p-2 rounded-2 text-success"><i class="fa-solid fa-receipt"></i></div>
                    </div>
                    <h3 class="fw-bold m-0"><%= facturasHoy %></h3>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card card-metric">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="text-muted fw-semibold" style="font-size: 0.7rem; letter-spacing: 0.5px;">TOTAL FACTURADO HOY</span>
                        <div class="bg-light p-2 rounded-2 text-primary"><i class="fa-solid fa-sack-dollar"></i></div>
                    </div>
                    <h3 class="fw-bold m-0">$<%= totalFacturadoHoy %></h3>
                </div>
            </div>
        </div>

        <!-- Panel Informativo de Historial -->
        <div class="table-container">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <h5 class="fw-bold m-0" style="font-size: 1.1rem;">Historial de Facturación</h5>
                <span class="badge bg-light text-dark border px-2 py-1"><%= totalFacturas %> facturas emitidas en total</span>
            </div>
            <p class="text-muted small mb-0">
                Acceda a la sección <strong>Facturación</strong> para procesar comandas provenientes del salón, aplicar impuestos y gestionar los métodos de pago.
            </p>
        </div>

    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>