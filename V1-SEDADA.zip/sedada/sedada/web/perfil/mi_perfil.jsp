<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuarios" %>
<%
    Usuarios user = (Usuarios) session.getAttribute("usuarioLogueado");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }

    // Identificación del Rol
    String nombreRol = "Usuario del Sistema";
    if (user.getRoles_id_roles() == 1) {
        nombreRol = "Administrator";
    } else if (user.getRoles_id_roles() == 2) {
        nombreRol = "Mesero / Operativo";
    } else if (user.getRoles_id_roles() == 3) {
        nombreRol = "Cajero / Facturación";
    }

    // Ruta de retorno según perfil
    String rutaDashboard = request.getContextPath() + "/login.jsp";
    if (user.getRoles_id_roles() == 1) {
        rutaDashboard = request.getContextPath() + "/admin/admin_dashboard";
    } else if (user.getRoles_id_roles() == 2) {
        rutaDashboard = request.getContextPath() + "/mesero/pedidos";
    } else if (user.getRoles_id_roles() == 3) {
        rutaDashboard = request.getContextPath() + "/cajero/dashboard";
    }

    String nombreCompleto = (user.getNombre_usuarios() != null ? user.getNombre_usuarios() : "") + 
                           (user.getApellido_usuarios() != null ? " " + user.getApellido_usuarios() : "");
    if (nombreCompleto.trim().isEmpty()) {
        nombreCompleto = "John Doe";
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Settings - SEDADA Enterprise</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">
</head>
<body class="admin-body py-4 bg-light">

    <div class="container profile-container" style="max-width: 1080px;">

        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark m-0" style="letter-spacing: -0.5px;">Profile Settings</h3>
                <p class="text-secondary small m-0 mt-1">Manage your personal information, role details, and security preferences.</p>
            </div>
            <a href="<%= rutaDashboard %>" class="btn btn-outline-secondary btn-sm fw-semibold rounded-2 px-3 shadow-sm">
                <i class="fa-solid fa-arrow-left me-1"></i> Return to Dashboard
            </a>
        </div>

        <% if ("true".equals(request.getParameter("exito"))) { %>
            <div class="alert alert-success alert-dismissible fade show small mb-4 border-0 shadow-sm rounded-3" role="alert">
                <i class="fa-solid fa-circle-check me-2 fs-6"></i> <strong>¡Operación exitosa!</strong> Los cambios han sido guardados correctamente en el sistema.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <% } else if ("true".equals(request.getParameter("error"))) { %>
            <div class="alert alert-danger alert-dismissible fade show small mb-4 border-0 shadow-sm rounded-3" role="alert">
                <i class="fa-solid fa-triangle-exclamation me-2 fs-6"></i> <strong>Error de actualización:</strong> No se pudieron guardar los cambios. Verifique la información ingresada.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <% } %>

        <form action="${pageContext.request.contextPath}/perfil" method="POST" id="formPerfil">
            <div class="row g-4">

                <div class="col-lg-4">
                    
                    <div class="card profile-card p-4 text-center mb-3 border-0 shadow-sm rounded-3 bg-white">
                        <div class="mx-auto mb-3 avatar-circle d-flex align-items-center justify-content-center fw-bold fs-2 bg-dark text-white rounded-circle shadow-sm" style="width: 80px; height: 80px;">
                            <%= user.getNombre_usuarios() != null && !user.getNombre_usuarios().isEmpty() ? user.getNombre_usuarios().substring(0, 1).toUpperCase() : "U" %>
                        </div>
                        
                        <h5 class="fw-bold text-dark m-0 fs-5"><%= nombreCompleto %></h5>
                        <div class="mt-2">
                            <span class="badge bg-dark bg-opacity-10 text-dark border border-dark-subtle rounded-pill px-3 py-1 fw-semibold"><%= nombreRol %></span>
                        </div>
                        
                        <p class="text-secondary mt-3 mb-3" style="font-size: 0.73rem;">Formatos permitidos: JPG, PNG o GIF. Tamaño máximo de 800KB.</p>
                        
                        <div class="d-flex gap-2 justify-content-center">
                            <button type="button" class="btn btn-dark btn-sm px-3 w-100 py-2 fw-semibold">
                                <i class="fa-solid fa-cloud-arrow-up me-1"></i> Upload New
                            </button>
                            <button type="button" class="btn btn-outline-danger btn-sm px-3" title="Delete Photo">
                                <i class="fa-regular fa-trash-can"></i>
                            </button>
                        </div>
                    </div>

                    <div class="card profile-card p-3 border-0 shadow-sm rounded-3 bg-white">
                        <div class="d-flex align-items-center gap-3">
                            <div class="bg-success bg-opacity-10 text-success p-2 rounded-circle d-flex align-items-center justify-content-center flex-shrink-0" style="width: 40px; height: 40px;">
                                <i class="fa-solid fa-shield-halved fs-6"></i>
                            </div>
                            <div>
                                <h6 class="fw-bold m-0 text-dark" style="font-size: 0.88rem;">Account Status</h6>
                                <p class="text-secondary m-0 mt-1" style="font-size: 0.78rem; line-height: 1.25;">Your account is active and operating under optimal security settings.</p>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="col-lg-8">

                    <div class="card profile-card p-4 mb-4 border-0 shadow-sm rounded-3 bg-white">
                        <div class="d-flex align-items-center gap-2 mb-4 border-bottom pb-2">
                            <i class="fa-solid fa-user-gear text-dark fs-5"></i>
                            <h5 class="fw-bold text-dark m-0 fs-5">Personal Information</h5>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold text-secondary small">First Name</label>
                                <input type="text" class="form-control form-control-sm" name="nombre_usuarios" value="<%= user.getNombre_usuarios() != null ? user.getNombre_usuarios() : "" %>" required placeholder="Nombres">
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold text-secondary small">Last Name</label>
                                <input type="text" class="form-control form-control-sm" name="apellido_usuarios" value="<%= user.getApellido_usuarios() != null ? user.getApellido_usuarios() : "" %>" required placeholder="Apellidos">
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold text-secondary small">Email Address</label>
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text bg-light text-muted"><i class="fa-regular fa-envelope"></i></span>
                                    <input type="email" class="form-control bg-light" value="<%= user.getCorreos() != null ? user.getCorreos() : "" %>" disabled readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold text-secondary small">Phone Number</label>
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text bg-light text-muted"><i class="fa-solid fa-phone"></i></span>
                                    <input type="text" class="form-control" name="telefonos" value="<%= user.getTelefonos() != null ? user.getTelefonos() : "" %>" placeholder="+57 (300) 000-0000">
                                </div>
                            </div>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-12">
                                <label class="form-label fw-semibold text-secondary small d-flex align-items-center justify-content-between">
                                    Assigned System Role
                                    <i class="fa-regular fa-circle-question text-secondary" style="font-size: 0.8rem;" title="El rol asignado solo puede ser gestionado por administradores del sistema."></i>
                                </label>
                                <input type="text" class="form-control form-control-sm bg-light" value="<%= nombreRol %>" disabled readonly>
                            </div>
                        </div>

                        <div>
                            <label class="form-label fw-semibold text-secondary small">Bio / Address Notes</label>
                            <textarea class="form-control form-control-sm" name="direccion_usuarios" rows="3" maxlength="500" placeholder="Dirección de residencia o notas sobre la cuenta..."><%= user.getDireccion_usuarios() != null ? user.getDireccion_usuarios() : "" %></textarea>
                            <div class="text-end text-secondary mt-1" style="font-size: 0.72rem;">Límite máximo: 500 caracteres</div>
                        </div>
                    </div>

                    <div class="card profile-card p-4 mb-4 border-0 shadow-sm rounded-3 bg-white">
                        <div class="d-flex align-items-center gap-2 mb-3 border-bottom pb-2">
                            <i class="fa-solid fa-lock text-dark fs-5"></i>
                            <h5 class="fw-bold text-dark m-0 fs-5">Security & Password</h5>
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold text-secondary small">Current Password</label>
                                <div class="input-group input-group-sm">
                                    <input type="password" name="password_actual" id="passActual" class="form-control" placeholder="••••••••">
                                    <button class="btn btn-outline-secondary" type="button" onclick="toggleVisibilidad('passActual')">
                                        <i class="fa-regular fa-eye" id="icon-passActual"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div class="row g-3 mb-2">
                            <div class="col-md-6">
                                <label class="form-label fw-semibold text-secondary small">New Password</label>
                                <div class="input-group input-group-sm">
                                    <input type="password" name="nueva_password" id="passNueva" class="form-control" placeholder="••••••••">
                                    <button class="btn btn-outline-secondary" type="button" onclick="toggleVisibilidad('passNueva')">
                                        <i class="fa-regular fa-eye" id="icon-passNueva"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-semibold text-secondary small">Confirm New Password</label>
                                <div class="input-group input-group-sm">
                                    <input type="password" name="confirmar_password" id="passConfirm" class="form-control" placeholder="••••••••">
                                    <button class="btn btn-outline-secondary" type="button" onclick="toggleVisibilidad('passConfirm')">
                                        <i class="fa-regular fa-eye" id="icon-passConfirm"></i>
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div id="passwordError" class="text-danger small mt-1 d-none">
                            <i class="fa-solid fa-circle-exclamation me-1"></i> Las contraseñas nuevas no coinciden.
                        </div>

                        <small class="text-muted d-flex align-items-center mt-2" style="font-size: 0.78rem;">
                            <i class="fa-regular fa-circle-check me-1 text-success"></i> Se recomienda incluir un mínimo de 8 caracteres con letras y números.
                        </small>
                    </div>

                    <div class="d-flex justify-content-end align-items-center gap-3">
                        <a href="<%= rutaDashboard %>" class="btn btn-light btn-sm px-4 fw-semibold border">Cancel</a>
                        <button type="submit" class="btn btn-dark btn-sm px-4 py-2 fw-semibold shadow-sm d-flex align-items-center gap-2">
                            <i class="fa-solid fa-floppy-disk"></i> Save Changes
                        </button>
                    </div>

                </div>

            </div>
        </form>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function toggleVisibilidad(idInput) {
            const input = document.getElementById(idInput);
            const icon = document.getElementById('icon-' + idInput);
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        }

        document.getElementById('formPerfil').addEventListener('submit', function (e) {
            const nueva = document.getElementById('passNueva').value;
            const confirm = document.getElementById('passConfirm').value;
            const errorDiv = document.getElementById('passwordError');

            if (nueva !== '' || confirm !== '') {
                if (nueva !== confirm) {
                    e.preventDefault();
                    errorDiv.classList.remove('d-none');
                } else {
                    errorDiv.classList.add('d-none');
                }
            }
        });
    </script>
</body>
</html>