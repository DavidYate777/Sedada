<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="Modelo.Usuarios" %>
<%@ page import="Modelo.Pedido" %>
<%@ page import="Modelo.DetallePedidos" %>
<%@ page import="Modelo.Productos" %>
<%@ page import="Modelo.Facturas" %>
<%@ page import="Modelo.MetodosPago" %>
<%@ page import="java.math.BigDecimal" %>
<%@ page import="java.util.List" %>
<%@ page import="java.util.Map" %>
<%@ page import="java.util.Set" %>
<%
    Usuarios user = (Usuarios) session.getAttribute("usuarioLogueado");
    if (user == null) {
        response.sendRedirect(request.getContextPath() + "/login.jsp");
        return;
    }

    List<Pedido> pedidosPendientes = (List<Pedido>) request.getAttribute("pedidosPendientes");
    Map<Integer, List<DetallePedidos>> detallesPorPedido = (Map<Integer, List<DetallePedidos>>) request.getAttribute("detallesPorPedido");
    Map<Integer, BigDecimal> totalPorPedido = (Map<Integer, BigDecimal>) request.getAttribute("totalPorPedido");
    Map<Integer, Productos> mapaProductos = (Map<Integer, Productos>) request.getAttribute("mapaProductos");
    List<Facturas> todasFacturas = (List<Facturas>) request.getAttribute("todasFacturas");
    Map<Integer, String> mapaEstadosPago = (Map<Integer, String>) request.getAttribute("mapaEstadosPago");
    Integer idEstadoPagado = (Integer) request.getAttribute("idEstadoPagado");
    List<MetodosPago> listaMetodosPago = (List<MetodosPago>) request.getAttribute("listaMetodosPago");
    Set<Integer> facturasConPago = (Set<Integer>) request.getAttribute("facturasConPago");

    if (idEstadoPagado == null) idEstadoPagado = -1;
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facturación - SEDADA Enterprise OPS</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Archivo CSS centralizado -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/styles.css">
</head>
<body class="admin-body">

    <!-- Menú Lateral -->
    <div class="admin-sidebar">
        <div class="brand d-flex align-items-center gap-2">
            <div class="bg-dark text-white rounded p-1 px-2 fw-bold" style="font-size: 0.8rem;">SD</div>
            <div>
                <div style="line-height: 1.2;">SEDADA</div>
                <small class="text-muted fw-normal" style="font-size: 0.70rem;">CAJERO OPS</small>
            </div>
        </div>

        <div class="px-2 mt-2 flex-grow-1">
            <div class="text-muted px-3 mb-1" style="font-size: 0.65rem; letter-spacing: 0.5px;">MENÚ PRINCIPAL</div>
            <ul class="nav flex-column gap-1">
                <li class="nav-item">
                    <a href="${pageContext.request.contextPath}/cajero/dashboard" class="nav-link">
                        <i class="fa-solid fa-shapes"></i> Resumen
                    </a>
                </li>
                <li class="nav-item">
                    <a href="${pageContext.request.contextPath}/cajero/facturacion" class="nav-link active">
                        <i class="fa-solid fa-file-invoice-dollar"></i> Facturación
                    </a>
                </li>
            </ul>
        </div>

        <div class="p-3 border-top">
            <a href="#" class="nav-link mb-2"><i class="fa-solid fa-circle-question"></i> Soporte</a>
            <a href="${pageContext.request.contextPath}/LoginServlet?accion=logout" class="nav-link text-danger">
                <i class="fa-solid fa-right-from-bracket"></i> Cerrar Sesión
            </a>
        </div>
    </div>

    <!-- Área de Contenido Principal -->
    <div class="admin-main-content">

        <!-- Barra Superior -->
        <div class="admin-top-navbar mb-3">
            <div class="text-muted small">SEDADA / Cajero / <span class="text-dark fw-semibold">Facturación</span></div>
            <div class="d-flex align-items-center gap-3">
                <i class="fa-regular fa-bell text-secondary fs-6" style="cursor: pointer;"></i>
                <a href="${pageContext.request.contextPath}/perfil" class="text-secondary d-flex align-items-center text-decoration-none" title="Configuración de Perfil">
                    <i class="fa-solid fa-gear fs-6"></i>
                </a>
                <div class="d-flex align-items-center gap-2 border-start ps-3">
                    <div class="bg-dark text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 32px; height: 32px; font-size: 0.8rem;">
                        <%= user.getNombre_usuarios().substring(0, 1).toUpperCase() %>
                    </div>
                    <div>
                        <span class="fw-semibold text-dark small d-block" style="line-height: 1;"><%= user.getNombre_usuarios() %></span>
                        <small class="text-muted" style="font-size: 0.7rem;">Cajero Activo</small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Encabezado de la Sección -->
        <div class="mb-4">
            <h3 class="fw-bold m-0" style="font-size: 1.4rem;">Módulo de Facturación</h3>
            <p class="text-muted small m-0 mt-1">Genere facturas electrónicas a partir de los pedidos del salón y registre la conciliación de pagos.</p>
        </div>

        <!-- Pedidos Pendientes de Facturar -->
        <div class="table-container mb-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold m-0" style="font-size: 1.05rem;">Pedidos Pendientes de Facturar</h5>
                <span class="badge bg-warning bg-opacity-10 text-warning border px-2 py-1 small">
                    <%= pedidosPendientes != null ? pedidosPendientes.size() : 0 %> comanda(s) por procesar
                </span>
            </div>
            
            <% if (pedidosPendientes != null && !pedidosPendientes.isEmpty()) { %>
            <div class="row g-3">
                <% for (Pedido p : pedidosPendientes) {
                    List<DetallePedidos> lineas = detallesPorPedido != null ? detallesPorPedido.get(p.getId_pedidos()) : null;
                    BigDecimal subtotal = totalPorPedido != null ? totalPorPedido.get(p.getId_pedidos()) : BigDecimal.ZERO;
                    if (subtotal == null) subtotal = BigDecimal.ZERO;
                %>
                <div class="col-md-6 col-lg-4">
                    <div class="card border-0 shadow-sm p-3 bg-white h-100 rounded-3 d-flex flex-column">
                        <div class="d-flex justify-content-between align-items-start border-bottom pb-2 mb-2">
                            <div>
                                <span class="badge bg-light text-dark fw-bold border">
                                    <%= p.getMesas_id_mesas() != null ? "Mesa " + p.getMesas_id_mesas() : "Domicilio" %>
                                </span>
                                <div class="text-muted" style="font-size: 0.72rem;">#ORD-<%= p.getId_pedidos() %></div>
                            </div>
                            <span class="fw-bold text-dark small">$<%= subtotal %></span>
                        </div>
                        <div class="mb-3 small flex-grow-1" style="max-height: 120px; overflow-y: auto;">
                            <% if (lineas != null && !lineas.isEmpty()) {
                                for (DetallePedidos d : lineas) {
                                    Productos prod = mapaProductos != null ? mapaProductos.get(d.getProductos_id_productos()) : null;
                                    String nombreProd = prod != null ? prod.getNombres_productos() : "Producto #" + d.getProductos_id_productos();
                                    BigDecimal precioUnit = d.getPrecio_unitario() != null ? d.getPrecio_unitario() : BigDecimal.ZERO;
                                    BigDecimal subtotalLinea = precioUnit.multiply(BigDecimal.valueOf(d.getCantidades()));
                            %>
                            <div class="d-flex justify-content-between text-muted py-1 border-bottom border-light">
                                <span><%= d.getCantidades() %>x <%= nombreProd %></span>
                                <span class="fw-semibold text-dark">$<%= subtotalLinea %></span>
                            </div>
                            <% } } else { %>
                            <div class="text-muted fst-italic">Sin ítems detallados.</div>
                            <% } %>
                        </div>
                        <button type="button" class="btn btn-dark btn-sm w-100 mt-auto fw-semibold"
                                data-bs-toggle="modal" data-bs-target="#modalGenerarFactura"
                                onclick="prepararGeneracion(<%= p.getId_pedidos() %>, '<%= p.getMesas_id_mesas() != null ? "Mesa " + p.getMesas_id_mesas() : "Domicilio" %>', '<%= subtotal %>')">
                            <i class="fa-solid fa-file-invoice me-1"></i> Generar Factura
                        </button>
                    </div>
                </div>
                <% } %>
            </div>
            <% } else { %>
            <div class="p-4 text-center text-muted">
                <i class="fa-solid fa-circle-check fs-2 mb-2 text-success opacity-50"></i>
                <p class="small mb-0">No hay pedidos pendientes por facturar en este momento.</p>
            </div>
            <% } %>
        </div>

        <!-- Facturas Generadas -->
        <div class="table-container">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold m-0" style="font-size: 1.05rem;">Historial de Facturas Emitidas</h5>
                <span class="text-muted small"><%= todasFacturas != null ? todasFacturas.size() : 0 %> factura(s) registradas</span>
            </div>
            <% if (todasFacturas != null && !todasFacturas.isEmpty()) { %>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="text-muted small bg-light">
                        <tr>
                            <th class="ps-3 py-3">FACTURA #</th>
                            <th>ORDEN ORIGEN</th>
                            <th>FECHA Y HORA</th>
                            <th>SUBTOTAL</th>
                            <th>IMPUESTOS</th>
                            <th>TOTAL</th>
                            <th>ESTADO</th>
                            <th class="text-end pe-3">ACCIONES</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <% for (Facturas f : todasFacturas) {
                            String nombreEstadoPago = mapaEstadosPago != null ? mapaEstadosPago.get(f.getEstados_pago_id_estados_pago()) : null;
                            if (nombreEstadoPago == null) nombreEstadoPago = "Estado #" + f.getEstados_pago_id_estados_pago();
                            boolean estaPagada = f.getEstados_pago_id_estados_pago() == idEstadoPagado
                                    || (facturasConPago != null && facturasConPago.contains(f.getId_facturas()));
                        %>
                        <tr>
                            <td class="fw-semibold ps-3"><%= f.getNumero_facturas() %></td>
                            <td class="text-muted">#ORD-<%= f.getPedidos_id_pedidos() %></td>
                            <td class="text-muted"><%= f.getFechas_facturas() %></td>
                            <td>$<%= f.getSubtotales() %></td>
                            <td class="text-muted">$<%= f.getImpuestos() %></td>
                            <td class="fw-bold text-dark">$<%= f.getTotales() %></td>
                            <td>
                                <% if (estaPagada) { %>
                                <span class="badge bg-success bg-opacity-10 text-success border px-2 py-1">
                                    <i class="fa-solid fa-circle-check me-1"></i> Pagada
                                </span>
                                <% } else { %>
                                <span class="badge bg-warning bg-opacity-10 text-warning border px-2 py-1">
                                    <i class="fa-solid fa-clock me-1"></i> <%= nombreEstadoPago %>
                                </span>
                                <% } %>
                            </td>
                            <td class="text-end pe-3">
                                <% if (!estaPagada) { %>
                                <button type="button" class="btn btn-dark btn-sm py-0 px-2 fw-semibold"
                                        data-bs-toggle="modal" data-bs-target="#modalRegistrarPago"
                                        onclick="prepararPago(<%= f.getId_facturas() %>, '<%= f.getNumero_facturas() %>', '<%= f.getTotales() %>')">
                                    <i class="fa-solid fa-hand-holding-dollar me-1"></i> Registrar Pago
                                </button>
                                <% } else { %>
                                <span class="text-muted small"><i class="fa-solid fa-check text-success me-1"></i> Conciliada</span>
                                <% } %>
                            </td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>
            </div>
            <% } else { %>
            <div class="p-4 text-center text-muted">
                <p class="small mb-0">Aún no se han generado facturas en la sesión actual.</p>
            </div>
            <% } %>
        </div>

    </div>

    <!-- Modal Generar Factura -->
    <div class="modal fade" id="modalGenerarFactura" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="${pageContext.request.contextPath}/cajero/facturacion" method="POST">
                    <input type="hidden" name="accion" value="generar_factura">
                    <input type="hidden" name="id_pedido" id="inputIdPedido">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold fs-6">Confirmar Emisión de Factura</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body small">
                        <p class="mb-2">Se procederá a liquidar la orden de consumo: <strong id="textoPedidoModal">-</strong></p>
                        <div class="alert alert-light border small text-muted mb-0">
                            Subtotal estimado: <strong>$<span id="textoSubtotalModal">0</span></strong>.<br>
                            Los impuestos (IVA / INC) se calcularán dinámicamente de acuerdo a la parametrización fiscal DIAN.
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-dark btn-sm fw-semibold">Generar Factura</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Registrar Pago -->
    <div class="modal fade" id="modalRegistrarPago" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form action="${pageContext.request.contextPath}/cajero/facturacion" method="POST">
                    <input type="hidden" name="accion" value="registrar_pago">
                    <input type="hidden" name="id_factura" id="inputIdFactura">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold fs-6">Registrar Transacción de Pago</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body small">
                        <div class="mb-3 bg-light p-2 rounded-2">
                            <div class="text-muted">Factura a liquidar: <strong id="textoFacturaModal" class="text-dark">-</strong></div>
                            <div class="text-muted">Monto Total: <strong class="text-primary fs-6">$<span id="textoTotalModal">0</span></strong></div>
                        </div>
                        <div class="mb-2">
                            <label class="form-label fw-semibold">Método de Pago</label>
                            <select class="form-select form-select-sm" name="metodos_pago_id_metodos_pago" required>
                                <% if (listaMetodosPago != null) {
                                    for (MetodosPago mp : listaMetodosPago) { %>
                                <option value="<%= mp.getId_metodos_pago() %>"><%= mp.getNombre_metodo_pago() %></option>
                                <% } } %>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-dark btn-sm fw-semibold">Confirmar Pago</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function prepararGeneracion(idPedido, referencia, subtotal) {
            document.getElementById('inputIdPedido').value = idPedido;
            document.getElementById('textoPedidoModal').innerText = referencia + ' (#ORD-' + idPedido + ')';
            document.getElementById('textoSubtotalModal').innerText = subtotal;
        }
        function prepararPago(idFactura, numeroFactura, total) {
            document.getElementById('inputIdFactura').value = idFactura;
            document.getElementById('textoFacturaModal').innerText = numeroFactura;
            document.getElementById('textoTotalModal').innerText = total;
        }
    </script>
</body>
</html>